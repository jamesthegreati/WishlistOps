﻿# WishlistOps Build Plan - Week 1: Critical Features
## Implementation Guide for AI Coding Agents

---

## 🎯 PROJECT CONTEXT & BIG PICTURE

**What We're Building:** WishlistOps - A "Publisher-in-a-Box" platform that automates Steam marketing for indie game developers.

**The Problem We Solve:** Indie developers stop marketing when they code. This context-switching costs 12-24 hours/week and causes commercial failure despite technical excellence.

**Our Solution:** Git-triggered automation that generates Steam announcements and banners using AI, with human approval gates to prevent quality issues.

**Architecture Philosophy:**
- Git is the single source of truth (version controlled)
- GitHub Actions provides serverless execution ($0 infrastructure)
- Dual interface: Git for programmers, Web dashboard for non-technical team members
- Human-in-the-loop: Discord approval before posting to Steam
- Quality first: Anti-slop filters prevent generic AI language

**Key Technical Constraints:**
- Zero infrastructure costs (GitHub + Cloudflare free tiers only)
- Must work for non-programmers (web dashboard requirement)
- Must prevent AI hallucinations (approval gate requirement)
- Must handle API failures gracefully (fallback mechanisms)
- Must respect Steam rate limits (max 1 post per week)

**Reference Documents:**
- `04_WishlistOps_System_Architecture_Diagrams.md` - Complete system architecture with 13 diagrams
- `05_WishlistOps_Revised_Architecture.md` - Production-ready architecture with all fixes
- `02_WishlistOps_Business_Blueprint.md` - Business requirements and constraints

---

## 📋 WEEK 1 OVERVIEW

**Goal:** Implement critical features that make WishlistOps functional and safe to use.

**Timeline:** 7 days (Tasks 1-4)

**Success Criteria:**
- [ ] AI can generate announcements from Git commits
- [ ] Team can review drafts in Discord before posting
- [ ] Anti-slop filter prevents generic language
- [ ] Non-programmers can configure settings via web dashboard
- [ ] End-to-end workflow tested with real Steam API

**Deliverables:**
1. GitHub Action workflow (main automation)
2. Discord approval bot
3. Anti-slop content filter
4. Web dashboard MVP
5. Documentation for beta testers

---

## 🚀 TASK 1: Core GitHub Action Workflow
**Priority:** CRITICAL  
**Timeline:** Day 1-2  
**Dependencies:** None  
**Files to Create:** 3 files

### Context for AI Agent

You are building the core automation engine for WishlistOps. This GitHub Action will:
1. Trigger when a developer pushes a Git tag (e.g., v1.2.0)
2. Parse Git commits to identify player-facing changes
3. Generate a Steam announcement using AI
4. Send it to Discord for human approval
5. Only post to Steam if approved

**Key Requirements:**
- Must be idempotent (safe to re-run)
- Must handle API failures gracefully
- Must respect rate limits
- Must log everything for debugging
- Must store state in Git (no external database)

**Anti-Patterns to Avoid:**
- ❌ Don't hardcode API keys in workflow files
- ❌ Don't auto-publish to Steam without approval
- ❌ Don't skip error handling
- ❌ Don't use deprecated GitHub Actions syntax
- ❌ Don't ignore rate limits


---

### TASK 1.1: GitHub Action Workflow Definition

**File:** `.github/workflows/wishlistops.yml`

**Prompt for AI Agent:**

```
CONTEXT:
You are creating the main GitHub Actions workflow for WishlistOps, a Steam marketing automation platform. This workflow orchestrates the entire process from Git commit to Discord notification.

ARCHITECTURE REFERENCE:
- See "Section 3: The Automation Infrastructure" in 04_WishlistOps_System_Architecture_Diagrams.md
- See "Complete Workflow" diagram showing 60-second execution timeline
- See "Fix #2: Discord Approval Gate" in 05_WishlistOps_Revised_Architecture.md

REQUIREMENTS:
1. Trigger on Git tag push (pattern: v*.*.*)
2. Trigger on manual dispatch (for testing)
3. Trigger on schedule (optional: weekly cron)
4. Use Ubuntu 22.04 runner (free tier)
5. Install Python 3.11+ and dependencies
6. Execute main automation script
7. Upload artifacts (logs, drafts) for debugging
8. Send notification on failure

TECHNICAL SPECIFICATIONS:
- Workflow name: "WishlistOps Automation"
- Runs-on: ubuntu-latest
- Timeout: 10 minutes (prevent runaway costs)
- Permissions: contents:read, actions:write
- Secrets required: STEAM_API_KEY, GOOGLE_AI_KEY, DISCORD_WEBHOOK_URL
- Environment variables: GITHUB_TOKEN (automatic)

QUALITY REQUIREMENTS:
- Use latest action versions (actions/checkout@v4, actions/setup-python@v5)
- Include comments explaining each step
- Use proper YAML indentation (2 spaces)
- Include conditional steps (skip if no changes)
- Add failure notifications

ERROR HANDLING:
- Continue-on-error for non-critical steps
- Retry logic for API calls (built into Python script)
- Upload logs even on failure
- Send Discord notification on error

CODE STYLE:
- Follow GitHub Actions best practices
- Use descriptive step names
- Group related steps
- Include timeout-minutes for each step
- Use secrets properly (never hardcode)

TESTING:
- Must validate with: actionlint (GitHub Actions linter)
- Must test with: act (local GitHub Actions testing)
- Must include example manual dispatch parameters

OUTPUT FORMAT:
Create a complete .github/workflows/wishlistops.yml file with:
1. Clear comments explaining the workflow purpose
2. All triggers (tag, manual, schedule)
3. Job definition with proper dependencies
4. All required steps in execution order
5. Artifact upload for debugging
6. Error handling and notifications

EXAMPLE STRUCTURE:
```yaml
name: WishlistOps Automation

on:
  push:
    tags:
      - 'v*.*.*'
  workflow_dispatch:
    inputs:
      dry_run:
        description: 'Run without posting to Steam'
        required: false
        default: 'true'
  schedule:
    - cron: '0 12 * * 1'  # Weekly on Monday at noon UTC

jobs:
  generate-and-notify:
    runs-on: ubuntu-latest
    timeout-minutes: 10
    permissions:
      contents: read
      actions: write
    
    steps:
      - name: Checkout repository
        uses: actions/checkout@v4
        with:
          fetch-depth: 0  # Need full history for git log
      
      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.11'
          cache: 'pip'
      
      - name: Install dependencies
        run: |
          pip install -r requirements.txt
      
      - name: Run WishlistOps automation
        env:
          STEAM_API_KEY: ${{ secrets.STEAM_API_KEY }}
          GOOGLE_AI_KEY: ${{ secrets.GOOGLE_AI_KEY }}
          DISCORD_WEBHOOK_URL: ${{ secrets.DISCORD_WEBHOOK_URL }}
        run: |
          python -m wishlistops.main --config wishlistops/config.json
      
      - name: Upload artifacts
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: wishlistops-logs
          path: |
            wishlistops/logs/
            wishlistops/drafts/
          retention-days: 30
      
      - name: Notify on failure
        if: failure()
        run: |
          curl -X POST "${{ secrets.DISCORD_WEBHOOK_URL }}" \
            -H "Content-Type: application/json" \
            -d '{"content":"❌ WishlistOps workflow failed. Check logs."}'
```

DO NOT:
- Use deprecated action versions
- Hardcode any secrets or API keys
- Skip error handling
- Use complex shell scripts inline (delegate to Python)
- Ignore rate limits or timeouts

VERIFICATION:
After creation, verify:
1. YAML syntax is valid
2. All secrets are referenced correctly
3. Timeouts are set appropriately
4. Artifacts are uploaded on both success and failure
5. Failure notifications are configured
```

**Expected Output:**
- File: `.github/workflows/wishlistops.yml` (150-200 lines)
- Fully functional GitHub Actions workflow
- Includes comments and error handling
- Ready for immediate use

**Testing Instructions:**
```bash
# Validate YAML syntax
yamllint .github/workflows/wishlistops.yml

# Lint GitHub Actions workflow
actionlint .github/workflows/wishlistops.yml

# Test locally (optional)
act -W .github/workflows/wishlistops.yml --list
```

**Success Criteria:**
- [ ] Workflow triggers on tag push
- [ ] Workflow can be manually dispatched
- [ ] All steps have timeout limits
- [ ] Secrets are properly referenced
- [ ] Artifacts upload on failure
- [ ] Linter shows no errors

---


### TASK 1.2: Python Orchestration Script

**File:** `wishlistops/main.py`

**Prompt for AI Agent:**

```
CONTEXT:
You are creating the main orchestration script for WishlistOps. This Python script is the "brain" that coordinates all automation tasks: parsing Git logs, calling AI APIs, filtering content, and sending Discord notifications.

ARCHITECTURE REFERENCE:
- See "Section 2: Detailed Component Architecture" in 04_WishlistOps_System_Architecture_Diagrams.md
- See "Data Flow Diagram" showing all processing steps
- See "Step-by-step workflow" in 05_WishlistOps_Revised_Architecture.md

SYSTEM FLOW:
1. Load configuration (config.json)
2. Parse Git log to extract commits
3. Classify commits (player-facing vs. internal)
4. Generate announcement text (Gemini 1.5 Pro)
5. Run anti-slop filter
6. Generate banner image (Gemini 2.5 Flash)
7. Composite game logo onto banner
8. Send to Discord for approval
9. Save state (state.json)

TECHNICAL REQUIREMENTS:
- Python 3.11+ with type hints
- Async/await for API calls
- Structured logging (JSON format)
- Error handling with retries
- Graceful degradation on API failures
- State management (idempotent operations)

DEPENDENCIES TO USE:
```python
# requirements.txt
requests>=2.31.0
Pillow>=10.0.0
GitPython>=3.1.40
python-dotenv>=1.0.0
pydantic>=2.5.0
aiohttp>=3.9.0
```

CODE ARCHITECTURE:
The wishlistops package structure:
```
wishlistops/
├── __init__.py
├── main.py                 # ← YOU ARE CREATING THIS
├── config_manager.py       # Configuration loader
├── git_parser.py          # Git operations
├── ai_client.py           # Gemini API wrapper
├── content_filter.py      # Anti-slop filter
├── image_compositor.py    # Logo compositing
├── discord_notifier.py    # Discord webhook
├── state_manager.py       # State persistence
└── models.py              # Pydantic models
```

MAIN.PY RESPONSIBILITIES:
1. Command-line argument parsing
2. Configuration loading
3. Logger initialization
4. Workflow orchestration
5. Error handling and recovery
6. State management
7. Exit code handling

ERROR HANDLING PHILOSOPHY:
- API failures: Retry with exponential backoff (3 attempts)
- Validation failures: Fail fast with clear error messages
- Partial failures: Continue with degraded functionality
- Network timeouts: Retry with circuit breaker pattern
- Always log the error before raising

LOGGING REQUIREMENTS:
- Use Python logging module
- JSON structured logs for machine parsing
- Log levels: DEBUG, INFO, WARNING, ERROR, CRITICAL
- Include timestamps, request IDs, and context
- Log all API calls (mask secrets)
- Create separate log file per run

QUALITY REQUIREMENTS:
- Type hints on ALL functions and methods
- Docstrings in Google style
- No print() statements (use logging)
- No global mutable state
- Pure functions where possible
- Dependency injection for testability

CODE TEMPLATE:
```python
"""
WishlistOps Main Orchestrator

This module coordinates the entire automation workflow from Git commits
to Discord approval notifications.

Architecture: See 04_WishlistOps_System_Architecture_Diagrams.md
Production fixes: See 05_WishlistOps_Revised_Architecture.md

Workflow Steps:
1. Parse Git commits since last run
2. Generate announcement text using AI
3. Filter content for quality (anti-slop)
4. Generate banner image
5. Composite game logo
6. Send to Discord for approval
7. Update state for next run

Error Handling:
- API failures retry with exponential backoff
- Partial failures continue with degraded functionality
- All errors logged with full context
"""

import argparse
import asyncio
import logging
import sys
from pathlib import Path
from typing import Optional

from .config_manager import load_config
from .models import Config, WorkflowState, AnnouncementDraft
from .git_parser import GitParser
from .ai_client import AIClient
from .content_filter import ContentFilter
from .image_compositor import ImageCompositor
from .discord_notifier import DiscordNotifier
from .state_manager import StateManager


# Configure structured JSON logging
logging.basicConfig(
    level=logging.INFO,
    format='{"timestamp":"%(asctime)s","level":"%(levelname)s","module":"%(name)s","message":"%(message)s"}',
    datefmt='%Y-%m-%dT%H:%M:%S'
)
logger = logging.getLogger(__name__)


class WishlistOpsOrchestrator:
    """
    Main orchestrator for WishlistOps automation workflow.
    
    This class coordinates all components to transform Git commits
    into Steam-ready announcements with human approval.
    
    Attributes:
        config: Validated configuration
        state: State manager for persistence
        git: Git operations handler
        ai: AI client for content generation
        filter: Content quality filter
        compositor: Image compositing handler
        notifier: Discord notification sender
    """
    
    def __init__(self, config_path: Path, dry_run: bool = False) -> None:
        """
        Initialize orchestrator with configuration.
        
        Args:
            config_path: Path to config.json file
            dry_run: If True, skip actual API calls
            
        Raises:
            FileNotFoundError: If config file doesn't exist
            ValidationError: If config is invalid
        """
        logger.info("Initializing WishlistOps orchestrator", extra={
            "config_path": str(config_path),
            "dry_run": dry_run
        })
        
        self.dry_run = dry_run
        self.config = load_config(config_path)
        self.state = StateManager(config_path.parent / "state.json")
        
        # Initialize all components
        self.git = GitParser(config_path.parent)
        self.ai = AIClient(
            api_key=self.config.google_ai_key,
            model_config=self.config.ai
        )
        self.filter = ContentFilter(self.config.voice)
        self.compositor = ImageCompositor(self.config.branding)
        self.notifier = DiscordNotifier(
            webhook_url=self.config.discord_webhook_url,
            dry_run=dry_run
        )
        
        logger.info("Orchestrator initialized successfully")
    
    async def run(self) -> WorkflowState:
        """
        Execute the complete automation workflow.
        
        This is the main entry point that orchestrates all steps:
        1. Parse commits
        2. Generate content
        3. Filter quality
        4. Send for approval
        5. Update state
        
        Returns:
            WorkflowState with execution results
            
        Raises:
            WorkflowError: If critical step fails
        """
        logger.info("="*60)
        logger.info("Starting WishlistOps workflow execution")
        logger.info("="*60)
        
        try:
            # Step 1: Check if we should run (rate limiting)
            if not self._should_run():
                logger.info("Skipping run due to rate limits")
                return WorkflowState(status="skipped", reason="rate_limit")
            
            # Step 2: Parse Git commits
            commits = await self._parse_commits()
            if not commits:
                logger.info("No new commits found, ending run")
                return WorkflowState(status="skipped", reason="no_commits")
            
            logger.info(f"Found {len(commits)} commits to process")
            
            # Step 3: Generate announcement text
            draft = await self._generate_announcement(commits)
            logger.info(f"Generated announcement: {draft.title}")
            
            # Step 4: Filter content for quality
            draft = await self._filter_content(draft)
            logger.info("Content passed quality filter")
            
            # Step 5: Generate and composite banner
            if self.config.branding:
                draft = await self._create_banner(draft)
                logger.info("Banner generated successfully")
            
            # Step 6: Send to Discord for approval
            await self._send_for_approval(draft)
            logger.info("Sent to Discord for approval")
            
            # Step 7: Update state
            self.state.update_last_run(draft)
            logger.info("State updated successfully")
            
            logger.info("="*60)
            logger.info("✅ Workflow completed successfully")
            logger.info("="*60)
            
            return WorkflowState(status="success", draft=draft)
            
        except Exception as e:
            logger.error(f"❌ Workflow failed: {e}", exc_info=True)
            await self.notifier.send_error(str(e))
            raise
    
    def _should_run(self) -> bool:
        """
        Check if workflow should run based on rate limits.
        
        Returns:
            True if OK to run, False if rate limited
        """
        last_post = self.state.get_last_post_date()
        if not last_post:
            return True
        
        days_since = (datetime.now() - last_post).days
        min_days = self.config.automation.min_days_between_posts
        
        if days_since < min_days:
            logger.warning(f"Rate limit: Only {days_since} days since last post (min: {min_days})")
            return False
        
        return True
    
    async def _parse_commits(self) -> list:
        """Parse Git commits since last run."""
        last_tag = self.state.get_last_tag()
        commits = self.git.get_commits_since(last_tag)
        
        # Filter to player-facing changes only
        player_facing = [c for c in commits if self.git.is_player_facing(c)]
        
        logger.info(f"Parsed {len(commits)} commits, {len(player_facing)} player-facing")
        return player_facing
    
    async def _generate_announcement(self, commits: list) -> AnnouncementDraft:
        """Generate announcement text using AI."""
        logger.info("Generating announcement with AI")
        
        # Build context from config
        context = self._build_ai_context(commits)
        
        # Call AI API
        result = await self.ai.generate_text(
            prompt=context,
            temperature=self.config.ai.temperature
        )
        
        return AnnouncementDraft(
            title=result['title'],
            body=result['body'],
            created_at=datetime.now().isoformat()
        )
    
    async def _filter_content(self, draft: AnnouncementDraft) -> AnnouncementDraft:
        """Apply anti-slop filter to content."""
        logger.info("Filtering content for quality")
        
        issues = self.filter.check(draft.body)
        
        if issues:
            logger.warning(f"Found {len(issues)} quality issues: {issues}")
            # Regenerate with stricter prompt
            draft = await self._regenerate_with_fixes(draft, issues)
        
        return draft
    
    async def _create_banner(self, draft: AnnouncementDraft) -> AnnouncementDraft:
        """Generate and composite banner image."""
        logger.info("Generating banner image")
        
        # Generate base image with AI
        base_image = await self.ai.generate_image(
            prompt=self._build_image_prompt(draft),
            aspect_ratio="16:9"
        )
        
        # Composite logo
        final_image = self.compositor.add_logo(
            base_image,
            logo_path=self.config.branding.logo_path
        )
        
        # Save and get URL
        banner_url = self._save_banner(final_image)
        draft.banner_url = banner_url
        
        return draft
    
    async def _send_for_approval(self, draft: AnnouncementDraft) -> None:
        """Send draft to Discord for human approval."""
        logger.info("Sending to Discord for approval")
        
        await self.notifier.send_approval_request(
            title=draft.title,
            body=draft.body,
            banner_url=draft.banner_url
        )
    
    def _build_ai_context(self, commits: list) -> str:
        """Build AI prompt context from commits and config."""
        # Implementation details...
        pass
    
    def _build_image_prompt(self, draft: AnnouncementDraft) -> str:
        """Build image generation prompt."""
        # Implementation details...
        pass


def main() -> None:
    """Main entry point for CLI."""
    parser = argparse.ArgumentParser(
        description="WishlistOps - Automate Steam marketing for indie games",
        epilog="See documentation at: https://github.com/your-org/wishlistops"
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=Path("wishlistops/config.json"),
        help="Path to configuration file"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Run without making actual API calls"
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Enable debug logging"
    )
    
    args = parser.parse_args()
    
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    try:
        orchestrator = WishlistOpsOrchestrator(args.config, dry_run=args.dry_run)
        result = asyncio.run(orchestrator.run())
        
        if result.status == "success":
            logger.info("✅ Workflow completed successfully")
            sys.exit(0)
        else:
            logger.warning(f"⚠️ Workflow ended with status: {result.status}")
            sys.exit(1)
            
    except Exception as e:
        logger.error(f"❌ Fatal error: {e}", exc_info=True)
        sys.exit(2)


if __name__ == "__main__":
    main()
```

IMPLEMENTATION CHECKLIST:
- [ ] Create wishlistops/main.py with WishlistOpsOrchestrator class
- [ ] Implement __init__ with dependency injection
- [ ] Implement run() method with complete workflow
- [ ] Implement all private helper methods
- [ ] Add comprehensive error handling
- [ ] Add structured logging to all methods
- [ ] Create CLI with argparse
- [ ] Add type hints to everything
- [ ] Write docstrings for all public methods

TESTING REQUIREMENTS:
Create tests/test_main.py with:
```python
import pytest
from pathlib import Path
from wishlistops.main import WishlistOpsOrchestrator

def test_orchestrator_initializes():
    """Test orchestrator can be created."""
    orch = WishlistOpsOrchestrator(Path("wishlistops/config.json"))
    assert orch.config is not None

@pytest.mark.asyncio
async def test_workflow_skips_on_no_commits():
    """Test workflow skips when no commits."""
    # Mock git parser to return empty list
    # Run workflow
    # Assert status is "skipped"
```

VERIFICATION:
- [ ] Passes mypy --strict
- [ ] Passes pylint (score >9.0)
- [ ] Passes black formatting check
- [ ] All methods have docstrings
- [ ] All imports are used
- [ ] No print() statements
- [ ] Structured logging throughout
```

**Expected Output:**
- File: `wishlistops/main.py` (400-500 lines)
- Complete orchestrator implementation
- CLI entry point
- Ready for testing

**Success Criteria:**
- [ ] Can be imported without errors
- [ ] CLI shows help message
- [ ] Type checking passes
- [ ] Linting passes
- [ ] All docstrings present


### TASK 1.3: Configuration Schema & Validation

**Files:** `wishlistops/models.py` + `wishlistops/config_manager.py`

**Prompt for AI Agent:**

```
CONTEXT:
You are creating the configuration management system for WishlistOps. This handles loading, validating, and providing type-safe access to user configuration.

ARCHITECTURE REFERENCE:
- See "Section 10: Database Schema & State Management" in 04_WishlistOps_System_Architecture_Diagrams.md
- See "Configuration Schema (config.json)" showing complete JSON structure
- Users configure via web dashboard OR by editing JSON directly

CONFIGURATION STRUCTURE:
The config.json contains:
1. Steam settings (app_id, app_name)
2. Branding (art_style, colors, logo)
3. Voice/tone (personality, avoid_phrases)
4. Automation rules (triggers, rate limits)
5. AI settings (models, temperature, retries)

VALIDATION PHILOSOPHY:
- Fail fast with clear error messages
- Use Pydantic for automatic validation
- Provide helpful suggestions when validation fails
- Support environment variable overrides
- Create sensible defaults

DATA MODEL DESIGN:
Use Pydantic BaseModel for:
- Automatic JSON validation
- Type safety throughout codebase
- IDE autocomplete support
- Clear error messages
- Easy serialization

IMPLEMENTATION:

FILE 1: wishlistops/models.py
```python
"""
Data models for WishlistOps configuration and runtime state.

All models use Pydantic for validation and type safety.
See: 04_WishlistOps_System_Architecture_Diagrams.md Section 10
"""

from datetime import datetime
from enum import Enum
from typing import Optional
from pydantic import BaseModel, Field, field_validator, model_validator


class LogoPosition(str, Enum):
    """Valid logo positions on generated banners."""
    TOP_LEFT = "top-left"
    TOP_RIGHT = "top-right"
    CENTER = "center"
    BOTTOM_LEFT = "bottom-left"
    BOTTOM_RIGHT = "bottom-right"


class SteamConfig(BaseModel):
    """Steam platform configuration."""
    
    app_id: str = Field(
        ...,
        description="Steam Application ID (6-7 digits)",
        pattern=r"^\d{6,7}$",
        examples=["480", "413150"]
    )
    app_name: str = Field(
        ...,
        description="Game name as displayed on Steam",
        min_length=1,
        max_length=255
    )
    
    @field_validator('app_id')
    @classmethod
    def validate_app_id(cls, v: str) -> str:
        """Validate Steam App ID format and reasonableness."""
        if not v.isdigit():
            raise ValueError(
                f"Steam app_id must be numeric, got: '{v}'\n"
                f"Find your App ID at: https://partner.steamgames.com/"
            )
        if len(v) < 3:
            raise ValueError(
                f"Steam app_id seems too short: '{v}'\n"
                f"Most Steam games have 6-7 digit IDs"
            )
        return v


class BrandingConfig(BaseModel):
    """Visual branding and style configuration."""
    
    art_style: str = Field(
        ...,
        description="Art style keywords for AI image generation",
        min_length=10,
        max_length=500,
        examples=["pixel art fantasy", "low poly sci-fi", "hand-drawn cartoon"]
    )
    color_palette: list[str] = Field(
        default_factory=list,
        description="Hex color codes for brand consistency",
        examples=[["#FF6B6B", "#4ECDC4", "#FFE66D"]]
    )
    logo_position: LogoPosition = Field(
        default=LogoPosition.TOP_RIGHT,
        description="Where to place logo on generated banners"
    )
    logo_size_percent: int = Field(
        default=25,
        ge=10,
        le=50,
        description="Logo size as percentage of banner width"
    )
    logo_path: Optional[str] = Field(
        default="wishlistops/assets/logo.png",
        description="Path to game logo (transparent PNG recommended)"
    )
    
    @field_validator('color_palette')
    @classmethod
    def validate_hex_colors(cls, v: list[str]) -> list[str]:
        """Validate all colors are proper hex codes."""
        if not v:
            return v
        
        for color in v:
            if not color.startswith('#'):
                raise ValueError(
                    f"Color must start with #, got: '{color}'\n"
                    f"Example: #FF6B6B"
                )
            if len(color) != 7:
                raise ValueError(
                    f"Color must be 7 characters (#RRGGBB), got: '{color}'"
                )
            try:
                int(color[1:], 16)
            except ValueError:
                raise ValueError(
                    f"Invalid hex color: '{color}'\n"
                    f"Use format: #RRGGBB (e.g., #FF6B6B)"
                )
        return v


class VoiceConfig(BaseModel):
    """Writing voice and tone configuration."""
    
    tone: str = Field(
        default="casual and excited",
        description="Overall tone of announcements",
        examples=["casual and excited", "professional", "humorous"]
    )
    personality: str = Field(
        default="friendly indie developer",
        description="Writer persona for AI to adopt",
        examples=["friendly indie developer", "veteran game designer", "enthusiastic creator"]
    )
    avoid_phrases: list[str] = Field(
        default_factory=lambda: ["monetization", "grind", "lootbox"],
        description="Words/phrases to avoid in announcements"
    )
    
    @field_validator('avoid_phrases')
    @classmethod
    def lowercase_phrases(cls, v: list[str]) -> list[str]:
        """Convert all avoid phrases to lowercase for matching."""
        return [phrase.lower() for phrase in v]


class AutomationConfig(BaseModel):
    """Automation behavior and scheduling configuration."""
    
    enabled: bool = Field(
        default=True,
        description="Master switch for automation"
    )
    trigger_on_tags: bool = Field(
        default=True,
        description="Trigger on Git tag pushes"
    )
    schedule: Optional[str] = Field(
        default=None,
        description="Cron schedule for automatic runs",
        examples=["0 12 * * 1", "0 */6 * * *"]
    )
    min_days_between_posts: int = Field(
        default=7,
        ge=1,
        le=30,
        description="Minimum days between Steam posts (rate limiting)"
    )
    require_manual_approval: bool = Field(
        default=True,
        description="Require Discord approval before posting"
    )


class AIConfig(BaseModel):
    """AI model configuration and parameters."""
    
    model_text: str = Field(
        default="gemini-1.5-pro",
        description="Model for text generation"
    )
    model_image: str = Field(
        default="gemini-2.5-flash-image",
        description="Model for image generation"
    )
    temperature: float = Field(
        default=0.7,
        ge=0.0,
        le=1.0,
        description="Creativity level (0=deterministic, 1=creative)"
    )
    max_retries: int = Field(
        default=3,
        ge=1,
        le=5,
        description="Max API retry attempts on failure"
    )


class Config(BaseModel):
    """
    Main configuration model for WishlistOps.
    
    This is the root configuration object loaded from config.json.
    Secrets (API keys) are loaded from environment variables.
    """
    
    version: str = Field(default="1.0")
    steam: SteamConfig
    branding: BrandingConfig
    voice: VoiceConfig = Field(default_factory=VoiceConfig)
    automation: AutomationConfig = Field(default_factory=AutomationConfig)
    ai: AIConfig = Field(default_factory=AIConfig)
    
    # Runtime secrets (not in config.json, from environment)
    steam_api_key: Optional[str] = Field(default=None, exclude=True)
    google_ai_key: Optional[str] = Field(default=None, exclude=True)
    discord_webhook_url: Optional[str] = Field(default=None, exclude=True)
    
    model_config = {
        "json_schema_extra": {
            "example": {
                "version": "1.0",
                "steam": {
                    "app_id": "480",
                    "app_name": "Spacewar"
                },
                "branding": {
                    "art_style": "retro arcade space shooter",
                    "color_palette": ["#000000", "#FFFFFF"],
                    "logo_position": "top-right"
                }
            }
        }
    }


# Runtime state models

class AnnouncementDraft(BaseModel):
    """Generated announcement draft awaiting approval."""
    
    title: str = Field(..., max_length=255)
    body: str = Field(..., min_length=50)
    banner_url: Optional[str] = None
    created_at: str
    approved: bool = False
    approved_at: Optional[str] = None


class WorkflowState(BaseModel):
    """State of a workflow execution."""
    
    status: str = Field(..., pattern="^(success|failed|skipped)$")
    draft: Optional[AnnouncementDraft] = None
    reason: Optional[str] = None
    error: Optional[str] = None
    timestamp: str = Field(default_factory=lambda: datetime.now().isoformat())


class StateSnapshot(BaseModel):
    """Persistent state between workflow runs."""
    
    last_run_timestamp: Optional[str] = None
    last_tag: Optional[str] = None
    last_post_date: Optional[str] = None
    total_runs: int = 0
    successful_runs: int = 0
    failed_runs: int = 0
```

FILE 2: wishlistops/config_manager.py
```python
"""
Configuration management for WishlistOps.

Handles loading, validating, and providing access to configuration
with helpful error messages.
"""

import json
import os
from pathlib import Path
from typing import Optional

from .models import Config


class ConfigurationError(Exception):
    """Raised when configuration is invalid."""
    pass


class ConfigManager:
    """Manages loading and validating configuration."""
    
    @staticmethod
    def load_config(config_path: Path) -> Config:
        """
        Load and validate configuration from file and environment.
        
        Args:
            config_path: Path to config.json file
            
        Returns:
            Validated Config object with secrets from environment
            
        Raises:
            ConfigurationError: If config is invalid or incomplete
            FileNotFoundError: If config file doesn't exist
        """
        # Check file exists
        if not config_path.exists():
            raise FileNotFoundError(
                f"Configuration file not found: {config_path}\n\n"
                f"Create one with:\n"
                f"  python -m wishlistops.config_manager --create-default\n\n"
                f"Or see example at:\n"
                f"  https://github.com/your-org/wishlistops/blob/main/config.example.json"
            )
        
        # Load JSON
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except json.JSONDecodeError as e:
            raise ConfigurationError(
                f"Invalid JSON syntax in {config_path}:\n"
                f"  Line {e.lineno}, Column {e.colno}\n"
                f"  Error: {e.msg}\n\n"
                f"Tip: Validate JSON at https://jsonlint.com/"
            ) from e
        
        # Load secrets from environment
        data['steam_api_key'] = os.getenv('STEAM_API_KEY')
        data['google_ai_key'] = os.getenv('GOOGLE_AI_KEY')
        data['discord_webhook_url'] = os.getenv('DISCORD_WEBHOOK_URL')
        
        # Validate with Pydantic
        try:
            config = Config(**data)
        except Exception as e:
            raise ConfigurationError(
                f"Configuration validation failed:\n"
                f"{str(e)}\n\n"
                f"Check your config.json file at: {config_path}"
            ) from e
        
        # Validate required secrets
        ConfigManager._validate_secrets(config)
        
        return config
    
    @staticmethod
    def _validate_secrets(config: Config) -> None:
        """Validate required environment variables are set."""
        missing = []
        
        if not config.steam_api_key:
            missing.append("STEAM_API_KEY")
        if not config.google_ai_key:
            missing.append("GOOGLE_AI_KEY")
        if config.automation.require_manual_approval and not config.discord_webhook_url:
            missing.append("DISCORD_WEBHOOK_URL")
        
        if missing:
            raise ConfigurationError(
                f"Missing required environment variables:\n" +
                "\n".join(f"  - {var}" for var in missing) +
                "\n\nSet them with:\n" +
                "\n".join(f"  export {var}='your-key-here'" for var in missing) +
                "\n\nOr add to GitHub Secrets if using GitHub Actions."
            )
    
    @staticmethod
    def create_default_config(config_path: Path) -> None:
        """
        Create a default configuration file with placeholders.
        
        Args:
            config_path: Where to create config.json
        """
        default = {
            "version": "1.0",
            "steam": {
                "app_id": "REPLACE_WITH_YOUR_STEAM_APP_ID",
                "app_name": "Your Game Name Here"
            },
            "branding": {
                "art_style": "describe your game's visual style (e.g., pixel art fantasy)",
                "color_palette": ["#FF6B6B", "#4ECDC4", "#FFE66D"],
                "logo_position": "top-right",
                "logo_size_percent": 25,
                "logo_path": "wishlistops/assets/logo.png"
            },
            "voice": {
                "tone": "casual and excited",
                "personality": "friendly indie developer",
                "avoid_phrases": ["monetization", "grind", "lootbox", "pay-to-win"]
            },
            "automation": {
                "enabled": True,
                "trigger_on_tags": True,
                "schedule": None,
                "min_days_between_posts": 7,
                "require_manual_approval": True
            },
            "ai": {
                "model_text": "gemini-1.5-pro",
                "model_image": "gemini-2.5-flash-image",
                "temperature": 0.7,
                "max_retries": 3
            }
        }
        
        config_path.parent.mkdir(parents=True, exist_ok=True)
        with open(config_path, 'w', encoding='utf-8') as f:
            json.dump(default, f, indent=2)
        
        print(f"✅ Created default configuration at: {config_path}")
        print("\n📝 Next steps:")
        print(f"1. Edit {config_path}")
        print("2. Replace REPLACE_WITH_YOUR_STEAM_APP_ID with your actual Steam App ID")
        print("3. Customize art_style to match your game")
        print("4. Set environment variables for API keys")


# Convenience function for imports
def load_config(config_path: Path) -> Config:
    """Load configuration (convenience wrapper)."""
    return ConfigManager.load_config(config_path)


# CLI for creating default config
if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="WishlistOps Configuration Manager")
    parser.add_argument(
        "--create-default",
        action="store_true",
        help="Create default config.json"
    )
    parser.add_argument(
        "--path",
        type=Path,
        default=Path("wishlistops/config.json"),
        help="Path for config file"
    )
    
    args = parser.parse_args()
    
    if args.create_default:
        ConfigManager.create_default_config(args.path)
    else:
        try:
            config = ConfigManager.load_config(args.path)
            print(f"✅ Configuration valid: {args.path}")
            print(f"Steam App: {config.steam.app_name} ({config.steam.app_id})")
        except Exception as e:
            print(f"❌ Configuration error: {e}")
            exit(1)
```

QUALITY REQUIREMENTS:
- All Pydantic models have descriptions
- All validators have helpful error messages
- Type hints on everything
- Example values in field definitions
- CLI for common operations

TESTING:
Create tests/test_config.py:
```python
import pytest
from pathlib import Path
from pydantic import ValidationError
from wishlistops.config_manager import ConfigManager
from wishlistops.models import Config

def test_valid_config_loads():
    """Test that a valid config loads successfully."""
    config = ConfigManager.load_config(Path("tests/fixtures/valid_config.json"))
    assert config.steam.app_id == "480"

def test_invalid_app_id_raises_error():
    """Test that invalid Steam App ID is rejected."""
    with pytest.raises(ValidationError):
        Config(steam={"app_id": "abc", "app_name": "Test"})

def test_invalid_hex_color_raises_error():
    """Test that invalid hex colors are rejected."""
    with pytest.raises(ValidationError):
        Config(
            steam={"app_id": "480", "app_name": "Test"},
            branding={"art_style": "test", "color_palette": ["GGGGGG"]}
        )

def test_environment_variables_loaded():
    """Test that environment variables override JSON."""
    os.environ['STEAM_API_KEY'] = 'test-key'
    config = ConfigManager.load_config(Path("tests/fixtures/valid_config.json"))
    assert config.steam_api_key == 'test-key'
```

OUTPUT FILES:
1. wishlistops/models.py (200-250 lines)
2. wishlistops/config_manager.py (150-200 lines)
3. tests/test_config.py (100-150 lines)

SUCCESS CRITERIA:
- [ ] Config validates all fields
- [ ] Error messages are helpful
- [ ] Environment variables work
- [ ] Default config can be created
- [ ] All tests pass
- [ ] Passes mypy --strict
```

**Expected Output:**
- Complete configuration system
- Type-safe models
- Helpful validation errors
- CLI for config management

**Testing:**
```bash
# Create default config
python -m wishlistops.config_manager --create-default

# Validate existing config
python -m wishlistops.config_manager --path wishlistops/config.json

# Run tests
pytest tests/test_config.py -v
```

---

## 📝 TASK 1 COMPLETION CHECKLIST

After Task 1, you should have:

**Files Created:**
- [ ] `.github/workflows/wishlistops.yml` (GitHub Action)
- [ ] `wishlistops/main.py` (Orchestrator)
- [ ] `wishlistops/models.py` (Data models)
- [ ] `wishlistops/config_manager.py` (Config loader)
- [ ] `wishlistops/__init__.py` (Package init)
- [ ] `requirements.txt` (Dependencies)
- [ ] `tests/test_config.py` (Config tests)

**Integration Tests:**
```bash
# 1. Validate GitHub Action workflow
actionlint .github/workflows/wishlistops.yml

# 2. Validate Python imports work
python -c "from wishlistops.main import WishlistOpsOrchestrator"

# 3. Validate config system
python -m wishlistops.config_manager --create-default
python -m wishlistops.config_manager --path wishlistops/config.json

# 4. Run type checking
mypy wishlistops/ --strict

# 5. Run linting
pylint wishlistops/

# 6. Run tests
pytest tests/ -v
```

**Next Steps:**
After Task 1 is complete, move to creating the remaining build plan files for Tasks 2-4.

---
