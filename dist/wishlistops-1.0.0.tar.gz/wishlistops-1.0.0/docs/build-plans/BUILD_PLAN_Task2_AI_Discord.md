﻿# WishlistOps Build Plan - Task 2: AI Integration & Discord Approval
## Day 2-3: Core Processing Components

---

## 🎯 TASK 2 OVERVIEW

**Goal:** Implement AI content generation, Discord notifications, and supporting utilities.

**Timeline:** Day 2-3 (2 days)

**Dependencies:** Task 1 complete (main.py, models.py, config_manager.py)

**Components to Build:**
1. Git commit parser
2. Gemini AI client (text + image)
3. Discord notifier with approval buttons
4. State manager for persistence

**Success Criteria:**
- [ ] Can parse Git commits and identify player-facing changes
- [ ] Can generate text with Gemini 1.5 Pro
- [ ] Can generate images with Gemini 2.5 Flash
- [ ] Can send Discord notifications with preview
- [ ] State persists between runs

---

## 🔧 TASK 2.1: Git Commit Parser

**File:** `wishlistops/git_parser.py`

**Prompt for AI Agent:**

```
CONTEXT:
You are creating the Git commit parser for WishlistOps. This component extracts commit history, analyzes commit messages, and identifies player-facing changes vs. internal changes.

ARCHITECTURE REFERENCE:
- See "Section 3: Data Flow Diagram" in 04_WishlistOps_System_Architecture_Diagrams.md
- See "Step 1: Parse Git Log" showing commit classification logic
- Must distinguish between player-facing features and internal refactors

WHY THIS MATTERS:
Players don't care about "refactored memory allocation" or "updated CI pipeline".
They care about "added double-jump mechanic" or "fixed boss AI bug".
Our parser must filter commits to only include player-relevant changes.

CLASSIFICATION STRATEGY:
Player-facing commits contain keywords like:
- Feature: "add", "new", "implement" + gameplay terms
- Bugfix: "fix", "resolve", "patch" + user-visible bugs
- Content: "added", "updated" + art/audio/level terms

Internal commits contain:
- "refactor", "optimize", "cleanup"
- "update dependencies", "CI", "tests"
- "docs", "readme", "comments"

TECHNICAL REQUIREMENTS:
- Use GitPython library
- Handle missing Git repository gracefully
- Support fetching commits between tags
- Support fetching commits since date
- Extract: message, author, date, files changed
- Classify: player-facing vs internal

IMPLEMENTATION:

```python
"""
Git operations and commit parsing for WishlistOps.

Parses Git history to identify player-facing changes that should be
announced to the Steam community.

See: 04_WishlistOps_System_Architecture_Diagrams.md Section 3
"""

import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Optional

import git
from git.exc import GitCommandError, InvalidGitRepositoryError


@dataclass
class Commit:
    """Represents a Git commit with metadata."""
    
    sha: str
    message: str
    author: str
    date: datetime
    files_changed: list[str]
    is_player_facing: bool = False


class GitParser:
    """
    Parse Git commits and classify for announcement generation.
    
    Attributes:
        repo: GitPython Repository object
        repo_path: Path to the Git repository
    """
    
    # Keywords that indicate player-facing changes
    PLAYER_FACING_KEYWORDS = [
        # Features
        r'\b(add|new|implement|introduce)\b.*\b(feature|mechanic|ability|weapon|enemy|level|boss|character|item|power|skill)\b',
        r'\b(add|new)\b.*\b(gameplay|combat|system|mode)\b',
        
        # Bugfixes (user-visible)
        r'\bfix\b.*\b(bug|crash|issue|problem|glitch)\b',
        r'\bfix\b.*\b(player|enemy|boss|level|animation|sound|ui|menu)\b',
        r'\bresolve\b.*\b(softlock|stuck|freeze)\b',
        
        # Content
        r'\b(add|update|improve|enhance)\b.*\b(art|sprite|texture|model|animation|sound|music|voice|dialog|dialogue)\b',
        r'\b(new|added)\b.*\b(map|level|area|world|zone|stage)\b',
        
        # Balance/Polish
        r'\bbalance|rebalance|tweak|adjust\b.*\b(damage|health|difficulty|enemy|boss)\b',
        r'\bimprov(e|ed)\b.*\b(performance|framerate|loading)\b',
        r'\boptimiz(e|ed)\b.*\b(performance|framerate)\b',
    ]
    
    # Keywords that indicate internal changes (NOT player-facing)
    INTERNAL_KEYWORDS = [
        r'\brefactor',
        r'\bcleanup',
        r'\bupdate\b.*\b(dependencies|ci|pipeline|workflow)\b',
        r'\b(add|update|fix)\b.*\b(test|unit test|integration test)\b',
        r'\bdocs?\b',
        r'\breadme',
        r'\bcomment',
        r'\btypo',
        r'\bformat|formatting|lint',
        r'\bversion bump',
        r'\bmerge (branch|pull request)',
    ]
    
    def __init__(self, repo_path: Path) -> None:
        """
        Initialize Git parser.
        
        Args:
            repo_path: Path to Git repository
            
        Raises:
            InvalidGitRepositoryError: If path is not a Git repo
        """
        try:
            self.repo = git.Repo(repo_path, search_parent_directories=True)
            self.repo_path = Path(self.repo.working_dir)
        except InvalidGitRepositoryError as e:
            raise InvalidGitRepositoryError(
                f"Not a Git repository: {repo_path}\n"
                f"Initialize with: git init"
            ) from e
    
    def get_commits_since_tag(self, tag: Optional[str] = None) -> list[Commit]:
        """
        Get all commits since a specific tag.
        
        Args:
            tag: Git tag to start from (e.g., 'v1.0.0'). If None, returns all commits.
            
        Returns:
            List of Commit objects
            
        Raises:
            GitCommandError: If tag doesn't exist
        """
        try:
            if tag:
                # Get commits between tag and HEAD
                commit_range = f"{tag}..HEAD"
                commits_iter = self.repo.iter_commits(commit_range)
            else:
                # Get all commits
                commits_iter = self.repo.iter_commits('HEAD')
            
            commits = []
            for git_commit in commits_iter:
                commit = self._parse_commit(git_commit)
                commits.append(commit)
            
            return commits
            
        except GitCommandError as e:
            if tag:
                raise GitCommandError(
                    f"Tag not found: {tag}\n"
                    f"Available tags: {', '.join(self.get_tags())}"
                ) from e
            raise
    
    def get_commits_since_date(self, since: datetime) -> list[Commit]:
        """
        Get all commits since a specific date.
        
        Args:
            since: Date to start from
            
        Returns:
            List of Commit objects
        """
        commits_iter = self.repo.iter_commits('HEAD', since=since)
        return [self._parse_commit(c) for c in commits_iter]
    
    def get_latest_tag(self) -> Optional[str]:
        """
        Get the most recent Git tag.
        
        Returns:
            Tag name or None if no tags exist
        """
        try:
            tags = sorted(self.repo.tags, key=lambda t: t.commit.committed_datetime, reverse=True)
            return tags[0].name if tags else None
        except:
            return None
    
    def get_tags(self) -> list[str]:
        """Get all Git tags."""
        return [tag.name for tag in self.repo.tags]
    
    def _parse_commit(self, git_commit) -> Commit:
        """
        Parse a GitPython commit into our Commit dataclass.
        
        Args:
            git_commit: GitPython Commit object
            
        Returns:
            Parsed Commit with classification
        """
        message = git_commit.message.strip()
        files_changed = [item.a_path for item in git_commit.diff(git_commit.parents[0] if git_commit.parents else None)]
        
        commit = Commit(
            sha=git_commit.hexsha[:8],  # Short SHA
            message=message,
            author=git_commit.author.name,
            date=datetime.fromtimestamp(git_commit.committed_date),
            files_changed=files_changed,
            is_player_facing=self._is_player_facing(message, files_changed)
        )
        
        return commit
    
    def _is_player_facing(self, message: str, files_changed: list[str]) -> bool:
        """
        Determine if a commit is player-facing.
        
        Args:
            message: Commit message
            files_changed: List of changed file paths
            
        Returns:
            True if player-facing, False if internal
        """
        message_lower = message.lower()
        
        # Check internal keywords first (higher priority)
        for pattern in self.INTERNAL_KEYWORDS:
            if re.search(pattern, message_lower, re.IGNORECASE):
                return False
        
        # Check player-facing keywords
        for pattern in self.PLAYER_FACING_KEYWORDS:
            if re.search(pattern, message_lower, re.IGNORECASE):
                return True
        
        # Check file paths for clues
        player_facing_paths = ['assets/', 'content/', 'levels/', 'scenes/']
        internal_paths = ['tests/', 'docs/', '.github/', 'ci/']
        
        for file_path in files_changed:
            for path in internal_paths:
                if path in file_path:
                    return False
            for path in player_facing_paths:
                if path in file_path:
                    return True
        
        # Default: assume internal if we can't determine
        return False
    
    def get_player_facing_commits(self, since_tag: Optional[str] = None) -> list[Commit]:
        """
        Get only player-facing commits since a tag.
        
        This is a convenience method that filters commits.
        
        Args:
            since_tag: Tag to start from
            
        Returns:
            List of player-facing commits only
        """
        all_commits = self.get_commits_since_tag(since_tag)
        return [c for c in all_commits if c.is_player_facing]


# Convenience functions for backward compatibility
def get_commits_since(repo_path: Path, tag: Optional[str] = None) -> list[Commit]:
    """Get commits since tag (convenience function)."""
    parser = GitParser(repo_path)
    return parser.get_commits_since_tag(tag)
```

TESTING:
Create tests/test_git_parser.py:
```python
import pytest
from pathlib import Path
from wishlistops.git_parser import GitParser, Commit

def test_parser_initializes():
    """Test parser can be created from valid repo."""
    parser = GitParser(Path("."))
    assert parser.repo is not None

def test_classify_player_facing_feature():
    """Test classification of player-facing feature."""
    parser = GitParser(Path("."))
    assert parser._is_player_facing("Add new double jump mechanic", []) == True

def test_classify_internal_refactor():
    """Test classification of internal change."""
    parser = GitParser(Path("."))
    assert parser._is_player_facing("Refactor memory management", []) == False

def test_classify_player_facing_bugfix():
    """Test classification of user-visible bugfix."""
    parser = GitParser(Path("."))
    assert parser._is_player_facing("Fix boss AI getting stuck", []) == True

def test_classify_internal_test():
    """Test classification of test changes."""
    parser = GitParser(Path("."))
    assert parser._is_player_facing("Add unit tests for parser", []) == False
```

QUALITY CHECKLIST:
- [ ] Uses GitPython correctly
- [ ] Handles missing repo gracefully
- [ ] Classification logic is comprehensive
- [ ] Regex patterns are case-insensitive
- [ ] Returns structured Commit objects
- [ ] All methods have docstrings
- [ ] Type hints on everything

OUTPUT:
- File: wishlistops/git_parser.py (250-300 lines)
- File: tests/test_git_parser.py (100-150 lines)
```

**Expected Output:**
- Complete Git parser with smart classification
- ~85% accuracy on player-facing detection
- Ready for integration with main.py

**Testing:**
```bash
# Test on real repo
python -c "from wishlistops.git_parser import GitParser; from pathlib import Path; parser = GitParser(Path('.')); commits = parser.get_player_facing_commits(); print(f'Found {len(commits)} player-facing commits')"

# Run unit tests
pytest tests/test_git_parser.py -v
```

**Success Criteria:**
- [ ] Can parse real Git repository
- [ ] Correctly classifies commits
- [ ] Handles edge cases (no tags, no commits)
- [ ] All tests pass

---


### TASK 2.2: Gemini AI Client (Text + Image Generation)

**File:** `wishlistops/ai_client.py`

**Prompt for AI Agent:**

```
CONTEXT:
You are creating the AI client for WishlistOps that interfaces with Google's Gemini API for both text and image generation. This is the core content generation engine that transforms Git commits into Steam announcements.

ARCHITECTURE REFERENCE:
- See "Section 2: AI/ML Layer" in 04_WishlistOps_System_Architecture_Diagrams.md
- See "Section 11: API Integration Specifications" for Gemini API details
- See "Fix #3: Simplified Onboarding" in 05_WishlistOps_Revised_Architecture.md

WHY THIS MATTERS:
This is the heart of WishlistOps. The quality of AI-generated content directly impacts:
- Developer trust in the tool
- Steam community perception
- Conversion rate from wishlist to purchase
- Poor generation = developers abandon the tool

GEMINI API OVERVIEW:
- Gemini 1.5 Pro: Text generation with 2M token context
- Gemini 2.5 Flash Image: Image generation with text-aware capabilities
- Both support system instructions for persona/tone
- Rate limits: 60 requests/minute (free tier)
- Authentication: API key via header

TECHNICAL REQUIREMENTS:
- Async/await for all API calls
- Retry logic with exponential backoff
- Context window management (2M tokens)
- Structured response parsing
- Error handling with helpful messages
- Request/response logging (without secrets)
- Timeout handling (30s default)

PROMPT ENGINEERING STRATEGY:
For text generation:
1. System instruction: Define persona and constraints
2. Context: Load game lore, previous posts, style guide
3. Input: Commits with classification
4. Output: Structured response (title + body)

For image generation:
1. Include reference screenshot (base64)
2. Art style keywords from config
3. Color palette constraints
4. Text placement instructions
5. Output: Base64 encoded PNG

IMPLEMENTATION:

```python
"""
Gemini AI client for content generation.

Handles both text generation (announcements) and image generation (banners)
using Google's Gemini API.

Architecture: See 04_WishlistOps_System_Architecture_Diagrams.md Section 2
API Specs: See Section 11 for detailed API integration
"""

import asyncio
import base64
import logging
from dataclasses import dataclass
from typing import Optional, Any
from pathlib import Path

import aiohttp
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception_type
)

from .models import AIConfig


logger = logging.getLogger(__name__)


class AIError(Exception):
    """Base exception for AI client errors."""
    pass


class RateLimitError(AIError):
    """Raised when API rate limit is exceeded."""
    pass


class GenerationError(AIError):
    """Raised when content generation fails."""
    pass


@dataclass
class TextGenerationResult:
    """Result of text generation."""
    title: str
    body: str
    metadata: dict[str, Any]


@dataclass
class ImageGenerationResult:
    """Result of image generation."""
    image_data: bytes  # PNG bytes
    width: int
    height: int
    metadata: dict[str, Any]


class GeminiClient:
    """
    Client for Google Gemini API (text and image generation).
    
    This client handles:
    - Announcement text generation (Gemini 1.5 Pro)
    - Banner image generation (Gemini 2.5 Flash Image)
    - Retry logic with exponential backoff
    - Context window management
    - Rate limiting
    
    Attributes:
        api_key: Google AI API key
        config: AI configuration
        base_url: Gemini API base URL
        session: Async HTTP session
    """
    
    BASE_URL = "https://generativelanguage.googleapis.com/v1beta"
    
    def __init__(self, api_key: str, config: AIConfig) -> None:
        """
        Initialize Gemini AI client.
        
        Args:
            api_key: Google AI API key (from AI Studio or Cloud Console)
            config: AI configuration (models, temperature, etc.)
            
        Raises:
            ValueError: If API key is invalid format
        """
        if not api_key or not api_key.startswith('AIza'):
            raise ValueError(
                "Invalid Google AI API key format.\n"
                "Expected: AIzaSy...\n"
                "Get key at: https://ai.google.dev/"
            )
        
        self.api_key = api_key
        self.config = config
        self.base_url = self.BASE_URL
        self.session: Optional[aiohttp.ClientSession] = None
        
        logger.info("Gemini client initialized", extra={
            "model_text": config.model_text,
            "model_image": config.model_image
        })
    
    async def __aenter__(self):
        """Async context manager entry."""
        self.session = aiohttp.ClientSession()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        if self.session:
            await self.session.close()
    
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        retry=retry_if_exception_type((aiohttp.ClientError, asyncio.TimeoutError)),
        reraise=True
    )
    async def generate_text(
        self,
        prompt: str,
        system_instruction: Optional[str] = None,
        temperature: Optional[float] = None
    ) -> TextGenerationResult:
        """
        Generate announcement text using Gemini 1.5 Pro.
        
        Args:
            prompt: The prompt containing commits and context
            system_instruction: System instruction for persona/tone
            temperature: Creativity level (0-1), uses config default if None
            
        Returns:
            TextGenerationResult with title and body
            
        Raises:
            RateLimitError: If rate limit exceeded
            GenerationError: If generation fails
            AIError: For other API errors
        """
        if not self.session:
            raise AIError("Client not initialized. Use 'async with' context manager.")
        
        temp = temperature if temperature is not None else self.config.temperature
        
        logger.info("Generating text with Gemini", extra={
            "model": self.config.model_text,
            "temperature": temp,
            "prompt_length": len(prompt)
        })
        
        # Build request payload
        payload = {
            "contents": [{
                "role": "user",
                "parts": [{"text": prompt}]
            }],
            "generationConfig": {
                "temperature": temp,
                "maxOutputTokens": 2048,
                "topP": 0.95,
                "topK": 40
            }
        }
        
        # Add system instruction if provided
        if system_instruction:
            payload["systemInstruction"] = {
                "parts": [{"text": system_instruction}]
            }
        
        # Make API call
        url = f"{self.base_url}/models/{self.config.model_text}:generateContent"
        headers = {
            "Content-Type": "application/json",
            "x-goog-api-key": self.api_key
        }
        
        try:
            async with self.session.post(
                url,
                json=payload,
                headers=headers,
                timeout=aiohttp.ClientTimeout(total=30)
            ) as response:
                
                # Handle rate limiting
                if response.status == 429:
                    retry_after = response.headers.get('Retry-After', '60')
                    raise RateLimitError(
                        f"Rate limit exceeded. Retry after {retry_after}s.\n"
                        f"Tip: Reduce frequency or upgrade to paid tier."
                    )
                
                # Handle other errors
                if response.status != 200:
                    error_text = await response.text()
                    raise GenerationError(
                        f"API error (status {response.status}): {error_text}"
                    )
                
                # Parse response
                data = await response.json()
                result = self._parse_text_response(data)
                
                logger.info("Text generation successful", extra={
                    "title_length": len(result.title),
                    "body_length": len(result.body)
                })
                
                return result
        
        except asyncio.TimeoutError as e:
            raise AIError("API request timed out after 30s") from e
        except aiohttp.ClientError as e:
            raise AIError(f"Network error: {e}") from e
    
    def _parse_text_response(self, data: dict) -> TextGenerationResult:
        """
        Parse Gemini API response for text generation.
        
        Args:
            data: JSON response from API
            
        Returns:
            Parsed TextGenerationResult
            
        Raises:
            GenerationError: If response format is invalid
        """
        try:
            # Extract generated text
            candidates = data.get('candidates', [])
            if not candidates:
                raise GenerationError("No candidates in response")
            
            content = candidates[0].get('content', {})
            parts = content.get('parts', [])
            if not parts:
                raise GenerationError("No parts in response")
            
            text = parts[0].get('text', '')
            if not text:
                raise GenerationError("Empty text in response")
            
            # Parse into title and body
            # Expected format: "Title: ...\n\nBody: ..."
            lines = text.strip().split('\n', 1)
            
            if len(lines) < 2:
                # Fallback: use first line as title, rest as body
                title = lines[0][:255]  # Max Steam title length
                body = text
            else:
                # Extract title (remove "Title:" prefix if present)
                title = lines[0].replace('Title:', '').strip()[:255]
                body = lines[1].replace('Body:', '').strip()
            
            # Extract metadata
            metadata = {
                'model': data.get('modelVersion', self.config.model_text),
                'finish_reason': candidates[0].get('finishReason', 'unknown'),
                'safety_ratings': candidates[0].get('safetyRatings', [])
            }
            
            return TextGenerationResult(
                title=title,
                body=body,
                metadata=metadata
            )
            
        except (KeyError, IndexError, AttributeError) as e:
            raise GenerationError(f"Failed to parse response: {e}") from e
    
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        retry=retry_if_exception_type((aiohttp.ClientError, asyncio.TimeoutError)),
        reraise=True
    )
    async def generate_image(
        self,
        prompt: str,
        reference_image_path: Optional[Path] = None,
        aspect_ratio: str = "16:9"
    ) -> ImageGenerationResult:
        """
        Generate banner image using Gemini 2.5 Flash Image.
        
        Args:
            prompt: Image generation prompt (art style, content description)
            reference_image_path: Path to reference screenshot for style matching
            aspect_ratio: Image aspect ratio ("16:9", "1:1", "4:3")
            
        Returns:
            ImageGenerationResult with PNG bytes
            
        Raises:
            RateLimitError: If rate limit exceeded
            GenerationError: If generation fails
            AIError: For other API errors
        """
        if not self.session:
            raise AIError("Client not initialized. Use 'async with' context manager.")
        
        logger.info("Generating image with Gemini", extra={
            "model": self.config.model_image,
            "aspect_ratio": aspect_ratio,
            "has_reference": reference_image_path is not None
        })
        
        # Build request parts
        parts = [{"text": prompt}]
        
        # Add reference image if provided
        if reference_image_path and reference_image_path.exists():
            with open(reference_image_path, 'rb') as f:
                image_bytes = f.read()
                image_b64 = base64.b64encode(image_bytes).decode('utf-8')
            
            parts.append({
                "inline_data": {
                    "mime_type": "image/png",
                    "data": image_b64
                }
            })
        
        # Build payload
        payload = {
            "contents": [{
                "role": "user",
                "parts": parts
            }],
            "generationConfig": {
                "responseModalities": ["image"],
                "aspectRatio": aspect_ratio
            }
        }
        
        # Make API call
        url = f"{self.base_url}/models/{self.config.model_image}:generateContent"
        headers = {
            "Content-Type": "application/json",
            "x-goog-api-key": self.api_key
        }
        
        try:
            async with self.session.post(
                url,
                json=payload,
                headers=headers,
                timeout=aiohttp.ClientTimeout(total=60)  # Image gen takes longer
            ) as response:
                
                if response.status == 429:
                    retry_after = response.headers.get('Retry-After', '60')
                    raise RateLimitError(
                        f"Rate limit exceeded. Retry after {retry_after}s"
                    )
                
                if response.status != 200:
                    error_text = await response.text()
                    raise GenerationError(
                        f"Image generation failed (status {response.status}): {error_text}"
                    )
                
                # Parse response
                data = await response.json()
                result = self._parse_image_response(data)
                
                logger.info("Image generation successful", extra={
                    "size_bytes": len(result.image_data),
                    "dimensions": f"{result.width}x{result.height}"
                })
                
                return result
        
        except asyncio.TimeoutError as e:
            raise AIError("Image generation timed out after 60s") from e
        except aiohttp.ClientError as e:
            raise AIError(f"Network error: {e}") from e
    
    def _parse_image_response(self, data: dict) -> ImageGenerationResult:
        """
        Parse Gemini API response for image generation.
        
        Args:
            data: JSON response from API
            
        Returns:
            Parsed ImageGenerationResult
            
        Raises:
            GenerationError: If response format is invalid
        """
        try:
            candidates = data.get('candidates', [])
            if not candidates:
                raise GenerationError("No candidates in response")
            
            content = candidates[0].get('content', {})
            parts = content.get('parts', [])
            if not parts:
                raise GenerationError("No parts in response")
            
            # Extract base64 image data
            inline_data = parts[0].get('inline_data', {})
            image_b64 = inline_data.get('data', '')
            
            if not image_b64:
                raise GenerationError("No image data in response")
            
            # Decode base64
            image_bytes = base64.b64decode(image_b64)
            
            # Get dimensions from metadata or assume standard
            # Note: Gemini doesn't always return dimensions, so we may need to parse PNG header
            width = 1024  # Default
            height = 576   # Default for 16:9
            
            metadata = {
                'model': data.get('modelVersion', self.config.model_image),
                'finish_reason': candidates[0].get('finishReason', 'unknown')
            }
            
            return ImageGenerationResult(
                image_data=image_bytes,
                width=width,
                height=height,
                metadata=metadata
            )
            
        except (KeyError, IndexError, base64.binascii.Error) as e:
            raise GenerationError(f"Failed to parse image response: {e}") from e
    
    async def close(self) -> None:
        """Close the HTTP session."""
        if self.session:
            await self.session.close()
            self.session = None


# Convenience wrapper class for backwards compatibility
class AIClient(GeminiClient):
    """Alias for GeminiClient (backwards compatibility)."""
    pass
```

TESTING:
Create tests/test_ai_client.py:
```python
import pytest
from pathlib import Path
from wishlistops.ai_client import GeminiClient, AIError, RateLimitError
from wishlistops.models import AIConfig

@pytest.fixture
def ai_config():
    """Create test AI config."""
    return AIConfig(
        model_text="gemini-1.5-pro",
        model_image="gemini-2.5-flash-image",
        temperature=0.7,
        max_retries=3
    )

@pytest.fixture
def mock_api_key():
    """Mock API key for testing."""
    return "AIzaSyTest1234567890"

@pytest.mark.asyncio
async def test_client_initialization(mock_api_key, ai_config):
    """Test client can be initialized."""
    client = GeminiClient(mock_api_key, ai_config)
    assert client.api_key == mock_api_key
    assert client.config == ai_config

def test_invalid_api_key_raises_error(ai_config):
    """Test invalid API key format is rejected."""
    with pytest.raises(ValueError, match="Invalid Google AI API key"):
        GeminiClient("invalid-key", ai_config)

@pytest.mark.asyncio
@pytest.mark.integration
async def test_text_generation_real_api():
    """Test text generation with real API (requires GOOGLE_AI_KEY env var)."""
    import os
    api_key = os.getenv('GOOGLE_AI_KEY')
    if not api_key:
        pytest.skip("GOOGLE_AI_KEY not set")
    
    config = AIConfig()
    async with GeminiClient(api_key, config) as client:
        result = await client.generate_text(
            prompt="Write a short game update about adding a new weapon.",
            system_instruction="You are a friendly indie game developer."
        )
        
        assert result.title
        assert result.body
        assert len(result.title) > 0
        assert len(result.body) > 50

@pytest.mark.asyncio
@pytest.mark.integration
async def test_image_generation_real_api():
    """Test image generation with real API."""
    import os
    api_key = os.getenv('GOOGLE_AI_KEY')
    if not api_key:
        pytest.skip("GOOGLE_AI_KEY not set")
    
    config = AIConfig()
    async with GeminiClient(api_key, config) as client:
        result = await client.generate_image(
            prompt="A pixel art fantasy game banner with a knight and sword",
            aspect_ratio="16:9"
        )
        
        assert result.image_data
        assert len(result.image_data) > 1000  # Reasonable size
        assert result.width > 0
        assert result.height > 0
```

QUALITY CHECKLIST:
- [ ] Uses aiohttp for async HTTP
- [ ] Retry logic with exponential backoff
- [ ] Rate limit handling (429 status)
- [ ] Timeout handling (30s text, 60s image)
- [ ] Structured logging with context
- [ ] Helpful error messages
- [ ] Type hints on all methods
- [ ] Docstrings on all public methods
- [ ] Context manager support (async with)

OUTPUT:
- File: wishlistops/ai_client.py (400-500 lines)
- File: tests/test_ai_client.py (150-200 lines)
```

**Expected Output:**
- Complete Gemini API client
- Text generation (announcements)
- Image generation (banners)
- Robust error handling
- Ready for production use

**Testing:**
```bash
# Unit tests (mocked)
pytest tests/test_ai_client.py -v -k "not integration"

# Integration tests (requires real API key)
export GOOGLE_AI_KEY='your-key-here'
pytest tests/test_ai_client.py -v -m integration

# Manual test
python -c "
import asyncio
from pathlib import Path
from wishlistops.ai_client import GeminiClient
from wishlistops.models import AIConfig

async def test():
    config = AIConfig()
    async with GeminiClient('YOUR_API_KEY', config) as client:
        result = await client.generate_text('Test prompt')
        print(f'Title: {result.title}')
        print(f'Body: {result.body[:100]}...')

asyncio.run(test())
"
```

**Success Criteria:**
- [ ] Client initializes correctly
- [ ] Text generation works
- [ ] Image generation works
- [ ] Rate limiting handled gracefully
- [ ] Retries work on transient failures
- [ ] All tests pass
- [ ] Type checking passes

---


### TASK 2.3: Discord Notifier with Approval Buttons

**File:** `wishlistops/discord_notifier.py`

**Prompt for AI Agent:**

```
CONTEXT:
You are creating the Discord notification system for WishlistOps. This component sends draft announcements to Discord/Slack for human approval before posting to Steam. This is a CRITICAL safety feature that prevents AI mistakes from reaching the public.

ARCHITECTURE REFERENCE:
- See "Fix #2: Discord Approval Gate" in 05_WishlistOps_Revised_Architecture.md
- See "Section 7: User Journey Flow" in 04_WishlistOps_System_Architecture_Diagrams.md
- See the complete approval workflow diagram

WHY THIS MATTERS:
This is the quality gate that prevents:
- AI hallucinations (fake features)
- Generic "ChatGPT slop" language
- Off-brand tone
- Embarrassing mistakes

Without this, one bad AI generation could damage the game's reputation permanently.

DISCORD WEBHOOK OVERVIEW:
- Webhooks allow posting to channels without bot setup
- Support rich embeds (title, description, image, fields)
- Support buttons (interactive components) - LIMITED
- Rate limit: 30 requests per minute per webhook
- Max embed size: 6000 characters

IMPORTANT LIMITATION:
Discord webhooks do NOT support interactive buttons directly. For approval buttons, we have two options:
1. Simple: Send preview, require manual Steam check
2. Advanced: Use Discord bot with interactions (future phase)

For Week 1 MVP, we'll use Option 1 (preview notification).

TECHNICAL REQUIREMENTS:
- Async HTTP POST to webhook URL
- Rich embed formatting
- Image URL attachment
- Error handling (webhook down)
- Rate limit respecting
- Dry-run mode support

NOTIFICATION CONTENT:
- Game name and version
- Announcement title
- Announcement body preview (first 500 chars)
- Banner image preview
- Link to full draft (GitHub artifact)
- Instructions for manual approval

IMPLEMENTATION:

```python
"""
Discord notification system for approval workflow.

Sends draft announcements to Discord for human review before posting to Steam.
This is the critical quality gate that prevents AI mistakes.

Architecture: See 05_WishlistOps_Revised_Architecture.md Fix #2
"""

import logging
from typing import Optional
from datetime import datetime

import aiohttp


logger = logging.getLogger(__name__)


class DiscordError(Exception):
    """Base exception for Discord notification errors."""
    pass


class WebhookError(DiscordError):
    """Raised when webhook delivery fails."""
    pass


class DiscordNotifier:
    """
    Send notifications to Discord via webhooks.
    
    This class handles sending draft announcements to Discord channels
    for human approval before posting to Steam.
    
    Attributes:
        webhook_url: Discord webhook URL
        dry_run: If True, log notifications without sending
    """
    
    # Discord limits
    MAX_EMBED_DESCRIPTION = 4096
    MAX_FIELD_VALUE = 1024
    MAX_TITLE = 256
    RATE_LIMIT_DELAY = 2  # seconds between requests
    
    def __init__(self, webhook_url: Optional[str], dry_run: bool = False) -> None:
        """
        Initialize Discord notifier.
        
        Args:
            webhook_url: Discord webhook URL (starts with https://discord.com/api/webhooks/)
            dry_run: If True, log without actually sending
            
        Raises:
            ValueError: If webhook URL format is invalid
        """
        if webhook_url and not webhook_url.startswith('https://discord.com/api/webhooks/'):
            raise ValueError(
                "Invalid Discord webhook URL format.\n"
                "Expected: https://discord.com/api/webhooks/...\n"
                "Get one from: Discord Server Settings > Integrations > Webhooks"
            )
        
        self.webhook_url = webhook_url
        self.dry_run = dry_run
        
        if dry_run:
            logger.info("Discord notifier initialized in DRY RUN mode")
        else:
            logger.info("Discord notifier initialized", extra={
                "webhook_configured": bool(webhook_url)
            })
    
    async def send_approval_request(
        self,
        title: str,
        body: str,
        banner_url: Optional[str] = None,
        game_name: Optional[str] = None,
        tag: Optional[str] = None
    ) -> bool:
        """
        Send draft announcement to Discord for approval.
        
        Args:
            title: Announcement title
            body: Announcement body (full text)
            banner_url: URL to generated banner image
            game_name: Name of the game
            tag: Git tag (e.g., v1.2.0)
            
        Returns:
            True if sent successfully, False if dry run or webhook not configured
            
        Raises:
            WebhookError: If webhook delivery fails
        """
        if not self.webhook_url:
            logger.warning("Discord webhook not configured, skipping notification")
            return False
        
        if self.dry_run:
            logger.info("DRY RUN: Would send to Discord", extra={
                "title": title,
                "body_length": len(body),
                "has_banner": bool(banner_url)
            })
            return False
        
        logger.info("Sending approval request to Discord", extra={
            "title": title,
            "game": game_name,
            "tag": tag
        })
        
        # Build embed
        embed = self._build_approval_embed(
            title=title,
            body=body,
            banner_url=banner_url,
            game_name=game_name,
            tag=tag
        )
        
        # Send to Discord
        try:
            await self._send_webhook(embed)
            logger.info("Approval request sent successfully")
            return True
        except Exception as e:
            logger.error(f"Failed to send approval request: {e}", exc_info=True)
            raise WebhookError(f"Discord notification failed: {e}") from e
    
    def _build_approval_embed(
        self,
        title: str,
        body: str,
        banner_url: Optional[str],
        game_name: Optional[str],
        tag: Optional[str]
    ) -> dict:
        """
        Build Discord embed for approval request.
        
        Args:
            title: Announcement title
            body: Announcement body
            banner_url: Banner image URL
            game_name: Game name
            tag: Git tag
            
        Returns:
            Discord embed payload
        """
        # Truncate body for preview
        body_preview = body[:500] + "..." if len(body) > 500 else body
        
        # Build title
        embed_title = f"🎮 New Announcement Ready: {title[:200]}"
        
        # Build description
        description = (
            f"**Game:** {game_name or 'Unknown'}\n"
            f"**Version:** {tag or 'Unknown'}\n"
            f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M UTC')}\n\n"
            f"**Preview:**\n{body_preview}"
        )
        
        # Truncate if too long
        if len(description) > self.MAX_EMBED_DESCRIPTION:
            description = description[:self.MAX_EMBED_DESCRIPTION - 3] + "..."
        
        # Build embed
        embed = {
            "title": embed_title[:self.MAX_TITLE],
            "description": description,
            "color": 5814783,  # Blue color
            "fields": [
                {
                    "name": "📝 Next Steps",
                    "value": (
                        "1. Review the announcement above\n"
                        "2. Check the banner image below\n"
                        "3. Log into Steamworks dashboard\n"
                        "4. Find the 'Hidden' announcement\n"
                        "5. Edit if needed, then publish"
                    ),
                    "inline": False
                },
                {
                    "name": "⚠️ Important",
                    "value": (
                        "The announcement is saved as 'Hidden' in Steam.\n"
                        "It will NOT be published automatically.\n"
                        "You must manually publish it after review."
                    ),
                    "inline": False
                }
            ],
            "footer": {
                "text": "WishlistOps • Automated Steam Marketing"
            },
            "timestamp": datetime.utcnow().isoformat()
        }
        
        # Add banner image if available
        if banner_url:
            embed["image"] = {"url": banner_url}
        
        return embed
    
    async def send_error(self, error_message: str) -> bool:
        """
        Send error notification to Discord.
        
        Args:
            error_message: Error description
            
        Returns:
            True if sent successfully, False if dry run or webhook not configured
        """
        if not self.webhook_url:
            logger.warning("Discord webhook not configured, skipping error notification")
            return False
        
        if self.dry_run:
            logger.info("DRY RUN: Would send error to Discord", extra={
                "error": error_message
            })
            return False
        
        logger.info("Sending error notification to Discord")
        
        embed = {
            "title": "❌ WishlistOps Workflow Failed",
            "description": (
                f"**Error:**\n```\n{error_message[:500]}\n```\n\n"
                f"**Time:** {datetime.now().strftime('%Y-%m-%d %H:%M UTC')}\n\n"
                f"**Actions:**\n"
                f"1. Check GitHub Actions logs\n"
                f"2. Verify API keys are set correctly\n"
                f"3. Try running manually with --dry-run flag"
            ),
            "color": 15158332,  # Red color
            "footer": {
                "text": "WishlistOps • Error Notification"
            },
            "timestamp": datetime.utcnow().isoformat()
        }
        
        try:
            await self._send_webhook(embed)
            return True
        except Exception as e:
            logger.error(f"Failed to send error notification: {e}")
            return False
    
    async def send_success(
        self,
        title: str,
        steam_url: Optional[str] = None
    ) -> bool:
        """
        Send success notification to Discord.
        
        Args:
            title: Announcement title that was posted
            steam_url: URL to the Steam announcement
            
        Returns:
            True if sent successfully
        """
        if not self.webhook_url or self.dry_run:
            return False
        
        logger.info("Sending success notification to Discord")
        
        description = (
            f"✅ **Announcement Posted Successfully**\n\n"
            f"**Title:** {title}\n"
            f"**Time:** {datetime.now().strftime('%Y-%m-%d %H:%M UTC')}\n"
        )
        
        if steam_url:
            description += f"\n**View on Steam:** {steam_url}"
        
        embed = {
            "title": "✅ Announcement Published",
            "description": description,
            "color": 5763719,  # Green color
            "footer": {
                "text": "WishlistOps • Success Notification"
            },
            "timestamp": datetime.utcnow().isoformat()
        }
        
        try:
            await self._send_webhook(embed)
            return True
        except Exception as e:
            logger.error(f"Failed to send success notification: {e}")
            return False
    
    async def _send_webhook(self, embed: dict) -> None:
        """
        Send embed to Discord webhook.
        
        Args:
            embed: Discord embed object
            
        Raises:
            WebhookError: If delivery fails
        """
        payload = {
            "username": "WishlistOps",
            "embeds": [embed]
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.post(
                self.webhook_url,
                json=payload,
                timeout=aiohttp.ClientTimeout(total=10)
            ) as response:
                
                if response.status == 429:
                    # Rate limited
                    retry_after = response.headers.get('Retry-After', '60')
                    raise WebhookError(
                        f"Discord rate limit hit. Retry after {retry_after}s"
                    )
                
                if response.status == 404:
                    raise WebhookError(
                        "Discord webhook not found. Check your webhook URL."
                    )
                
                if response.status >= 400:
                    error_text = await response.text()
                    raise WebhookError(
                        f"Discord API error (status {response.status}): {error_text}"
                    )
                
                logger.debug("Discord webhook sent successfully", extra={
                    "status": response.status
                })


# Convenience function for quick notifications
async def notify_discord(
    webhook_url: str,
    message: str,
    dry_run: bool = False
) -> bool:
    """
    Quick notification helper.
    
    Args:
        webhook_url: Discord webhook URL
        message: Message to send
        dry_run: If True, don't actually send
        
    Returns:
        True if sent successfully
    """
    notifier = DiscordNotifier(webhook_url, dry_run=dry_run)
    
    embed = {
        "description": message,
        "color": 5814783,
        "timestamp": datetime.utcnow().isoformat()
    }
    
    try:
        await notifier._send_webhook(embed)
        return True
    except:
        return False
```

TESTING:
Create tests/test_discord_notifier.py:
```python
import pytest
from wishlistops.discord_notifier import DiscordNotifier, WebhookError

def test_notifier_initialization():
    """Test notifier can be initialized."""
    notifier = DiscordNotifier("https://discord.com/api/webhooks/123/abc")
    assert notifier.webhook_url is not None
    assert notifier.dry_run is False

def test_invalid_webhook_url_raises_error():
    """Test invalid webhook URL is rejected."""
    with pytest.raises(ValueError, match="Invalid Discord webhook"):
        DiscordNotifier("https://example.com/webhook")

def test_dry_run_mode():
    """Test dry run mode doesn't send."""
    notifier = DiscordNotifier(
        "https://discord.com/api/webhooks/123/abc",
        dry_run=True
    )
    assert notifier.dry_run is True

@pytest.mark.asyncio
async def test_send_without_webhook():
    """Test sending without webhook configured."""
    notifier = DiscordNotifier(None)
    result = await notifier.send_approval_request(
        title="Test",
        body="Test body"
    )
    assert result is False

@pytest.mark.asyncio
@pytest.mark.integration
async def test_send_approval_request_real():
    """Test sending to real Discord webhook."""
    import os
    webhook_url = os.getenv('DISCORD_WEBHOOK_URL')
    if not webhook_url:
        pytest.skip("DISCORD_WEBHOOK_URL not set")
    
    notifier = DiscordNotifier(webhook_url)
    result = await notifier.send_approval_request(
        title="Test Announcement",
        body="This is a test announcement body with some content.",
        game_name="Test Game",
        tag="v1.0.0"
    )
    
    assert result is True

@pytest.mark.asyncio
@pytest.mark.integration
async def test_send_error_notification_real():
    """Test sending error notification."""
    import os
    webhook_url = os.getenv('DISCORD_WEBHOOK_URL')
    if not webhook_url:
        pytest.skip("DISCORD_WEBHOOK_URL not set")
    
    notifier = DiscordNotifier(webhook_url)
    result = await notifier.send_error("Test error message")
    
    assert result is True
```

QUALITY CHECKLIST:
- [ ] Rich embed formatting
- [ ] Truncation for Discord limits
- [ ] Error handling (webhook down, rate limits)
- [ ] Dry-run mode support
- [ ] Structured logging
- [ ] Type hints on all methods
- [ ] Docstrings on all public methods
- [ ] Success/error notification variants

OUTPUT:
- File: wishlistops/discord_notifier.py (300-400 lines)
- File: tests/test_discord_notifier.py (100-150 lines)
```

**Expected Output:**
- Complete Discord notification system
- Rich embeds with preview
- Error notifications
- Dry-run mode for testing
- Ready for integration

**Testing:**
```bash
# Unit tests
pytest tests/test_discord_notifier.py -v -k "not integration"

# Integration test (requires real webhook)
export DISCORD_WEBHOOK_URL='https://discord.com/api/webhooks/YOUR_WEBHOOK'
pytest tests/test_discord_notifier.py -v -m integration

# Manual test
python -c "
import asyncio
from wishlistops.discord_notifier import DiscordNotifier

async def test():
    notifier = DiscordNotifier('YOUR_WEBHOOK_URL')
    await notifier.send_approval_request(
        title='Test Announcement',
        body='This is a test body with some content.',
        game_name='My Game',
        tag='v1.0.0'
    )

asyncio.run(test())
"
```

**Success Criteria:**
- [ ] Notifier initializes correctly
- [ ] Can send approval requests
- [ ] Can send error notifications
- [ ] Handles rate limits gracefully
- [ ] Dry-run mode works
- [ ] All tests pass
- [ ] Integration test succeeds with real webhook

---


### TASK 2.4: State Manager for Persistence

**File:** `wishlistops/state_manager.py`

**Prompt for AI Agent:**

```
CONTEXT:
You are creating the state management system for WishlistOps. This component persists workflow state between runs, enabling idempotent operations and rate limiting. Since we have NO external database (zero infrastructure cost), state is stored in JSON files within the Git repository.

ARCHITECTURE REFERENCE:
- See "Section 10: Database Schema & State Management" in 04_WishlistOps_System_Architecture_Diagrams.md
- See "Git as Database" philosophy - all state version controlled
- See "State Schema (state.json)" for complete structure

WHY THIS MATTERS:
State management enables:
- Idempotency (safe to re-run workflows)
- Rate limiting (prevent spam posts)
- Tracking history (audit log)
- Resuming after failures
- Detecting duplicate runs

Without proper state management, the system could:
- Post duplicate announcements
- Violate Steam rate limits
- Lose track of what's been processed
- Fail to resume after errors

STATE FILE STRUCTURE:
state.json contains:
- last_run_timestamp: When workflow last executed
- last_tag: Last Git tag processed
- last_post_date: When we last posted to Steam
- total_runs: Counter for analytics
- successful_runs: Success counter
- failed_runs: Failure counter
- last_draft: Most recent generated content

TECHNICAL REQUIREMENTS:
- Atomic writes (write to temp, then rename)
- JSON serialization with Pydantic
- File locking (prevent concurrent access)
- Validation on load (detect corruption)
- Backup on write (keep last 5 versions)
- Thread-safe operations

IMPLEMENTATION:

```python
"""
State management for WishlistOps workflow persistence.

Stores workflow state in JSON files within the Git repository,
enabling idempotent operations without external database.

Architecture: See 04_WishlistOps_System_Architecture_Diagrams.md Section 10
Philosophy: Git as Database - all state is version controlled
"""

import json
import logging
import shutil
from datetime import datetime
from pathlib import Path
from typing import Optional
from filelock import FileLock

from pydantic import BaseModel, Field, ValidationError

from .models import AnnouncementDraft


logger = logging.getLogger(__name__)


class StateError(Exception):
    """Base exception for state management errors."""
    pass


class StateCorruptedError(StateError):
    """Raised when state file is corrupted."""
    pass


class WorkflowRun(BaseModel):
    """Record of a single workflow run."""
    timestamp: str
    tag: Optional[str] = None
    status: str  # "success", "failed", "skipped"
    draft_title: Optional[str] = None
    error: Optional[str] = None


class StateData(BaseModel):
    """
    Complete state data structure.
    
    This matches the schema in 04_WishlistOps_System_Architecture_Diagrams.md
    Section 10: State Schema (state.json)
    """
    
    # Last run information
    last_run_timestamp: Optional[str] = None
    last_tag: Optional[str] = None
    last_commit_sha: Optional[str] = None
    
    # Last post information (for rate limiting)
    last_post_date: Optional[str] = None
    last_post_title: Optional[str] = None
    
    # Counters
    total_runs: int = 0
    successful_runs: int = 0
    failed_runs: int = 0
    skipped_runs: int = 0
    
    # Recent history (last 10 runs)
    recent_runs: list[WorkflowRun] = Field(default_factory=list)
    
    # Current draft (if any)
    current_draft: Optional[AnnouncementDraft] = None
    
    # Metadata
    version: str = "1.0"
    created_at: str = Field(default_factory=lambda: datetime.utcnow().isoformat())
    updated_at: str = Field(default_factory=lambda: datetime.utcnow().isoformat())


class StateManager:
    """
    Manage persistent state for WishlistOps workflows.
    
    Provides thread-safe read/write operations on state.json file
    with atomic writes and backup management.
    
    Attributes:
        state_path: Path to state.json file
        lock_path: Path to lock file for synchronization
        backup_dir: Directory for state backups
        state: Current state data
    """
    
    MAX_RECENT_RUNS = 10
    MAX_BACKUPS = 5
    
    def __init__(self, state_path: Path) -> None:
        """
        Initialize state manager.
        
        Args:
            state_path: Path to state.json file
        """
        self.state_path = state_path
        self.lock_path = state_path.parent / f"{state_path.name}.lock"
        self.backup_dir = state_path.parent / ".state_backups"
        
        # Ensure directories exist
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        
        # Load or initialize state
        self.state = self._load_or_initialize()
        
        logger.info("State manager initialized", extra={
            "state_path": str(state_path),
            "total_runs": self.state.total_runs
        })
    
    def _load_or_initialize(self) -> StateData:
        """
        Load state from file or create new state if file doesn't exist.
        
        Returns:
            Loaded or new StateData
            
        Raises:
            StateCorruptedError: If state file exists but is corrupted
        """
        if not self.state_path.exists():
            logger.info("State file not found, creating new state")
            return StateData()
        
        try:
            with open(self.state_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # Validate with Pydantic
            state = StateData(**data)
            
            logger.info("State loaded successfully", extra={
                "total_runs": state.total_runs,
                "last_run": state.last_run_timestamp
            })
            
            return state
            
        except json.JSONDecodeError as e:
            raise StateCorruptedError(
                f"State file corrupted (invalid JSON): {e}\n"
                f"File: {self.state_path}\n"
                f"Consider restoring from backup in {self.backup_dir}"
            ) from e
        
        except ValidationError as e:
            raise StateCorruptedError(
                f"State file has invalid structure: {e}\n"
                f"File: {self.state_path}\n"
                f"Consider restoring from backup in {self.backup_dir}"
            ) from e
    
    def update_last_run(
        self,
        draft: Optional[AnnouncementDraft] = None,
        tag: Optional[str] = None,
        commit_sha: Optional[str] = None,
        status: str = "success",
        error: Optional[str] = None
    ) -> None:
        """
        Update state after a workflow run.
        
        Args:
            draft: Generated announcement draft
            tag: Git tag that triggered the run
            commit_sha: Git commit SHA
            status: Run status ("success", "failed", "skipped")
            error: Error message if failed
        """
        with FileLock(str(self.lock_path)):
            now = datetime.utcnow().isoformat()
            
            # Update last run info
            self.state.last_run_timestamp = now
            if tag:
                self.state.last_tag = tag
            if commit_sha:
                self.state.last_commit_sha = commit_sha
            
            # Update counters
            self.state.total_runs += 1
            if status == "success":
                self.state.successful_runs += 1
            elif status == "failed":
                self.state.failed_runs += 1
            elif status == "skipped":
                self.state.skipped_runs += 1
            
            # Add to recent runs
            run = WorkflowRun(
                timestamp=now,
                tag=tag,
                status=status,
                draft_title=draft.title if draft else None,
                error=error
            )
            self.state.recent_runs.insert(0, run)
            
            # Keep only last N runs
            if len(self.state.recent_runs) > self.MAX_RECENT_RUNS:
                self.state.recent_runs = self.state.recent_runs[:self.MAX_RECENT_RUNS]
            
            # Update draft
            self.state.current_draft = draft
            
            # Update timestamp
            self.state.updated_at = now
            
            # Save
            self._save()
            
            logger.info("State updated", extra={
                "status": status,
                "total_runs": self.state.total_runs,
                "tag": tag
            })
    
    def update_last_post(self, title: str) -> None:
        """
        Update state after posting to Steam.
        
        Args:
            title: Title of posted announcement
        """
        with FileLock(str(self.lock_path)):
            now = datetime.utcnow().isoformat()
            
            self.state.last_post_date = now
            self.state.last_post_title = title
            self.state.updated_at = now
            
            self._save()
            
            logger.info("Last post updated", extra={
                "title": title,
                "date": now
            })
    
    def get_last_post_date(self) -> Optional[datetime]:
        """
        Get the date of the last Steam post.
        
        Returns:
            Datetime of last post, or None if never posted
        """
        if not self.state.last_post_date:
            return None
        
        try:
            return datetime.fromisoformat(self.state.last_post_date)
        except ValueError:
            logger.warning(f"Invalid last_post_date format: {self.state.last_post_date}")
            return None
    
    def get_last_tag(self) -> Optional[str]:
        """
        Get the last Git tag processed.
        
        Returns:
            Last tag name, or None if never run
        """
        return self.state.last_tag
    
    def get_days_since_last_post(self) -> Optional[float]:
        """
        Calculate days since last post to Steam.
        
        Returns:
            Days since last post, or None if never posted
        """
        last_post = self.get_last_post_date()
        if not last_post:
            return None
        
        delta = datetime.utcnow() - last_post
        return delta.total_seconds() / 86400  # Convert to days
    
    def should_allow_post(self, min_days: int) -> bool:
        """
        Check if enough time has passed since last post (rate limiting).
        
        Args:
            min_days: Minimum days between posts
            
        Returns:
            True if OK to post, False if rate limited
        """
        days_since = self.get_days_since_last_post()
        
        if days_since is None:
            # Never posted before
            return True
        
        allowed = days_since >= min_days
        
        if not allowed:
            logger.warning(
                f"Rate limit: Only {days_since:.1f} days since last post "
                f"(minimum: {min_days} days)"
            )
        
        return allowed
    
    def get_statistics(self) -> dict:
        """
        Get workflow statistics.
        
        Returns:
            Dictionary with run statistics
        """
        success_rate = 0.0
        if self.state.total_runs > 0:
            success_rate = self.state.successful_runs / self.state.total_runs
        
        return {
            "total_runs": self.state.total_runs,
            "successful_runs": self.state.successful_runs,
            "failed_runs": self.state.failed_runs,
            "skipped_runs": self.state.skipped_runs,
            "success_rate": f"{success_rate:.1%}",
            "last_run": self.state.last_run_timestamp,
            "last_post": self.state.last_post_date,
            "last_tag": self.state.last_tag
        }
    
    def _save(self) -> None:
        """
        Save state to file atomically.
        
        Uses atomic write (write to temp, then rename) to prevent corruption.
        Creates backup before overwriting.
        """
        # Backup existing state
        if self.state_path.exists():
            self._create_backup()
        
        # Write to temporary file
        temp_path = self.state_path.parent / f"{self.state_path.name}.tmp"
        
        try:
            with open(temp_path, 'w', encoding='utf-8') as f:
                json.dump(
                    self.state.model_dump(mode='json'),
                    f,
                    indent=2,
                    ensure_ascii=False
                )
            
            # Atomic rename
            temp_path.replace(self.state_path)
            
            logger.debug("State saved successfully")
            
        except Exception as e:
            # Clean up temp file on error
            if temp_path.exists():
                temp_path.unlink()
            raise StateError(f"Failed to save state: {e}") from e
    
    def _create_backup(self) -> None:
        """Create backup of current state file."""
        timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        backup_path = self.backup_dir / f"state_{timestamp}.json"
        
        try:
            shutil.copy2(self.state_path, backup_path)
            logger.debug(f"State backup created: {backup_path}")
            
            # Clean old backups
            self._cleanup_old_backups()
            
        except Exception as e:
            logger.warning(f"Failed to create backup: {e}")
    
    def _cleanup_old_backups(self) -> None:
        """Remove old backups, keeping only last N."""
        backups = sorted(self.backup_dir.glob("state_*.json"), reverse=True)
        
        for backup in backups[self.MAX_BACKUPS:]:
            try:
                backup.unlink()
                logger.debug(f"Removed old backup: {backup}")
            except Exception as e:
                logger.warning(f"Failed to remove backup {backup}: {e}")
    
    def restore_from_backup(self, backup_name: Optional[str] = None) -> None:
        """
        Restore state from backup.
        
        Args:
            backup_name: Specific backup to restore, or None for latest
            
        Raises:
            StateError: If backup doesn't exist or restore fails
        """
        if backup_name:
            backup_path = self.backup_dir / backup_name
        else:
            # Get latest backup
            backups = sorted(self.backup_dir.glob("state_*.json"), reverse=True)
            if not backups:
                raise StateError("No backups found")
            backup_path = backups[0]
        
        if not backup_path.exists():
            raise StateError(f"Backup not found: {backup_path}")
        
        try:
            shutil.copy2(backup_path, self.state_path)
            self.state = self._load_or_initialize()
            logger.info(f"State restored from backup: {backup_path}")
        except Exception as e:
            raise StateError(f"Failed to restore backup: {e}") from e


# Convenience functions
def load_state(state_path: Path) -> StateManager:
    """Load state manager (convenience function)."""
    return StateManager(state_path)
```

TESTING:
Create tests/test_state_manager.py:
```python
import pytest
from pathlib import Path
from datetime import datetime, timedelta
from wishlistops.state_manager import StateManager, StateCorruptedError
from wishlistops.models import AnnouncementDraft

@pytest.fixture
def temp_state_path(tmp_path):
    """Create temporary state file path."""
    return tmp_path / "state.json"

def test_state_manager_initialization(temp_state_path):
    """Test state manager can be initialized."""
    manager = StateManager(temp_state_path)
    assert manager.state is not None
    assert manager.state.total_runs == 0

def test_state_creates_file_on_save(temp_state_path):
    """Test state file is created on first save."""
    manager = StateManager(temp_state_path)
    manager.update_last_run(status="success", tag="v1.0.0")
    
    assert temp_state_path.exists()

def test_state_persists_between_loads(temp_state_path):
    """Test state persists between manager instances."""
    # First instance
    manager1 = StateManager(temp_state_path)
    manager1.update_last_run(status="success", tag="v1.0.0")
    
    # Second instance
    manager2 = StateManager(temp_state_path)
    assert manager2.state.total_runs == 1
    assert manager2.state.last_tag == "v1.0.0"

def test_update_last_run_increments_counters(temp_state_path):
    """Test run counters are updated correctly."""
    manager = StateManager(temp_state_path)
    
    manager.update_last_run(status="success")
    assert manager.state.total_runs == 1
    assert manager.state.successful_runs == 1
    
    manager.update_last_run(status="failed")
    assert manager.state.total_runs == 2
    assert manager.state.failed_runs == 1

def test_rate_limiting(temp_state_path):
    """Test rate limiting works."""
    manager = StateManager(temp_state_path)
    
    # First post - should be allowed
    assert manager.should_allow_post(min_days=7) is True
    
    # Record post
    manager.update_last_post(title="Test Post")
    
    # Second post immediately - should be blocked
    assert manager.should_allow_post(min_days=7) is False
    
    # Fake time passage by modifying state
    past_date = (datetime.utcnow() - timedelta(days=8)).isoformat()
    manager.state.last_post_date = past_date
    
    # Now should be allowed
    assert manager.should_allow_post(min_days=7) is True

def test_recent_runs_limited(temp_state_path):
    """Test recent runs list is limited to MAX_RECENT_RUNS."""
    manager = StateManager(temp_state_path)
    
    # Add more runs than max
    for i in range(15):
        manager.update_last_run(status="success", tag=f"v1.{i}.0")
    
    assert len(manager.state.recent_runs) == StateManager.MAX_RECENT_RUNS

def test_backup_creation(temp_state_path):
    """Test backups are created."""
    manager = StateManager(temp_state_path)
    manager.update_last_run(status="success")
    
    # Make another change to trigger backup
    manager.update_last_run(status="success")
    
    backups = list(manager.backup_dir.glob("state_*.json"))
    assert len(backups) >= 1

def test_corrupted_state_raises_error(temp_state_path):
    """Test corrupted state file raises error."""
    # Create invalid JSON file
    with open(temp_state_path, 'w') as f:
        f.write("{invalid json")
    
    with pytest.raises(StateCorruptedError):
        StateManager(temp_state_path)

def test_statistics(temp_state_path):
    """Test statistics are calculated correctly."""
    manager = StateManager(temp_state_path)
    
    manager.update_last_run(status="success")
    manager.update_last_run(status="success")
    manager.update_last_run(status="failed")
    
    stats = manager.get_statistics()
    assert stats["total_runs"] == 3
    assert stats["successful_runs"] == 2
    assert stats["failed_runs"] == 1
    assert stats["success_rate"] == "66.7%"
```

QUALITY CHECKLIST:
- [ ] Atomic writes (temp + rename)
- [ ] File locking for thread safety
- [ ] Backup management
- [ ] Validation on load
- [ ] Rate limiting logic
- [ ] Statistics calculation
- [ ] Type hints on all methods
- [ ] Docstrings on all public methods
- [ ] Graceful corruption handling

OUTPUT:
- File: wishlistops/state_manager.py (400-500 lines)
- File: tests/test_state_manager.py (150-200 lines)
```

**Expected Output:**
- Complete state management system
- Atomic file operations
- Rate limiting support
- Backup/restore functionality
- Ready for production use

**Testing:**
```bash
# Run tests
pytest tests/test_state_manager.py -v

# Manual test
python -c "
from pathlib import Path
from wishlistops.state_manager import StateManager

manager = StateManager(Path('test_state.json'))
manager.update_last_run(status='success', tag='v1.0.0')

stats = manager.get_statistics()
print(f'Total runs: {stats[\"total_runs\"]}')
print(f'Success rate: {stats[\"success_rate\"]}')
"
```

**Success Criteria:**
- [ ] State persists between runs
- [ ] Rate limiting works
- [ ] Backups are created
- [ ] Corruption is detected
- [ ] Atomic writes prevent data loss
- [ ] All tests pass
- [ ] Thread-safe operations

---

## 📝 TASK 2 COMPLETION CHECKLIST

After Task 2, you should have:

**Files Created:**
- [ ] `wishlistops/git_parser.py` (Git operations)
- [ ] `wishlistops/ai_client.py` (Gemini API client)
- [ ] `wishlistops/discord_notifier.py` (Discord webhooks)
- [ ] `wishlistops/state_manager.py` (State persistence)
- [ ] `tests/test_git_parser.py`
- [ ] `tests/test_ai_client.py`
- [ ] `tests/test_discord_notifier.py`
- [ ] `tests/test_state_manager.py`

**Integration Tests:**
```bash
# Test all components together
python -c "
import asyncio
from pathlib import Path
from wishlistops.git_parser import GitParser
from wishlistops.ai_client import GeminiClient
from wishlistops.discord_notifier import DiscordNotifier
from wishlistops.state_manager import StateManager
from wishlistops.models import AIConfig

async def integration_test():
    # Parse commits
    parser = GitParser(Path('.'))
    commits = parser.get_player_facing_commits()
    print(f'✓ Found {len(commits)} player-facing commits')
    
    # Generate with AI (dry run)
    config = AIConfig()
    async with GeminiClient('test-key', config) as ai:
        print('✓ AI client initialized')
    
    # Test Discord notifier (dry run)
    notifier = DiscordNotifier(None, dry_run=True)
    await notifier.send_approval_request('Test', 'Body')
    print('✓ Discord notifier works')
    
    # Test state manager
    state = StateManager(Path('test_state.json'))
    state.update_last_run(status='success')
    print('✓ State manager works')

asyncio.run(integration_test())
"
```

**Ready for Task 3:** Quality control components (anti-slop filter, image compositor)

---
