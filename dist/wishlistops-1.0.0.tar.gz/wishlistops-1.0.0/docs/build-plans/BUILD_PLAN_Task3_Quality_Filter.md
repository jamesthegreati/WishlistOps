﻿# WishlistOps Build Plan - Task 3: Quality Control
## Day 4: Content Filtering & Image Processing

---

## 🎯 TASK 3 OVERVIEW

**Goal:** Implement quality control mechanisms to prevent AI mistakes from reaching Steam.

**Timeline:** Day 4 (1 day)

**Dependencies:** Task 2 complete (ai_client.py working)

**Components to Build:**
1. Anti-slop content filter (prevents generic AI language)
2. Image compositor (adds logo to AI-generated banners)
3. Integration tests (end-to-end workflow)

**Success Criteria:**
- [ ] Filter catches generic AI buzzwords
- [ ] Filter can regenerate content when issues found
- [ ] Logo properly composited onto banners
- [ ] End-to-end workflow runs successfully
- [ ] All integration tests pass

---

## 🔧 TASK 3.1: Anti-Slop Content Filter

**File:** `wishlistops/content_filter.py`

**Prompt for AI Agent:**

```
CONTEXT:
You are creating the anti-slop content filter for WishlistOps. This is a CRITICAL quality gate that prevents generic AI language from reaching Steam announcements. AI models often produce corporate buzzwords and clichés that damage authenticity.

ARCHITECTURE REFERENCE:
- See "Fix #5: Anti-Slop Quality Filter" in 05_WishlistOps_Revised_Architecture.md
- See "Section 8: Error Handling" in 04_WishlistOps_System_Architecture_Diagrams.md
- This is the quality control step before Discord approval

WHY THIS MATTERS:
Players can instantly detect "AI slop":
- Generic buzzwords like "delve", "tapestry", "leverage"
- Corporate marketing speak
- Phrases that no human developer would use
- This damages trust and appears inauthentic

DETECTION STRATEGY:
1. **Forbidden Words List:** Obvious AI buzzwords
2. **Phrase Patterns:** Marketing clichés
3. **Tone Analysis:** Overly formal language
4. **Repetition Detection:** Same words/phrases repeated
5. **Length Validation:** Too short or too long

FORBIDDEN WORDS (from research):
Common AI slop indicators:
- "delve", "tapestry", "leverage", "synergy", "robust"
- "holistic", "seamless", "cutting-edge", "revolutionary"
- "elevate", "immersive experience", "game-changing"
- "unlock potential", "dive deep", "at the end of the day"

IMPLEMENTATION:

```python
"""
Content quality filter to prevent AI-generated slop.

This filter detects and flags generic AI language, corporate buzzwords,
and other quality issues in generated content.

Architecture: See 05_WishlistOps_Revised_Architecture.md Fix #5
"""

import re
import logging
from dataclasses import dataclass
from typing import Optional

from .models import VoiceConfig


logger = logging.getLogger(__name__)


@dataclass
class FilterResult:
    """Result of content filtering."""
    passed: bool
    issues: list[str]
    score: float  # 0.0 (terrible) to 1.0 (perfect)


class ContentFilter:
    """
    Filter AI-generated content for quality issues.
    
    Detects:
    - AI slop buzzwords
    - Corporate marketing speak
    - Off-brand language
    - Length issues
    - Repetition problems
    
    Attributes:
        voice_config: Voice configuration with avoid_phrases
        slop_words: Built-in list of AI buzzwords
    """
    
    # Built-in AI slop detector patterns
    SLOP_WORDS = [
        # Classic AI buzzwords
        r'\bdelve\b', r'\btapestry\b', r'\bleverage\b', r'\bsynergy\b',
        r'\brobust\b', r'\bholistic\b', r'\bseamless\b',
        
        # Marketing buzzwords
        r'\bcutting[- ]edge\b', r'\brevolutionary\b', r'\bgame[- ]changing\b',
        r'\bindustry[- ]leading\b', r'\bworld[- ]class\b',
        
        # Corporate speak
        r'\belevate\b', r'\btransform\b', r'\bunlock\b.*\bpotential\b',
        r'\btake.*\bto the next level\b', r'\bpivot\b',
        
        # Generic phrases
        r'\bat the end of the day\b', r'\bthink outside the box\b',
        r'\bwin[- ]win\b', r'\blow[- ]hanging fruit\b',
        
        # Over-used AI transitions
        r'\bthat said\b', r'\bmeanwhile\b', r'\bnevertheless\b',
        r'\bhowever, it\'s important to note\b',
        
        # Overly formal
        r'\butilize\b', r'\bfacilitate\b', r'\bimplement\b',
        r'\boptimize\b.*\bexperience\b',
        
        # AI safety additions
        r'\bas an AI\b', r'\bI cannot\b', r'\bI apologize\b',
    ]
    
    # Suspicious phrase patterns (marketing speak)
    MARKETING_PATTERNS = [
        r'\bimmersive experience\b',
        r'\bunparalleled.*experience\b',
        r'\bnext[- ]generation\b',
        r'\binnovative solution\b',
        r'\bgroundbreaking\b',
        r'\bbest[- ]in[- ]class\b',
    ]
    
    # Good indie dev phrases (increase score)
    POSITIVE_PATTERNS = [
        r'\bwe fixed\b', r'\bwe added\b', r'\bwe improved\b',
        r'\bbug fix\b', r'\bnew feature\b', r'\bupdate\b',
        r'\bthanks for\b', r'\byour feedback\b',
    ]
    
    def __init__(self, voice_config: Optional[VoiceConfig] = None) -> None:
        """
        Initialize content filter.
        
        Args:
            voice_config: Voice configuration with custom avoid phrases
        """
        self.voice_config = voice_config or VoiceConfig()
        
        # Combine built-in and user-defined avoid phrases
        self.avoid_phrases = [
            phrase.lower() 
            for phrase in self.voice_config.avoid_phrases
        ]
        
        logger.info("Content filter initialized", extra={
            "custom_avoid_phrases": len(self.avoid_phrases)
        })
    
    def check(self, text: str) -> FilterResult:
        """
        Check text for quality issues.
        
        Args:
            text: Text to check (announcement body)
            
        Returns:
            FilterResult with pass/fail and detected issues
        """
        issues = []
        score = 1.0  # Start with perfect score
        
        text_lower = text.lower()
        
        # Check 1: AI slop words
        for pattern in self.SLOP_WORDS:
            matches = re.findall(pattern, text_lower, re.IGNORECASE)
            if matches:
                issues.append(f"AI slop detected: '{matches[0]}'")
                score -= 0.15
        
        # Check 2: Marketing patterns
        for pattern in self.MARKETING_PATTERNS:
            if re.search(pattern, text_lower, re.IGNORECASE):
                issues.append(f"Marketing speak detected: pattern '{pattern}'")
                score -= 0.10
        
        # Check 3: User-defined avoid phrases
        for phrase in self.avoid_phrases:
            if phrase in text_lower:
                issues.append(f"Avoided phrase found: '{phrase}'")
                score -= 0.10
        
        # Check 4: Length validation
        word_count = len(text.split())
        if word_count < 50:
            issues.append(f"Too short: {word_count} words (min 50)")
            score -= 0.20
        elif word_count > 500:
            issues.append(f"Too long: {word_count} words (max 500)")
            score -= 0.10
        
        # Check 5: Repetition detection
        repetition_issues = self._check_repetition(text)
        issues.extend(repetition_issues)
        score -= len(repetition_issues) * 0.05
        
        # Check 6: Overly formal tone
        if self._is_too_formal(text):
            issues.append("Tone too formal (sounds like corporate announcement)")
            score -= 0.15
        
        # Bonus: Good indie dev language
        for pattern in self.POSITIVE_PATTERNS:
            if re.search(pattern, text_lower, re.IGNORECASE):
                score += 0.05
        
        # Clamp score to 0-1 range
        score = max(0.0, min(1.0, score))
        
        # Pass threshold: 0.6
        passed = score >= 0.6 and len(issues) == 0
        
        if not passed:
            logger.warning("Content failed quality filter", extra={
                "score": f"{score:.2f}",
                "issues_count": len(issues),
                "issues": issues[:3]  # Log first 3 issues
            })
        else:
            logger.info("Content passed quality filter", extra={
                "score": f"{score:.2f}"
            })
        
        return FilterResult(
            passed=passed,
            issues=issues,
            score=score
        )
    
    def _check_repetition(self, text: str) -> list[str]:
        """
        Check for repeated words or phrases.
        
        Args:
            text: Text to check
            
        Returns:
            List of repetition issues found
        """
        issues = []
        words = text.lower().split()
        
        # Check for repeated words (same word 3+ times)
        word_counts = {}
        for word in words:
            if len(word) > 4:  # Only check meaningful words
                word_counts[word] = word_counts.get(word, 0) + 1
        
        for word, count in word_counts.items():
            if count >= 4:  # Word appears 4+ times
                issues.append(f"Word '{word}' repeated {count} times")
        
        # Check for repeated phrases (2-3 word phrases)
        for i in range(len(words) - 2):
            phrase = ' '.join(words[i:i+2])
            rest_of_text = ' '.join(words[i+2:])
            if phrase in rest_of_text:
                issues.append(f"Phrase '{phrase}' repeated")
                break  # Only report first repetition
        
        return issues
    
    def _is_too_formal(self, text: str) -> bool:
        """
        Check if tone is too formal/corporate.
        
        Args:
            text: Text to check
            
        Returns:
            True if too formal
        """
        formal_indicators = [
            r'\bpursuant to\b', r'\btherefore\b', r'\bfurthermore\b',
            r'\bsubsequently\b', r'\bhenceforth\b', r'\bwherein\b',
            r'\bis pleased to announce\b', r'\bare excited to introduce\b',
        ]
        
        text_lower = text.lower()
        formal_count = sum(
            1 for pattern in formal_indicators 
            if re.search(pattern, text_lower)
        )
        
        # If 2+ formal indicators, consider it too formal
        return formal_count >= 2
    
    def suggest_improvements(self, text: str, issues: list[str]) -> str:
        """
        Generate suggestions for improving flagged content.
        
        Args:
            text: Original text
            issues: Issues detected by filter
            
        Returns:
            String with improvement suggestions
        """
        suggestions = []
        
        if any("AI slop" in issue for issue in issues):
            suggestions.append(
                "Replace buzzwords with specific, concrete language. "
                "Example: Instead of 'robust system', say 'bug-free combat'."
            )
        
        if any("Marketing speak" in issue for issue in issues):
            suggestions.append(
                "Remove marketing jargon. Write like you're talking to a friend "
                "about your game, not pitching to investors."
            )
        
        if any("Too short" in issue for issue in issues):
            suggestions.append(
                "Add more details about the changes. What exactly is new? "
                "How does it improve gameplay?"
            )
        
        if any("repeated" in issue for issue in issues):
            suggestions.append(
                "Use more varied vocabulary. Find synonyms or rephrase "
                "to avoid repetition."
            )
        
        if any("too formal" in issue for issue in issues):
            suggestions.append(
                "Use casual, conversational tone. Write 'we fixed' not "
                "'we are pleased to announce the resolution of'."
            )
        
        return "\n".join(f"- {s}" for s in suggestions)
    
    def generate_regeneration_prompt(self, original_text: str, issues: list[str]) -> str:
        """
        Generate prompt for AI to regenerate content avoiding issues.
        
        Args:
            original_text: Original generated text
            issues: Issues that were detected
            
        Returns:
            Prompt for regeneration
        """
        forbidden_words = [
            issue.split("'")[1] 
            for issue in issues 
            if "'" in issue
        ]
        
        prompt = (
            f"Rewrite this announcement to fix these issues:\n"
            f"{chr(10).join(f'- {issue}' for issue in issues)}\n\n"
            f"Original text:\n{original_text}\n\n"
            f"Requirements:\n"
            f"- Do NOT use these words: {', '.join(forbidden_words)}\n"
            f"- Write in casual, authentic indie dev voice\n"
            f"- Be specific and concrete, not vague\n"
            f"- Sound like a human, not a corporate announcement\n"
            f"- Keep it between 50-300 words\n"
        )
        
        return prompt


# Convenience function
def check_content(text: str, voice_config: Optional[VoiceConfig] = None) -> FilterResult:
    """Quick content check (convenience function)."""
    filter = ContentFilter(voice_config)
    return filter.check(text)
```

TESTING:
Create tests/test_content_filter.py:
```python
import pytest
from wishlistops.content_filter import ContentFilter, FilterResult
from wishlistops.models import VoiceConfig

def test_filter_initialization():
    """Test filter can be initialized."""
    filter = ContentFilter()
    assert filter is not None

def test_detect_ai_slop():
    """Test detection of AI buzzwords."""
    filter = ContentFilter()
    
    bad_text = "Let's delve into the robust tapestry of our game's synergy."
    result = filter.check(bad_text)
    
    assert result.passed is False
    assert len(result.issues) > 0
    assert any("slop" in issue.lower() for issue in result.issues)

def test_detect_marketing_speak():
    """Test detection of marketing buzzwords."""
    filter = ContentFilter()
    
    bad_text = "Experience an immersive experience with cutting-edge graphics."
    result = filter.check(bad_text)
    
    assert result.passed is False
    assert any("marketing" in issue.lower() for issue in result.issues)

def test_good_content_passes():
    """Test that good indie dev language passes."""
    filter = ContentFilter()
    
    good_text = (
        "We fixed the boss AI bug that caused softlocks. "
        "We also added a new double-jump mechanic and improved "
        "the framerate in the forest level. Thanks for your feedback! "
        "This update makes combat feel way more responsive."
    )
    result = filter.check(good_text)
    
    assert result.passed is True
    assert len(result.issues) == 0
    assert result.score > 0.8

def test_too_short_fails():
    """Test that too-short content fails."""
    filter = ContentFilter()
    
    short_text = "We updated the game."
    result = filter.check(short_text)
    
    assert result.passed is False
    assert any("short" in issue.lower() for issue in result.issues)

def test_repetition_detected():
    """Test that repetition is detected."""
    filter = ContentFilter()
    
    repetitive_text = (
        "We improved the game. The game is better now. "
        "The game has new features. The game is more fun. " * 3
    )
    result = filter.check(repetitive_text)
    
    assert result.passed is False
    assert any("repeat" in issue.lower() for issue in result.issues)

def test_custom_avoid_phrases():
    """Test user-defined avoid phrases."""
    voice_config = VoiceConfig(avoid_phrases=["monetization", "lootbox"])
    filter = ContentFilter(voice_config)
    
    bad_text = (
        "We added new monetization options with lootbox mechanics "
        "to improve player engagement and retention metrics."
    )
    result = filter.check(bad_text)
    
    assert result.passed is False
    assert any("monetization" in issue.lower() for issue in result.issues)
    assert any("lootbox" in issue.lower() for issue in result.issues)

def test_formal_tone_detected():
    """Test overly formal tone is detected."""
    filter = ContentFilter()
    
    formal_text = (
        "We are pleased to announce that pursuant to user feedback, "
        "we have subsequently implemented improvements. Furthermore, "
        "we would like to express our gratitude."
    )
    result = filter.check(formal_text)
    
    assert result.passed is False
    assert any("formal" in issue.lower() for issue in result.issues)

def test_suggest_improvements():
    """Test improvement suggestions are generated."""
    filter = ContentFilter()
    
    bad_text = "Let's delve into our robust solution."
    result = filter.check(bad_text)
    
    suggestions = filter.suggest_improvements(bad_text, result.issues)
    assert len(suggestions) > 0
    assert "buzzword" in suggestions.lower() or "concrete" in suggestions.lower()

def test_regeneration_prompt():
    """Test regeneration prompt is created."""
    filter = ContentFilter()
    
    bad_text = "Delve into the tapestry"
    issues = ["AI slop detected: 'delve'", "AI slop detected: 'tapestry'"]
    
    prompt = filter.generate_regeneration_prompt(bad_text, issues)
    
    assert "delve" in prompt.lower()
    assert "tapestry" in prompt.lower()
    assert "rewrite" in prompt.lower()
```

QUALITY CHECKLIST:
- [ ] Detects AI slop words
- [ ] Detects marketing speak
- [ ] Detects repetition
- [ ] Detects formal tone
- [ ] Length validation
- [ ] Custom avoid phrases work
- [ ] Scoring system logical
- [ ] Improvement suggestions helpful
- [ ] Type hints on all methods
- [ ] Comprehensive tests

OUTPUT:
- File: wishlistops/content_filter.py (300-400 lines)
- File: tests/test_content_filter.py (150-200 lines)
```

**Expected Output:**
- Robust content quality filter
- Detects multiple issue types
- Provides actionable feedback
- Ready for production use

**Testing:**
```bash
# Run tests
pytest tests/test_content_filter.py -v

# Manual test with real content
python -c "
from wishlistops.content_filter import ContentFilter

filter = ContentFilter()

# Test bad content
bad = 'Let us delve into the robust tapestry of innovation.'
result = filter.check(bad)
print(f'Bad content score: {result.score:.2f}')
print(f'Issues: {result.issues}')

# Test good content
good = 'We fixed the boss AI and added double jump. Thanks for the feedback!'
result = filter.check(good)
print(f'Good content score: {result.score:.2f}')
print(f'Passed: {result.passed}')
"
```

**Success Criteria:**
- [ ] Catches known AI slop
- [ ] Allows good indie dev language
- [ ] Scoring is sensible
- [ ] All tests pass
- [ ] False positive rate <10%

---


### TASK 3.2: Image Compositor (Logo Overlay)

**File:** `wishlistops/image_compositor.py`

**Prompt for AI Agent:**

```
CONTEXT:
You are creating the image compositor for WishlistOps. This component takes AI-generated banner images and composites the game's logo onto them. This is CRITICAL because AI-generated images often have issues with text rendering, so we overlay the real logo separately.

ARCHITECTURE REFERENCE:
- See "Section 3: Data Flow Diagram" Step 7 in 04_WishlistOps_System_Architecture_Diagrams.md
- See "Logo Compositing Pipeline" in technical architecture
- This runs AFTER image generation, BEFORE Discord notification

WHY THIS MATTERS:
- AI text rendering is unreliable (often blurry or wrong)
- Game logo must be pixel-perfect (branding consistency)
- Logo placement must respect Steam's safe zones
- Final image must meet Steam specifications (800x450px)

STEAM IMAGE REQUIREMENTS:
- Dimensions: 800x450 pixels (16:9 aspect ratio)
- Format: PNG or JPG
- File size: <2MB
- Logo must be visible and readable
- Safe zones: Avoid edges (UI overlays on Steam)

COMPOSITING PROCESS:
1. Load AI-generated base image
2. Resize base to exact Steam dimensions
3. Load game logo (transparent PNG)
4. Resize logo to configured percentage of width
5. Position logo at configured location
6. Apply drop shadow for visibility
7. Composite using alpha blending
8. Save final image

TECHNICAL REQUIREMENTS:
- Use Pillow (PIL) library
- Support transparent PNGs for logo
- Maintain aspect ratios
- Apply effects (drop shadow, outline)
- Handle missing logo gracefully
- Optimize file size

IMPLEMENTATION:

```python
"""
Image compositor for logo overlay on AI-generated banners.

Composites game logos onto AI-generated banner images with proper
positioning, sizing, and effects for Steam requirements.

Architecture: See 04_WishlistOps_System_Architecture_Diagrams.md Section 3
"""

import logging
from io import BytesIO
from pathlib import Path
from typing import Optional, Tuple

from PIL import Image, ImageDraw, ImageFilter, ImageFont
from PIL.Image import Resampling

from .models import BrandingConfig


logger = logging.getLogger(__name__)


class CompositorError(Exception):
    """Base exception for compositor errors."""
    pass


class ImageCompositor:
    """
    Composite game logos onto AI-generated banners.
    
    Handles:
    - Resizing to Steam specifications
    - Logo positioning with safe zones
    - Drop shadow effects
    - Alpha blending
    - File optimization
    
    Attributes:
        config: Branding configuration
    """
    
    # Steam banner specifications
    STEAM_WIDTH = 800
    STEAM_HEIGHT = 450
    
    # Safe zones (pixels from edge)
    SAFE_ZONE_HORIZONTAL = 40
    SAFE_ZONE_VERTICAL = 40
    
    def __init__(self, config: BrandingConfig) -> None:
        """
        Initialize image compositor.
        
        Args:
            config: Branding configuration with logo settings
        """
        self.config = config
        logger.info("Image compositor initialized", extra={
            "logo_position": config.logo_position,
            "logo_size_percent": config.logo_size_percent
        })
    
    def composite_logo(
        self,
        base_image_data: bytes,
        logo_path: Optional[Path] = None,
        output_path: Optional[Path] = None
    ) -> bytes:
        """
        Composite logo onto base image.
        
        Args:
            base_image_data: Base banner image bytes (from AI)
            logo_path: Path to logo PNG (uses config default if None)
            output_path: Path to save result (optional)
            
        Returns:
            Final composited image as PNG bytes
            
        Raises:
            CompositorError: If compositing fails
        """
        try:
            # Load base image
            base_image = Image.open(BytesIO(base_image_data))
            logger.info("Loaded base image", extra={
                "size": base_image.size,
                "mode": base_image.mode
            })
            
            # Resize to Steam specifications
            base_image = self._resize_to_steam_specs(base_image)
            
            # Get logo path
            logo_path = logo_path or Path(self.config.logo_path)
            
            # If no logo, return base image
            if not logo_path or not logo_path.exists():
                logger.warning(f"Logo not found: {logo_path}, skipping overlay")
                return self._image_to_bytes(base_image)
            
            # Load and process logo
            logo = self._load_and_prepare_logo(logo_path)
            
            # Calculate position
            position = self._calculate_logo_position(base_image.size, logo.size)
            
            # Create shadow layer
            shadow = self._create_drop_shadow(logo)
            
            # Composite shadow first
            base_image.paste(shadow, position, shadow)
            
            # Composite logo
            base_image.paste(logo, position, logo)
            
            logger.info("Logo composited successfully", extra={
                "logo_size": logo.size,
                "position": position
            })
            
            # Convert to bytes
            result_bytes = self._image_to_bytes(base_image)
            
            # Save if output path provided
            if output_path:
                output_path.parent.mkdir(parents=True, exist_ok=True)
                with open(output_path, 'wb') as f:
                    f.write(result_bytes)
                logger.info(f"Saved composited image: {output_path}")
            
            return result_bytes
            
        except Exception as e:
            raise CompositorError(f"Failed to composite logo: {e}") from e
    
    def _resize_to_steam_specs(self, image: Image.Image) -> Image.Image:
        """
        Resize image to exact Steam specifications.
        
        Args:
            image: Input image
            
        Returns:
            Resized image (800x450)
        """
        target_size = (self.STEAM_WIDTH, self.STEAM_HEIGHT)
        
        if image.size == target_size:
            return image
        
        logger.debug(f"Resizing from {image.size} to {target_size}")
        
        # Use high-quality Lanczos resampling
        return image.resize(target_size, Resampling.LANCZOS)
    
    def _load_and_prepare_logo(self, logo_path: Path) -> Image.Image:
        """
        Load logo and prepare for compositing.
        
        Args:
            logo_path: Path to logo file
            
        Returns:
            Prepared logo image with alpha channel
            
        Raises:
            CompositorError: If logo cannot be loaded
        """
        try:
            logo = Image.open(logo_path)
            
            # Ensure RGBA mode (with alpha channel)
            if logo.mode != 'RGBA':
                logger.debug(f"Converting logo from {logo.mode} to RGBA")
                logo = logo.convert('RGBA')
            
            # Calculate target logo size
            target_width = int(self.STEAM_WIDTH * self.config.logo_size_percent / 100)
            
            # Maintain aspect ratio
            aspect_ratio = logo.height / logo.width
            target_height = int(target_width * aspect_ratio)
            target_size = (target_width, target_height)
            
            # Resize logo
            if logo.size != target_size:
                logger.debug(f"Resizing logo from {logo.size} to {target_size}")
                logo = logo.resize(target_size, Resampling.LANCZOS)
            
            return logo
            
        except Exception as e:
            raise CompositorError(f"Failed to load logo from {logo_path}: {e}") from e
    
    def _calculate_logo_position(
        self,
        banner_size: Tuple[int, int],
        logo_size: Tuple[int, int]
    ) -> Tuple[int, int]:
        """
        Calculate logo position based on configuration.
        
        Args:
            banner_size: Size of banner (width, height)
            logo_size: Size of logo (width, height)
            
        Returns:
            Position tuple (x, y) for top-left corner of logo
        """
        banner_width, banner_height = banner_size
        logo_width, logo_height = logo_size
        
        position_str = self.config.logo_position.value
        
        # Calculate positions with safe zones
        if position_str == "top-left":
            x = self.SAFE_ZONE_HORIZONTAL
            y = self.SAFE_ZONE_VERTICAL
        
        elif position_str == "top-right":
            x = banner_width - logo_width - self.SAFE_ZONE_HORIZONTAL
            y = self.SAFE_ZONE_VERTICAL
        
        elif position_str == "center":
            x = (banner_width - logo_width) // 2
            y = (banner_height - logo_height) // 2
        
        elif position_str == "bottom-left":
            x = self.SAFE_ZONE_HORIZONTAL
            y = banner_height - logo_height - self.SAFE_ZONE_VERTICAL
        
        elif position_str == "bottom-right":
            x = banner_width - logo_width - self.SAFE_ZONE_HORIZONTAL
            y = banner_height - logo_height - self.SAFE_ZONE_VERTICAL
        
        else:
            # Default to top-right
            x = banner_width - logo_width - self.SAFE_ZONE_HORIZONTAL
            y = self.SAFE_ZONE_VERTICAL
        
        logger.debug(f"Logo position: {position_str} -> ({x}, {y})")
        
        return (x, y)
    
    def _create_drop_shadow(
        self,
        logo: Image.Image,
        offset: Tuple[int, int] = (4, 4),
        blur_radius: int = 8,
        color: Tuple[int, int, int, int] = (0, 0, 0, 180)
    ) -> Image.Image:
        """
        Create drop shadow for logo visibility.
        
        Args:
            logo: Logo image
            offset: Shadow offset (x, y)
            blur_radius: Blur amount
            color: Shadow color (R, G, B, A)
            
        Returns:
            Shadow layer as RGBA image
        """
        # Create shadow layer (same size as logo)
        shadow = Image.new('RGBA', logo.size, (0, 0, 0, 0))
        
        # Extract alpha channel from logo
        if logo.mode == 'RGBA':
            alpha = logo.split()[3]
        else:
            alpha = Image.new('L', logo.size, 255)
        
        # Create shadow from alpha
        shadow_alpha = Image.new('L', logo.size, 0)
        shadow_alpha.paste(color[3], (0, 0), alpha)
        
        # Apply blur
        shadow_alpha = shadow_alpha.filter(ImageFilter.GaussianBlur(blur_radius))
        
        # Create colored shadow
        shadow = Image.merge('RGBA', (
            Image.new('L', logo.size, color[0]),
            Image.new('L', logo.size, color[1]),
            Image.new('L', logo.size, color[2]),
            shadow_alpha
        ))
        
        return shadow
    
    def _image_to_bytes(self, image: Image.Image) -> bytes:
        """
        Convert PIL Image to PNG bytes.
        
        Args:
            image: PIL Image
            
        Returns:
            PNG bytes
        """
        buffer = BytesIO()
        
        # Optimize for file size
        image.save(
            buffer,
            format='PNG',
            optimize=True,
            compress_level=6  # Balance between size and speed
        )
        
        buffer.seek(0)
        return buffer.read()
    
    def add_text_overlay(
        self,
        image_data: bytes,
        text: str,
        position: str = "bottom",
        font_size: int = 24
    ) -> bytes:
        """
        Add text overlay to image (for version numbers, etc.).
        
        Args:
            image_data: Input image bytes
            text: Text to add
            position: Position ("top", "bottom", "center")
            font_size: Font size in pixels
            
        Returns:
            Image with text overlay as bytes
        """
        image = Image.open(BytesIO(image_data))
        draw = ImageDraw.Draw(image)
        
        # Try to load a nice font, fall back to default
        try:
            font = ImageFont.truetype("arial.ttf", font_size)
        except:
            font = ImageFont.load_default()
        
        # Calculate text size and position
        bbox = draw.textbbox((0, 0), text, font=font)
        text_width = bbox[2] - bbox[0]
        text_height = bbox[3] - bbox[1]
        
        if position == "bottom":
            x = (image.width - text_width) // 2
            y = image.height - text_height - 20
        elif position == "top":
            x = (image.width - text_width) // 2
            y = 20
        else:  # center
            x = (image.width - text_width) // 2
            y = (image.height - text_height) // 2
        
        # Draw text with outline for visibility
        outline_range = 2
        for adj_x in range(-outline_range, outline_range + 1):
            for adj_y in range(-outline_range, outline_range + 1):
                draw.text((x + adj_x, y + adj_y), text, font=font, fill=(0, 0, 0, 255))
        
        # Draw main text
        draw.text((x, y), text, font=font, fill=(255, 255, 255, 255))
        
        return self._image_to_bytes(image)


# Convenience function
def composite_logo_simple(
    base_image_bytes: bytes,
    logo_path: Path,
    logo_size_percent: int = 25
) -> bytes:
    """
    Quick logo compositing (convenience function).
    
    Args:
        base_image_bytes: Base image
        logo_path: Path to logo
        logo_size_percent: Logo size as % of width
        
    Returns:
        Composited image bytes
    """
    from .models import BrandingConfig, LogoPosition
    
    config = BrandingConfig(
        art_style="default",
        logo_size_percent=logo_size_percent,
        logo_position=LogoPosition.TOP_RIGHT,
        logo_path=str(logo_path)
    )
    
    compositor = ImageCompositor(config)
    return compositor.composite_logo(base_image_bytes)
```

TESTING:
Create tests/test_image_compositor.py:
```python
import pytest
from pathlib import Path
from PIL import Image
from io import BytesIO

from wishlistops.image_compositor import ImageCompositor, CompositorError
from wishlistops.models import BrandingConfig, LogoPosition

@pytest.fixture
def test_base_image():
    """Create test base image."""
    img = Image.new('RGB', (1024, 576), color='blue')
    buffer = BytesIO()
    img.save(buffer, format='PNG')
    return buffer.getvalue()

@pytest.fixture
def test_logo(tmp_path):
    """Create test logo."""
    logo_path = tmp_path / "logo.png"
    img = Image.new('RGBA', (200, 200), color=(255, 0, 0, 255))
    img.save(logo_path)
    return logo_path

@pytest.fixture
def branding_config(test_logo):
    """Create test branding config."""
    return BrandingConfig(
        art_style="test",
        logo_position=LogoPosition.TOP_RIGHT,
        logo_size_percent=25,
        logo_path=str(test_logo)
    )

def test_compositor_initialization(branding_config):
    """Test compositor can be initialized."""
    compositor = ImageCompositor(branding_config)
    assert compositor.config == branding_config

def test_composite_logo_success(test_base_image, test_logo, branding_config):
    """Test logo compositing works."""
    compositor = ImageCompositor(branding_config)
    
    result = compositor.composite_logo(
        base_image_data=test_base_image,
        logo_path=test_logo
    )
    
    assert isinstance(result, bytes)
    assert len(result) > 0
    
    # Verify result is valid image
    img = Image.open(BytesIO(result))
    assert img.size == (800, 450)  # Steam specs

def test_resize_to_steam_specs(test_base_image, branding_config):
    """Test image is resized to Steam specifications."""
    compositor = ImageCompositor(branding_config)
    
    result = compositor.composite_logo(test_base_image)
    img = Image.open(BytesIO(result))
    
    assert img.size == (ImageCompositor.STEAM_WIDTH, ImageCompositor.STEAM_HEIGHT)

def test_logo_positions(test_base_image, test_logo, branding_config):
    """Test all logo positions work."""
    positions = [
        LogoPosition.TOP_LEFT,
        LogoPosition.TOP_RIGHT,
        LogoPosition.CENTER,
        LogoPosition.BOTTOM_LEFT,
        LogoPosition.BOTTOM_RIGHT
    ]
    
    for position in positions:
        branding_config.logo_position = position
        compositor = ImageCompositor(branding_config)
        
        result = compositor.composite_logo(
            base_image_data=test_base_image,
            logo_path=test_logo
        )
        
        assert len(result) > 0

def test_missing_logo_handled(test_base_image, branding_config):
    """Test missing logo is handled gracefully."""
    branding_config.logo_path = "nonexistent.png"
    compositor = ImageCompositor(branding_config)
    
    # Should return base image without logo
    result = compositor.composite_logo(test_base_image)
    assert len(result) > 0

def test_add_text_overlay(test_base_image, branding_config):
    """Test text overlay works."""
    compositor = ImageCompositor(branding_config)
    
    result = compositor.add_text_overlay(
        test_base_image,
        text="v1.0.0",
        position="bottom"
    )
    
    assert len(result) > 0
    img = Image.open(BytesIO(result))
    assert img.size == (800, 450)

def test_file_size_optimization(test_base_image, test_logo, branding_config):
    """Test output file size is reasonable."""
    compositor = ImageCompositor(branding_config)
    
    result = compositor.composite_logo(
        base_image_data=test_base_image,
        logo_path=test_logo
    )
    
    # Should be under 2MB (Steam limit)
    assert len(result) < 2 * 1024 * 1024
    # Should be reasonably compressed (not huge)
    assert len(result) < 500 * 1024  # Less than 500KB for test image
```

QUALITY CHECKLIST:
- [ ] Resizes to exact Steam specs
- [ ] Logo positions work correctly
- [ ] Drop shadow improves visibility
- [ ] Alpha blending works
- [ ] Handles missing logo gracefully
- [ ] File size optimized
- [ ] Type hints on all methods
- [ ] Comprehensive tests

OUTPUT:
- File: wishlistops/image_compositor.py (400-500 lines)
- File: tests/test_image_compositor.py (150-200 lines)
```

**Expected Output:**
- Complete image compositor
- Professional logo overlay
- Steam-compliant output
- Ready for production

**Testing:**
```bash
# Run tests
pytest tests/test_image_compositor.py -v

# Manual test with real images
python -c "
from pathlib import Path
from wishlistops.image_compositor import ImageCompositor
from wishlistops.models import BrandingConfig, LogoPosition

# Load test images
with open('test_banner.png', 'rb') as f:
    base_image = f.read()

config = BrandingConfig(
    art_style='test',
    logo_position=LogoPosition.TOP_RIGHT,
    logo_size_percent=25,
    logo_path='test_logo.png'
)

compositor = ImageCompositor(config)
result = compositor.composite_logo(base_image)

# Save result
with open('output.png', 'wb') as f:
    f.write(result)

print('✓ Composited image saved to output.png')
"
```

**Success Criteria:**
- [ ] Logo properly positioned
- [ ] Drop shadow visible
- [ ] Output is 800x450px
- [ ] File size <2MB
- [ ] All positions work
- [ ] All tests pass

---


### TASK 3.3: Integration Tests (End-to-End)

**File:** `tests/test_integration.py`

**Prompt for AI Agent:**

```
CONTEXT:
You are creating comprehensive integration tests for WishlistOps. These tests verify that all components work together correctly in the complete workflow. This is CRITICAL for ensuring production readiness.

ARCHITECTURE REFERENCE:
- See "Section 12: Complete System Workflow" in 04_WishlistOps_System_Architecture_Diagrams.md
- See the 60-second execution timeline
- Tests should cover the entire flow from Git to Discord

WHY THIS MATTERS:
Unit tests verify individual components work. Integration tests verify:
- Components communicate correctly
- Data flows through the entire pipeline
- Error handling works end-to-end
- System behavior under real conditions

TESTING STRATEGY:
1. **Mock External APIs** (don't hit real APIs in CI)
2. **Use Real Components** (actual code, not mocks)
3. **Test Happy Path** (everything works)
4. **Test Error Paths** (graceful failures)
5. **Test Edge Cases** (empty commits, rate limits)

IMPLEMENTATION:

```python
"""
Integration tests for WishlistOps end-to-end workflow.

Tests the complete pipeline from Git commits to Discord notification,
verifying all components work together correctly.
"""

import pytest
import asyncio
from pathlib import Path
from datetime import datetime
from unittest.mock import AsyncMock, MagicMock, patch

from wishlistops.main import WishlistOpsOrchestrator
from wishlistops.models import Config, AIConfig, VoiceConfig, BrandingConfig, SteamConfig
from wishlistops.git_parser import GitParser, Commit
from wishlistops.ai_client import GeminiClient, TextGenerationResult, ImageGenerationResult
from wishlistops.content_filter import ContentFilter
from wishlistops.discord_notifier import DiscordNotifier
from wishlistops.state_manager import StateManager


@pytest.fixture
def test_config(tmp_path):
    """Create test configuration."""
    return Config(
        steam=SteamConfig(app_id="480", app_name="Test Game"),
        branding=BrandingConfig(
            art_style="pixel art",
            logo_path=str(tmp_path / "logo.png")
        ),
        voice=VoiceConfig(),
        ai=AIConfig(),
        google_ai_key="test-key",
        discord_webhook_url="https://discord.com/api/webhooks/test"
    )


@pytest.fixture
def mock_commits():
    """Create mock Git commits."""
    return [
        Commit(
            sha="abc123",
            message="Add double jump mechanic",
            author="Dev",
            date=datetime.now(),
            files_changed=["src/player.py"],
            is_player_facing=True
        ),
        Commit(
            sha="def456",
            message="Fix boss AI bug",
            author="Dev",
            date=datetime.now(),
            files_changed=["src/boss.py"],
            is_player_facing=True
        )
    ]


@pytest.mark.asyncio
async def test_end_to_end_workflow_success(test_config, mock_commits, tmp_path):
    """
    Test complete workflow executes successfully.
    
    This is the main integration test that verifies:
    1. Git commits are parsed
    2. AI generates content
    3. Content passes filter
    4. Image is generated
    5. Discord notification sent
    6. State is updated
    """
    
    # Setup state manager
    state_path = tmp_path / "state.json"
    
    # Mock external API calls
    with patch('wishlistops.git_parser.GitParser.get_player_facing_commits') as mock_git, \
         patch('wishlistops.ai_client.GeminiClient.generate_text') as mock_text, \
         patch('wishlistops.ai_client.GeminiClient.generate_image') as mock_image, \
         patch('wishlistops.discord_notifier.DiscordNotifier._send_webhook') as mock_discord:
        
        # Configure mocks
        mock_git.return_value = mock_commits
        
        mock_text.return_value = TextGenerationResult(
            title="Combat Update v1.2",
            body="We added double jump and fixed the boss AI bug. Thanks for the feedback!",
            metadata={}
        )
        
        mock_image.return_value = ImageGenerationResult(
            image_data=b"fake-image-data",
            width=1024,
            height=576,
            metadata={}
        )
        
        mock_discord.return_value = None
        
        # Create orchestrator
        orchestrator = WishlistOpsOrchestrator(tmp_path / "config.json")
        orchestrator.config = test_config
        orchestrator.state = StateManager(state_path)
        
        # Run workflow
        result = await orchestrator.run()
        
        # Verify success
        assert result.status == "success"
        assert result.draft is not None
        assert result.draft.title == "Combat Update v1.2"
        
        # Verify all mocks were called
        mock_git.assert_called_once()
        mock_text.assert_called_once()
        mock_image.assert_called_once()
        mock_discord.assert_called_once()
        
        # Verify state was updated
        assert orchestrator.state.state.total_runs == 1
        assert orchestrator.state.state.successful_runs == 1


@pytest.mark.asyncio
async def test_workflow_skips_on_no_commits(test_config, tmp_path):
    """Test workflow skips when no commits found."""
    
    with patch('wishlistops.git_parser.GitParser.get_player_facing_commits') as mock_git:
        mock_git.return_value = []
        
        orchestrator = WishlistOpsOrchestrator(tmp_path / "config.json")
        orchestrator.config = test_config
        orchestrator.state = StateManager(tmp_path / "state.json")
        
        result = await orchestrator.run()
        
        assert result.status == "skipped"
        assert result.reason == "no_commits"


@pytest.mark.asyncio
async def test_content_filter_triggers_regeneration(test_config, mock_commits, tmp_path):
    """Test that content filter triggers AI regeneration on bad content."""
    
    with patch('wishlistops.git_parser.GitParser.get_player_facing_commits') as mock_git, \
         patch('wishlistops.ai_client.GeminiClient.generate_text') as mock_text, \
         patch('wishlistops.discord_notifier.DiscordNotifier._send_webhook') as mock_discord:
        
        mock_git.return_value = mock_commits
        
        # First call returns bad content (AI slop)
        # Second call returns good content
        mock_text.side_effect = [
            TextGenerationResult(
                title="Delve into our robust tapestry",
                body="Let us delve into the tapestry of innovation with our cutting-edge solution.",
                metadata={}
            ),
            TextGenerationResult(
                title="Combat Update",
                body="We added double jump and fixed the boss AI. Thanks for your feedback!",
                metadata={}
            )
        ]
        
        mock_discord.return_value = None
        
        orchestrator = WishlistOpsOrchestrator(tmp_path / "config.json")
        orchestrator.config = test_config
        orchestrator.state = StateManager(tmp_path / "state.json")
        
        result = await orchestrator.run()
        
        # Verify regeneration happened
        assert mock_text.call_count == 2
        
        # Verify final content is good
        assert result.status == "success"
        assert "delve" not in result.draft.body.lower()
        assert "tapestry" not in result.draft.body.lower()


@pytest.mark.asyncio
async def test_workflow_handles_rate_limiting(test_config, mock_commits, tmp_path):
    """Test workflow respects rate limits."""
    
    state_path = tmp_path / "state.json"
    state = StateManager(state_path)
    
    # Simulate recent post
    state.update_last_post(title="Recent Post")
    
    with patch('wishlistops.git_parser.GitParser.get_player_facing_commits') as mock_git:
        mock_git.return_value = mock_commits
        
        orchestrator = WishlistOpsOrchestrator(tmp_path / "config.json")
        orchestrator.config = test_config
        orchestrator.state = state
        
        # Try to run (should be rate limited)
        result = await orchestrator.run()
        
        assert result.status == "skipped"
        assert result.reason == "rate_limit"


@pytest.mark.asyncio
async def test_workflow_error_handling(test_config, mock_commits, tmp_path):
    """Test workflow handles errors gracefully."""
    
    with patch('wishlistops.git_parser.GitParser.get_player_facing_commits') as mock_git, \
         patch('wishlistops.ai_client.GeminiClient.generate_text') as mock_text, \
         patch('wishlistops.discord_notifier.DiscordNotifier.send_error') as mock_error:
        
        mock_git.return_value = mock_commits
        
        # Simulate API failure
        mock_text.side_effect = Exception("API Error")
        
        mock_error.return_value = True
        
        orchestrator = WishlistOpsOrchestrator(tmp_path / "config.json")
        orchestrator.config = test_config
        orchestrator.state = StateManager(tmp_path / "state.json")
        
        # Run should raise exception
        with pytest.raises(Exception, match="API Error"):
            await orchestrator.run()
        
        # Verify error notification was sent
        mock_error.assert_called_once()
        
        # Verify state recorded failure
        assert orchestrator.state.state.failed_runs == 1


@pytest.mark.asyncio
async def test_image_compositor_integration(test_config, tmp_path):
    """Test image compositor integrates correctly."""
    from wishlistops.image_compositor import ImageCompositor
    from PIL import Image
    from io import BytesIO
    
    # Create test logo
    logo_path = tmp_path / "logo.png"
    logo = Image.new('RGBA', (200, 200), color=(255, 0, 0, 255))
    logo.save(logo_path)
    
    test_config.branding.logo_path = str(logo_path)
    
    # Create test base image
    base_image = Image.new('RGB', (1024, 576), color='blue')
    buffer = BytesIO()
    base_image.save(buffer, format='PNG')
    base_image_bytes = buffer.getvalue()
    
    # Composite
    compositor = ImageCompositor(test_config.branding)
    result = compositor.composite_logo(base_image_bytes)
    
    # Verify result
    assert len(result) > 0
    
    result_image = Image.open(BytesIO(result))
    assert result_image.size == (800, 450)  # Steam specs


def test_configuration_validation():
    """Test configuration validation catches errors."""
    from pydantic import ValidationError
    
    # Missing required fields
    with pytest.raises(ValidationError):
        Config(steam={"app_id": "invalid"})
    
    # Invalid Steam App ID
    with pytest.raises(ValidationError):
        Config(
            steam={"app_id": "abc", "app_name": "Test"},
            branding={"art_style": "test"}
        )


def test_state_persistence_between_runs(tmp_path):
    """Test state persists correctly between workflow runs."""
    state_path = tmp_path / "state.json"
    
    # First run
    state1 = StateManager(state_path)
    state1.update_last_run(status="success", tag="v1.0.0")
    
    # Second run (new instance)
    state2 = StateManager(state_path)
    
    assert state2.state.total_runs == 1
    assert state2.state.last_tag == "v1.0.0"
    
    # Third run
    state2.update_last_run(status="success", tag="v1.1.0")
    
    # Fourth run (verify count)
    state3 = StateManager(state_path)
    assert state3.state.total_runs == 2


@pytest.mark.integration
@pytest.mark.asyncio
async def test_real_api_integration():
    """
    Test with real APIs (requires API keys in environment).
    
    This test is skipped in CI but useful for local validation.
    """
    import os
    
    api_key = os.getenv('GOOGLE_AI_KEY')
    if not api_key:
        pytest.skip("GOOGLE_AI_KEY not set")
    
    from wishlistops.ai_client import GeminiClient
    from wishlistops.models import AIConfig
    
    config = AIConfig()
    
    async with GeminiClient(api_key, config) as client:
        result = await client.generate_text(
            prompt="Write a short announcement about adding a new weapon to a game.",
            system_instruction="You are a friendly indie game developer."
        )
        
        assert result.title
        assert result.body
        assert len(result.body) > 50
        
        # Verify content filter
        from wishlistops.content_filter import ContentFilter
        filter = ContentFilter()
        filter_result = filter.check(result.body)
        
        # Content should be reasonably good
        assert filter_result.score > 0.5


# Performance tests
@pytest.mark.performance
@pytest.mark.asyncio
async def test_workflow_completes_within_time_limit(test_config, mock_commits, tmp_path):
    """Test workflow completes within expected time (60 seconds)."""
    import time
    
    with patch('wishlistops.git_parser.GitParser.get_player_facing_commits') as mock_git, \
         patch('wishlistops.ai_client.GeminiClient.generate_text') as mock_text, \
         patch('wishlistops.ai_client.GeminiClient.generate_image') as mock_image, \
         patch('wishlistops.discord_notifier.DiscordNotifier._send_webhook') as mock_discord:
        
        mock_git.return_value = mock_commits
        mock_text.return_value = TextGenerationResult(
            title="Test", body="Test body with enough content to pass validation.", metadata={}
        )
        mock_image.return_value = ImageGenerationResult(
            image_data=b"fake", width=800, height=450, metadata={}
        )
        mock_discord.return_value = None
        
        orchestrator = WishlistOpsOrchestrator(tmp_path / "config.json")
        orchestrator.config = test_config
        orchestrator.state = StateManager(tmp_path / "state.json")
        
        start = time.time()
        result = await orchestrator.run()
        duration = time.time() - start
        
        assert result.status == "success"
        assert duration < 60  # Should complete in under 60 seconds
```

QUALITY CHECKLIST:
- [ ] Tests complete workflow
- [ ] Tests error handling
- [ ] Tests rate limiting
- [ ] Tests content filtering
- [ ] Tests state persistence
- [ ] Tests configuration validation
- [ ] Includes performance tests
- [ ] Uses mocks appropriately
- [ ] Has real API tests (optional)

OUTPUT:
- File: tests/test_integration.py (400-500 lines)
```

**Expected Output:**
- Comprehensive integration tests
- End-to-end workflow coverage
- Error path testing
- Performance validation

**Testing:**
```bash
# Run integration tests
pytest tests/test_integration.py -v

# Run with coverage
pytest tests/test_integration.py --cov=wishlistops --cov-report=html

# Run performance tests
pytest tests/test_integration.py -v -m performance

# Run real API tests (optional)
export GOOGLE_AI_KEY='your-key'
pytest tests/test_integration.py -v -m integration
```

**Success Criteria:**
- [ ] All integration tests pass
- [ ] End-to-end workflow works
- [ ] Error handling verified
- [ ] Rate limiting works
- [ ] Performance acceptable (<60s)
- [ ] Code coverage >80%

---

## 📝 TASK 3 COMPLETION CHECKLIST

After Task 3, you should have:

**Files Created:**
- [ ] `wishlistops/content_filter.py` (Anti-slop filter)
- [ ] `wishlistops/image_compositor.py` (Logo overlay)
- [ ] `tests/test_content_filter.py`
- [ ] `tests/test_image_compositor.py`
- [ ] `tests/test_integration.py` (E2E tests)

**System Capabilities:**
- [ ] Content quality filtering works
- [ ] Image compositing works
- [ ] End-to-end workflow tested
- [ ] All quality gates operational

**Integration Test Results:**
```bash
# Run all tests
pytest tests/ -v

# Expected output:
# test_content_filter.py .......... (10 tests)
# test_image_compositor.py ........ (8 tests)
# test_integration.py ............ (10 tests)
# 
# ==================== 28 passed ====================
```

**Ready for Task 4:** Web dashboard for non-programmers

---
