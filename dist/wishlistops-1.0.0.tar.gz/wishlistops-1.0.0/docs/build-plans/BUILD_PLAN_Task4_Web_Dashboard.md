﻿# WishlistOps Build Plan - Task 4: Web Dashboard
## Day 5-7: Non-Programmer Interface

---

## 🎯 TASK 4 OVERVIEW

**Goal:** Create a web dashboard that allows non-programmers to configure and use WishlistOps.

**Timeline:** Day 5-7 (3 days)

**Dependencies:** Task 1.3 complete (config system exists)

**Components to Build:**
1. Static HTML/JS/CSS dashboard
2. GitHub API integration (read/write config files)
3. OAuth authentication flow
4. Visual configuration editor

**Success Criteria:**
- [ ] Non-programmer can configure WishlistOps via web UI
- [ ] Changes saved to Git repository
- [ ] OAuth authentication works
- [ ] Mobile-responsive design
- [ ] Works without backend server (GitHub Pages)

---

## 🔧 TASK 4.1: Static Site Dashboard (HTML/CSS/JS)

**Files:** `dashboard/index.html`, `dashboard/app.js`, `dashboard/styles.css`

**Prompt for AI Agent:**

```
CONTEXT:
You are creating a web-based dashboard for WishlistOps that allows non-technical team members (artists, community managers) to configure the system. This solves the "Git-Wall" problem identified in 05_WishlistOps_Revised_Architecture.md.

ARCHITECTURE REFERENCE:
- See "Fix #1: Dual Interface" in 05_WishlistOps_Revised_Architecture.md
- See "User Journey Flow" showing dashboard usage
- Must be deployable to GitHub Pages (static site only, no backend)

WHY THIS MATTERS:
90% of indie teams have non-programmers who manage Steam. If they can't use the tool, it fails. The dashboard must be:
- Simple enough for non-technical users
- Powerful enough to configure everything
- Beautiful enough to inspire confidence

TECHNICAL CONSTRAINTS:
- Static site only (HTML/CSS/JS - no backend)
- Must work on GitHub Pages (free hosting)
- Uses GitHub API directly from browser
- OAuth for authentication
- Responsive design (mobile-friendly)

USER WORKFLOW:
1. User visits dashboard URL
2. Clicks "Sign in with GitHub"
3. Authorizes app (OAuth)
4. Sees list of their repositories
5. Selects WishlistOps-enabled repo
6. Edits config visually (forms, not JSON)
7. Clicks "Save" - commits to Git
8. Done!

IMPLEMENTATION:

FILE 1: dashboard/index.html
```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WishlistOps Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="header-content">
                <h1 class="logo">🎮 WishlistOps</h1>
                <p class="tagline">Automated Steam Marketing for Indie Developers</p>
                <div id="auth-section">
                    <button id="sign-in-btn" class="btn btn-primary">
                        Sign in with GitHub
                    </button>
                    <div id="user-info" class="user-info hidden">
                        <img id="user-avatar" class="avatar" alt="User avatar">
                        <span id="user-name"></span>
                        <button id="sign-out-btn" class="btn btn-secondary">Sign Out</button>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main class="main container">
        <!-- Loading State -->
        <div id="loading" class="loading hidden">
            <div class="spinner"></div>
            <p>Loading...</p>
        </div>

        <!-- Welcome Screen (not signed in) -->
        <div id="welcome-screen" class="welcome-screen">
            <h2>Welcome to WishlistOps</h2>
            <p>Automate your Steam marketing so you can focus on game development.</p>
            <div class="features">
                <div class="feature">
                    <h3>✨ AI-Generated Announcements</h3>
                    <p>Automatically create Steam announcements from your Git commits</p>
                </div>
                <div class="feature">
                    <h3>🎨 Beautiful Banners</h3>
                    <p>AI generates custom banners with your game's logo</p>
                </div>
                <div class="feature">
                    <h3>✅ Human Approval</h3>
                    <p>Review in Discord before posting to Steam</p>
                </div>
            </div>
            <button class="btn btn-primary btn-large" onclick="document.getElementById('sign-in-btn').click()">
                Get Started
            </button>
        </div>

        <!-- Repository Selection -->
        <div id="repo-selection" class="hidden">
            <h2>Select Repository</h2>
            <p>Choose the repository you want to configure for WishlistOps:</p>
            <div id="repos-list" class="repos-list"></div>
        </div>

        <!-- Configuration Editor -->
        <div id="config-editor" class="hidden">
            <div class="editor-header">
                <h2 id="current-repo-name"></h2>
                <button id="back-to-repos" class="btn btn-secondary">← Back to Repositories</button>
            </div>

            <!-- Status Messages -->
            <div id="status-message" class="hidden"></div>

            <!-- Configuration Form -->
            <form id="config-form" class="config-form">
                
                <!-- Steam Settings -->
                <section class="config-section">
                    <h3>Steam Configuration</h3>
                    <div class="form-group">
                        <label for="steam-app-id">Steam App ID *</label>
                        <input type="text" id="steam-app-id" pattern="[0-9]{6,7}" required
                               placeholder="e.g., 480">
                        <small>Find this in your Steamworks dashboard</small>
                    </div>
                    <div class="form-group">
                        <label for="steam-app-name">Game Name *</label>
                        <input type="text" id="steam-app-name" required
                               placeholder="e.g., My Awesome Game">
                    </div>
                </section>

                <!-- Branding Settings -->
                <section class="config-section">
                    <h3>Branding</h3>
                    <div class="form-group">
                        <label for="art-style">Art Style *</label>
                        <input type="text" id="art-style" required
                               placeholder="e.g., pixel art fantasy, low poly sci-fi">
                        <small>Describe your game's visual style for AI image generation</small>
                    </div>
                    <div class="form-group">
                        <label for="color-palette">Color Palette</label>
                        <input type="text" id="color-palette"
                               placeholder="e.g., #FF6B6B, #4ECDC4, #FFE66D">
                        <small>Hex color codes separated by commas (optional)</small>
                    </div>
                    <div class="form-group">
                        <label for="logo-position">Logo Position</label>
                        <select id="logo-position">
                            <option value="top-right">Top Right</option>
                            <option value="top-left">Top Left</option>
                            <option value="center">Center</option>
                            <option value="bottom-right">Bottom Right</option>
                            <option value="bottom-left">Bottom Left</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="logo-size">Logo Size (%)</label>
                        <input type="range" id="logo-size" min="10" max="50" value="25">
                        <output id="logo-size-value">25%</output>
                    </div>
                </section>

                <!-- Voice Settings -->
                <section class="config-section">
                    <h3>Writing Voice</h3>
                    <div class="form-group">
                        <label for="tone">Tone</label>
                        <input type="text" id="tone"
                               placeholder="e.g., casual and excited">
                    </div>
                    <div class="form-group">
                        <label for="personality">Personality</label>
                        <input type="text" id="personality"
                               placeholder="e.g., friendly indie developer">
                    </div>
                    <div class="form-group">
                        <label for="avoid-phrases">Avoid Phrases</label>
                        <input type="text" id="avoid-phrases"
                               placeholder="e.g., monetization, grind, lootbox">
                        <small>Words/phrases to avoid in announcements (comma-separated)</small>
                    </div>
                </section>

                <!-- Automation Settings -->
                <section class="config-section">
                    <h3>Automation</h3>
                    <div class="form-group checkbox-group">
                        <label>
                            <input type="checkbox" id="automation-enabled" checked>
                            Enable automation
                        </label>
                    </div>
                    <div class="form-group checkbox-group">
                        <label>
                            <input type="checkbox" id="trigger-on-tags" checked>
                            Trigger on Git tags
                        </label>
                    </div>
                    <div class="form-group">
                        <label for="min-days">Minimum Days Between Posts</label>
                        <input type="number" id="min-days" min="1" max="30" value="7">
                        <small>Rate limiting (prevents spam)</small>
                    </div>
                    <div class="form-group checkbox-group">
                        <label>
                            <input type="checkbox" id="require-approval" checked>
                            Require manual approval (Discord)
                        </label>
                    </div>
                </section>

                <!-- AI Settings -->
                <section class="config-section">
                    <h3>AI Settings (Advanced)</h3>
                    <div class="form-group">
                        <label for="temperature">Creativity Level</label>
                        <input type="range" id="temperature" min="0" max="1" step="0.1" value="0.7">
                        <output id="temperature-value">0.7</output>
                        <small>0 = consistent, 1 = creative</small>
                    </div>
                </section>

                <!-- Action Buttons -->
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary btn-large">
                        💾 Save Configuration
                    </button>
                    <button type="button" id="preview-btn" class="btn btn-secondary">
                        👁️ Preview JSON
                    </button>
                </div>
            </form>
        </div>

        <!-- JSON Preview Modal -->
        <div id="preview-modal" class="modal hidden">
            <div class="modal-content">
                <span class="close">&times;</span>
                <h3>Configuration Preview</h3>
                <pre><code id="preview-json"></code></pre>
                <button class="btn btn-secondary" onclick="document.getElementById('preview-modal').classList.add('hidden')">
                    Close
                </button>
            </div>
        </div>

    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <p>&copy; 2025 WishlistOps | <a href="https://github.com/your-org/wishlistops">GitHub</a> | <a href="docs.html">Documentation</a></p>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="app.js"></script>
</body>
</html>
```

FILE 2: dashboard/styles.css
```css
/* WishlistOps Dashboard Styles */

:root {
    --primary-color: #5865F2;
    --secondary-color: #57F287;
    --danger-color: #ED4245;
    --background: #36393F;
    --surface: #2F3136;
    --text-primary: #FFFFFF;
    --text-secondary: #B9BBBE;
    --border: #202225;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: var(--background);
    color: var(--text-primary);
    line-height: 1.6;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
}

/* Header */
.header {
    background: var(--surface);
    border-bottom: 2px solid var(--border);
    padding: 20px 0;
}

.header-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 20px;
}

.logo {
    font-size: 24px;
    font-weight: bold;
    color: var(--primary-color);
}

.tagline {
    color: var(--text-secondary);
    font-size: 14px;
}

/* Buttons */
.btn {
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s;
}

.btn-primary {
    background: var(--primary-color);
    color: white;
}

.btn-primary:hover {
    background: #4752C4;
}

.btn-secondary {
    background: var(--border);
    color: var(--text-primary);
}

.btn-secondary:hover {
    background: #3a3d43;
}

.btn-large {
    padding: 15px 30px;
    font-size: 16px;
}

/* User Info */
.user-info {
    display: flex;
    align-items: center;
    gap: 10px;
}

.avatar {
    width: 32px;
    height: 32px;
    border-radius: 50%;
}

/* Main Content */
.main {
    min-height: calc(100vh - 200px);
    padding: 40px 20px;
}

/* Welcome Screen */
.welcome-screen {
    text-align: center;
    max-width: 800px;
    margin: 0 auto;
}

.welcome-screen h2 {
    font-size: 36px;
    margin-bottom: 20px;
}

.features {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 30px;
    margin: 40px 0;
}

.feature {
    background: var(--surface);
    padding: 30px;
    border-radius: 10px;
    border: 1px solid var(--border);
}

.feature h3 {
    margin-bottom: 10px;
    color: var(--secondary-color);
}

/* Config Form */
.config-form {
    background: var(--surface);
    padding: 30px;
    border-radius: 10px;
    border: 1px solid var(--border);
}

.config-section {
    margin-bottom: 40px;
}

.config-section h3 {
    color: var(--secondary-color);
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 2px solid var(--border);
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
    color: var(--text-primary);
}

.form-group input[type="text"],
.form-group input[type="number"],
.form-group select,
.form-group textarea {
    width: 100%;
    padding: 12px;
    background: var(--background);
    border: 1px solid var(--border);
    border-radius: 5px;
    color: var(--text-primary);
    font-size: 14px;
}

.form-group input[type="range"] {
    width: 100%;
}

.form-group small {
    display: block;
    margin-top: 5px;
    color: var(--text-secondary);
    font-size: 12px;
}

.form-actions {
    display: flex;
    gap: 15px;
    margin-top: 30px;
}

/* Status Messages */
.status-message {
    padding: 15px;
    border-radius: 5px;
    margin-bottom: 20px;
}

.status-success {
    background: rgba(87, 242, 135, 0.1);
    border: 1px solid var(--secondary-color);
    color: var(--secondary-color);
}

.status-error {
    background: rgba(237, 66, 69, 0.1);
    border: 1px solid var(--danger-color);
    color: var(--danger-color);
}

/* Loading */
.loading {
    text-align: center;
    padding: 60px;
}

.spinner {
    border: 4px solid var(--border);
    border-top: 4px solid var(--primary-color);
    border-radius: 50%;
    width: 50px;
    height: 50px;
    animation: spin 1s linear infinite;
    margin: 0 auto 20px;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

/* Modal */
.modal {
    display: none;
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.8);
}

.modal.visible {
    display: flex;
    align-items: center;
    justify-content: center;
}

.modal-content {
    background: var(--surface);
    padding: 30px;
    border-radius: 10px;
    max-width: 600px;
    width: 90%;
    max-height: 80vh;
    overflow-y: auto;
}

.modal pre {
    background: var(--background);
    padding: 15px;
    border-radius: 5px;
    overflow-x: auto;
}

/* Utility Classes */
.hidden {
    display: none !important;
}

/* Responsive */
@media (max-width: 768px) {
    .header-content {
        flex-direction: column;
        text-align: center;
    }
    
    .features {
        grid-template-columns: 1fr;
    }
    
    .form-actions {
        flex-direction: column;
    }
}

/* Footer */
.footer {
    background: var(--surface);
    border-top: 2px solid var(--border);
    padding: 20px 0;
    text-align: center;
    color: var(--text-secondary);
}

.footer a {
    color: var(--primary-color);
    text-decoration: none;
}

.footer a:hover {
    text-decoration: underline;
}
```

QUALITY CHECKLIST:
- [ ] Semantic HTML5
- [ ] Responsive design (mobile-friendly)
- [ ] Accessible (ARIA labels where needed)
- [ ] Modern CSS (Grid, Flexbox)
- [ ] Clean, maintainable code
- [ ] Works without JavaScript (graceful degradation)
- [ ] Fast loading (minimal dependencies)

OUTPUT:
- File: dashboard/index.html (300-400 lines)
- File: dashboard/styles.css (300-400 lines)
```

**Expected Output:**
- Beautiful, modern dashboard UI
- Responsive design
- Professional appearance
- Ready for JavaScript integration

**Testing:**
```bash
# Serve locally
python -m http.server 8000 -d dashboard

# Open browser
open http://localhost:8000

# Test on mobile
# Use browser dev tools responsive mode
```

**Success Criteria:**
- [ ] UI loads correctly
- [ ] Form inputs work
- [ ] Responsive on mobile
- [ ] Professional appearance
- [ ] No console errors

---
