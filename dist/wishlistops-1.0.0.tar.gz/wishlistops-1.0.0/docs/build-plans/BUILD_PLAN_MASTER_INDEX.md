﻿# WishlistOps Build Plan - Master Index
## Complete Implementation Guide for AI Coding Agents

---

## 📚 Document Structure

This build plan is split into manageable files for easier navigation:

### 📄 Core Files

1. **BUILD_PLAN_Week1_Critical_Features.md** ⭐
   - Project context and big picture
   - Task 1: Core GitHub Action Workflow
     - Task 1.1: GitHub Action YAML
     - Task 1.2: Python Orchestrator (main.py)
     - Task 1.3: Configuration System (models.py, config_manager.py)

2. **BUILD_PLAN_Task2_AI_Discord.md**
   - Task 2.1: Git Commit Parser
   - Task 2.2: Gemini AI Client (text + image)
   - Task 2.3: Discord Notifier with approval
   - Task 2.4: State Manager

3. **BUILD_PLAN_Task3_Quality_Filter.md**
   - Task 3.1: Anti-Slop Content Filter
   - Task 3.2: Image Compositor (logo overlay)
   - Task 3.3: Integration Testing

4. **BUILD_PLAN_Task4_Web_Dashboard.md**
   - Task 4.1: GitHub Pages Static Site
   - Task 4.2: GitHub API Integration
   - Task 4.3: OAuth Flow
   - Task 4.4: Visual Config Editor

---

## 🎯 Quick Start Guide

### For First-Time Implementation

**Step 1:** Read the project context
- File: `BUILD_PLAN_Week1_Critical_Features.md`
- Section: "PROJECT CONTEXT & BIG PICTURE"
- Time: 10 minutes

**Step 2:** Understand the architecture
- Reference: `04_WishlistOps_System_Architecture_Diagrams.md`
- Reference: `05_WishlistOps_Revised_Architecture.md`
- Time: 20 minutes

**Step 3:** Start implementing Task 1
- File: `BUILD_PLAN_Week1_Critical_Features.md`
- Start with: Task 1.1 (GitHub Action)
- Time: 2-3 hours

**Step 4:** Continue sequentially
- Complete all of Task 1 before Task 2
- Complete all of Task 2 before Task 3
- Each task builds on the previous

---

## ✅ Implementation Checklist

### Day 1-2: Task 1 (Core Infrastructure)
- [ ] Task 1.1: GitHub Action workflow created
- [ ] Task 1.2: Main orchestrator implemented
- [ ] Task 1.3: Configuration system complete
- [ ] All Task 1 tests pass
- [ ] Integration test passes

### Day 2-3: Task 2 (AI & Discord)
- [ ] Task 2.1: Git parser implemented
- [ ] Task 2.2: AI client complete
- [ ] Task 2.3: Discord notifier working
- [ ] Task 2.4: State manager functional
- [ ] End-to-end test with real APIs

### Day 3-4: Task 3 (Quality Control)
- [ ] Task 3.1: Anti-slop filter working
- [ ] Task 3.2: Image compositor ready
- [ ] Task 3.3: All integration tests pass
- [ ] Beta testing with 5 users

### Day 5-7: Task 4 (Web Dashboard)
- [ ] Task 4.1: Static site deployed
- [ ] Task 4.2: GitHub API integration
- [ ] Task 4.3: OAuth working
- [ ] Task 4.4: Config editor functional
- [ ] User testing complete

---

## 🔍 Key Principles for AI Coding Agents

### 1. Context is Everything
Every prompt includes:
- **CONTEXT:** What you're building and why
- **ARCHITECTURE REFERENCE:** Links to relevant diagrams
- **WHY THIS MATTERS:** Business/user impact
- **TECHNICAL REQUIREMENTS:** Specific constraints

### 2. Quality Over Speed
- Type hints on ALL functions
- Docstrings in Google style
- Comprehensive error handling
- Structured logging (JSON format)
- Unit tests for all components

### 3. Anti-Patterns to Avoid
- ❌ No print() statements (use logging)
- ❌ No hardcoded secrets
- ❌ No global mutable state
- ❌ No catching Exception without re-raising
- ❌ No skipping type hints
- ❌ No deprecated dependencies

### 4. Testing Philosophy
- Unit tests for logic
- Integration tests for APIs
- Mock external dependencies
- Test error scenarios
- Test idempotency (can re-run safely)

### 5. Code Style Standards
- **Python:** Black formatter, Pylint score >9.0, mypy --strict
- **YAML:** 2-space indentation, yamllint compliant
- **JSON:** 2-space indentation, valid syntax
- **Markdown:** Proper headers, code fences

---

## 📊 Progress Tracking

### Task Completion Matrix

| Task | File | Status | Time Est. | Dependencies |
|------|------|--------|-----------|--------------|
| 1.1 | GitHub Action YAML | ⬜ | 2h | None |
| 1.2 | Main Orchestrator | ⬜ | 4h | 1.1 |
| 1.3 | Config System | ⬜ | 3h | 1.2 |
| 2.1 | Git Parser | ⬜ | 3h | 1.3 |
| 2.2 | AI Client | ⬜ | 4h | 1.3 |
| 2.3 | Discord Notifier | ⬜ | 2h | 1.3 |
| 2.4 | State Manager | ⬜ | 2h | 1.3 |
| 3.1 | Content Filter | ⬜ | 3h | 2.2 |
| 3.2 | Image Compositor | ⬜ | 3h | 2.2 |
| 3.3 | Integration Tests | ⬜ | 2h | All above |
| 4.1 | Static Site | ⬜ | 4h | None |
| 4.2 | GitHub API | ⬜ | 3h | 4.1 |
| 4.3 | OAuth Flow | ⬜ | 3h | 4.2 |
| 4.4 | Config Editor | ⬜ | 4h | 4.3 |

**Total Time:** ~42 hours (split over 7 days = 6 hours/day)

---

## 🎓 Learning Path for AI Agents

### Understanding the System

**Level 1: Basic Understanding** (Read these first)
1. `05_WishlistOps_Revised_Architecture.md` - Production architecture
2. `BUILD_PLAN_Week1_Critical_Features.md` - Project context

**Level 2: Technical Details** (Reference during implementation)
1. `04_WishlistOps_System_Architecture_Diagrams.md` - All diagrams
2. `03_WishlistOps_Technical_Architecture.md` - Deep technical details

**Level 3: Business Context** (Optional, for understanding WHY)
1. `02_WishlistOps_Business_Blueprint.md` - Business strategy
2. `01_Creator_Economy_AI_SaaS_Opportunities.md` - Market analysis

### Implementation Order

**Phase 1: Foundation** (Cannot skip)
- Task 1.1 → Task 1.2 → Task 1.3
- Each builds on the previous
- Must complete in order

**Phase 2: Core Features** (Some parallelization possible)
- Task 2.1, 2.2, 2.3, 2.4 can be done in parallel if multiple agents
- But each needs Task 1 complete first

**Phase 3: Quality** (Depends on Phase 2)
- Task 3.1 needs 2.2 (AI client)
- Task 3.2 needs 2.2 (AI client)
- Task 3.3 needs everything

**Phase 4: Dashboard** (Can start early, but integrate late)
- Task 4 can start after Task 1.3 (config system exists)
- Integration happens after Task 3 complete

---

## 🚨 Common Pitfalls & Solutions

### Pitfall 1: "Works on my machine"
**Problem:** Code works locally but fails in GitHub Actions
**Solution:** Test with `act` (local GitHub Actions runner)
**Prevention:** Always include timeout limits and error handling

### Pitfall 2: "API keys not found"
**Problem:** Secrets not accessible in different environments
**Solution:** Clear error messages pointing to setup docs
**Prevention:** Validate secrets early in workflow

### Pitfall 3: "AI generates garbage"
**Problem:** Content filter not catching bad outputs
**Solution:** Add more specific patterns to filter
**Prevention:** Test filter with intentionally bad inputs

### Pitfall 4: "State file corrupted"
**Problem:** Partial writes or concurrent access
**Solution:** Use atomic writes (write to temp, then rename)
**Prevention:** Add validation on state load

### Pitfall 5: "Dashboard can't save config"
**Problem:** CORS errors or authentication failures
**Solution:** Proper GitHub OAuth scope and error handling
**Prevention:** Test with multiple browsers

---

## 📞 Getting Help

### When Stuck on a Task

**Step 1:** Re-read the task prompt
- Every prompt has CONTEXT, REQUIREMENTS, and VERIFICATION
- Check you haven't missed a requirement

**Step 2:** Check architecture diagrams
- Visual representation often clarifies text descriptions
- See `04_WishlistOps_System_Architecture_Diagrams.md`

**Step 3:** Look at similar code
- If stuck on Discord, see how Gemini API is called
- Similar patterns are used throughout

**Step 4:** Check example repos
- GitHub Actions examples: https://github.com/actions/starter-workflows
- Pydantic examples: https://docs.pydantic.dev/

### Debugging Checklist

When code doesn't work:
- [ ] Check logs (structured JSON format)
- [ ] Verify environment variables are set
- [ ] Test API credentials manually (curl)
- [ ] Check file permissions
- [ ] Verify Git repository is valid
- [ ] Test with --dry-run flag
- [ ] Run linters (mypy, pylint, yamllint)
- [ ] Check for typos in config.json

---

## 🎯 Success Metrics

### Task-Level Success

**Each task is complete when:**
1. All code files created
2. All tests pass
3. Linters show no errors
4. Documentation updated
5. Integration test passes

### Week-Level Success

**Week 1 is complete when:**
1. End-to-end workflow runs successfully
2. Draft announcement generated
3. Discord notification sent
4. Team can review in Discord
5. Non-programmer can use dashboard
6. All quality gates working
7. 5 beta testers successfully onboarded

---

## 📚 Additional Resources

### Documentation to Create

As you implement, create these docs:
- `SETUP.md` - How to set up development environment
- `TESTING.md` - How to run tests
- `DEPLOYMENT.md` - How to deploy to production
- `TROUBLESHOOTING.md` - Common issues and solutions
- `API.md` - API documentation for modules

### Tools to Use

**Development:**
- VS Code with Python extension
- GitHub Copilot (optional, for faster coding)
- Docker (for consistent environment)

**Testing:**
- pytest (unit tests)
- act (GitHub Actions testing)
- Postman (API testing)

**Quality:**
- mypy (type checking)
- pylint (linting)
- black (formatting)
- yamllint (YAML validation)

---

## 🎬 Next Steps

1. **Read Week 1 build plan:** `BUILD_PLAN_Week1_Critical_Features.md`
2. **Start Task 1.1:** GitHub Action workflow
3. **Follow prompts exactly:** They contain all requirements
4. **Test after each task:** Don't accumulate errors
5. **Commit frequently:** Small, atomic commits

**Remember:** Quality over speed. It's better to do Task 1 perfectly than to rush through all tasks with bugs.

---

*Build Plan Version: 1.0*  
*Status: Ready for Implementation*  
*Estimated Total Time: 42 hours over 7 days*

**Let's build something that helps indie developers win! 🚀**
