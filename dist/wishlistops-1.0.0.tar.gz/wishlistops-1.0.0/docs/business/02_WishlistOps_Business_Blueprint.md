# WishlistOps: The "Publisher-in-a-Box" Business Blueprint

## 1. Executive Summary: The "DevOps for Marketing" Pivot

You are entering a market where the primary pain point is not "creating" content, but **operational consistency**. Indie developers fail because they stop marketing when they start coding. Your product, **"WishlistOps,"** is not just a content generator; it is an infrastructure tool that treats marketing updates like code commits.

By leveraging your **Google AI Pro (Gemini 2.5 Flash/Imagen 3)** and **GitHub Pro (Actions/Codespaces)** plans, you can build a "Serverless Marketing Engine" with near-zero overhead. The strategy shifts from a traditional SaaS (monthly fee) to a **"Licensing + BYOK (Bring Your Own Key)"** model, protecting you from API cost scaling while appealing to the budget-conscious indie developer.

---

## 2. The Tech Stack: Weaponizing Your Pro Plans

You have access to enterprise-grade infrastructure for free. Here is how to architect the solution to maximize these specific assets.

### 2.1 The Brain: Google AI Pro & "Nano Banana" (Gemini 2.5 Flash Image)

**The Model:** You mentioned "Nano Banana." In the current Google ecosystem, this refers to **Gemini 2.5 Flash Image** (often nicknamed or associated with "Nano" for its speed and efficiency in recent dev circles). It is the SOTA (State-of-the-Art) model for high-fidelity, text-rich image generation.

**Why it wins for Steam:**
- Unlike Midjourney (which requires Discord) or Stable Diffusion (which requires heavy GPU), Gemini 2.5 Flash Image handles **text rendering exceptionally well**.
- Steam capsules must have **legible logos**.

**Implementation:**
- **Visuals:** Use Gemini 2.5 Flash Image to generate the background art based on the patch notes.
- **Text/Logo:** Do not rely on AI for the game logo. Use a Python script (Pillow library) to composite the developer's existing transparent PNG logo onto the AI-generated background. This ensures brand consistency.
- **Context Window:** Use Gemini 1.5 Pro's **2 Million Token Context** to load the game's entire "Lore Bible" and previous patch notes. This ensures the AI writes updates in the exact voice of the game (e.g., "The Kingdom expands..." vs. "Added new level").

### 2.2 The Nervous System: GitHub Pro (Actions & Codespaces)

**GitHub Actions (3,000 Minutes/Month):** This is your "backend server."

**Workflow:**
1. A developer pushes a tag (e.g., `v1.2.0`) to their repo. This triggers a GitHub Action.

**The Action:**
- Parses the git log since the last tag.
- Sends logs to Gemini 1.5 Pro to draft a Steam Announcement.
- Sends a prompt to Gemini 2.5 Flash Image to generate a banner.
- Composites the Game Logo onto the banner.
- **Crucial:** Uploads the draft to Steam as a "Hidden" Announcement for review.

**GitHub Codespaces (180 Hours/Month):**

**The Sales Demo:** Instead of building a complex web app with user auth, create a public template repository.

**The Hook:** "Try it instantly."
- Users click "Open in Codespaces" on your repo. It spins up a VS Code environment in their browser with your tool pre-configured.
- They enter their Steam API Key and test the tool on a fake game project.
- This removes friction: they are not installing anything, not signing up for a waitlist—they are using the product in 2 minutes.

### 2.3 The Glue: Steamworks Web API

**Critical APIs:**
- **ISteamNews:** Post announcements programmatically.
- **ISteamRemoteStorage:** Upload the generated banner images.
- **Partner API (Requires App Admin Access):** This is the gatekeeper. Developers must generate a "Publisher Web API Key" from their Steamworks account.

**The Risk:** Steam does not have official Python SDKs. You will be using undocumented endpoints (reverse-engineered by the community, like `steamworks-py`).

**Mitigation:** Build a fallback mode. If the API call fails, save the draft locally as a Markdown file + PNG, and the developer manually copies/pastes into Steam.

---

## 3. The Product Roadmap: 7 Days to Traction

**Constraint:** You need market validation before scaling. Here is a rapid iteration plan.

### Day 1-2: The "Toy" Version (GitHub Action Template)

**Build:**
- A single GitHub Action YAML file.
- On `git tag`, it reads the commit log, calls Gemini API, and outputs a formatted Markdown file.
- No Steam integration yet—just a proof of concept.

**Ship:**
- Post on Reddit (`r/gamedev`, `r/IndieDev`) as a free template.
- Title: "I built a GitHub Action that auto-writes patch notes for indie devs."

**Goal:** 100+ stars on the repo in 48 hours.

### Day 3-4: Add Visual Generation

**Build:**
- Integrate Gemini 2.5 Flash Image.
- The Action now generates a Steam-ready 800x450px banner.
- Use Pillow to overlay the developer's logo.

**Ship:**
- Update the Reddit thread with a demo video.
- Cross-post to Twitter/X and tag indie dev influencers.

**Goal:** First 10 developers request Steam integration.

### Day 5-7: Steam Integration (Beta)

**Build:**
- Add Steamworks API calls.
- Require users to add their Steam API key as a GitHub Secret.
- Upload the announcement as "Hidden" for manual review.

**Ship:**
- Invite the 10 developers from Day 4 to beta test.
- Create a landing page: "WishlistOps: The DevOps Tool for Steam Marketing."

**Goal:** First paying customer at $49 lifetime license.

---

## 4. Deep Dive: Monetization & Business Model

**Verdict: Lifetime License + BYOK (Bring Your Own Key)**

The research is clear: indie developers are **price-sensitive** but **value-aware**. They will pay once for a tool that saves them hours, but they will churn from a $29/month subscription.

### 4.1 The Pricing Model

**Tier 1: Free (GitHub Template)**
- The basic GitHub Action (text-only announcements).
- No support, no updates.
- **Purpose:** Lead magnet. Get developers addicted to automation.

**Tier 2: Pro License ($99 Lifetime)**
- Visual generation (banners).
- Steam API integration.
- Priority support (Discord channel).
- **BYOK:** They use their own Google AI API key. You are not paying for their usage.

**Tier 3: Studio License ($299 Lifetime)**
- Multi-game support.
- Team collaboration features (shared templates).
- Custom branding (white-label the tool for publishers).

### 4.2 Why BYOK (Bring Your Own Key) is Critical

**Problem:** If you charge $29/month and provide API access, a single viral game could bankrupt you. If their patch notes go viral on Steam, and the tool regenerates banners 1,000 times, you are paying Google's API costs.

**Solution:**
- Developers sign up for Google AI Studio (free tier: 60 requests/minute).
- They paste their API key into the tool.
- You are selling the **orchestration logic**, not the API access.

**Precedent:** Tools like **Zapier** and **n8n** use this model successfully.

---

## 5. The Pre-Mortem: Why This Will Fail (And How to Avoid It)

### Failure Mode 1: The "Steam Ban" Fear

**Risk:** Developers fear that using an automation tool will get them banned from Steam for "spamming."

**Solution:**
- **Rate Limiting:** Hardcode a limit: maximum 1 announcement per week.
- **Human-in-the-Loop:** Never auto-publish. Always save as "Hidden" for manual review.
- **Legal Copy:** Add a disclaimer: "This tool drafts content. You are responsible for what you publish."

### Failure Mode 2: "I Don't Trust AI to Write for My Game"

**Risk:** Developers with strong creative visions do not want "generic AI slop" representing their game.

**Solution:**
- **Voice Training:** Use the 2M token context window to load their existing blog posts, Steam descriptions, and dev logs. The AI mimics their style.
- **Editable Drafts:** The tool outputs Markdown. They can edit before publishing.
- **Showcase Quality:** Post side-by-side comparisons: "Human-written patch note" vs. "WishlistOps draft." If the AI version is 80% as good and takes 5 minutes instead of 2 hours, they will use it.

### Failure Mode 3: "GitHub Actions is Too Technical"

**Risk:** Many indie devs do not use Git or are intimidated by YAML files.

**Solution:**
- **Phase 2 Product:** A simple desktop app (Electron) that wraps the same logic.
- They drag-and-drop their game folder, click "Generate Update," and it works.
- Charge $199 for the desktop version (targets non-technical devs).

---

## 6. Strategic Summary

### Target:
Solo developers and small studios (2-5 people) working on **PC games launching on Steam**. They have a marketing budget of $0-$5K and are drowning in operational tasks.

### Why Now:
- **Steam's Algorithm Changed (2024):** The "Popular Upcoming" list now prioritizes games with consistent update cadence. Developers who do not post regular news are punished.
- **AI Tooling Matured:** Gemini 2.5 Flash Image is the first model that can reliably generate text-heavy graphics (previous models failed at readable logos).
- **Economic Pressure:** The average indie game now takes 3+ years to develop. Developers cannot afford to "go dark" during production.

### The Pitch (30 Seconds):
"Your game deserves better marketing, but you do not have time. **WishlistOps** watches your Git commits and auto-generates Steam announcements and banners—so you stay visible without switching contexts. It is like CI/CD, but for marketing. One-time payment. Your API keys. Your control."

### The Moat:
- **Integration Depth:** Competitors (like Impress.games) focus on influencer outreach. You own the Steamworks automation layer.
- **Developer-First UX:** Built by devs, for devs. No marketing jargon. It is a tool, not a service.
- **BYOK Model:** You are not in the API reselling business. You are selling the orchestration logic, which is defensible through continuous iteration.

---

## Next Steps: Week 1 Checklist

- [ ] **Day 1:** Set up GitHub repo. Create basic Action template (text-only patch notes).
- [ ] **Day 2:** Ship to Reddit. Goal: 100 stars.
- [ ] **Day 3:** Integrate Gemini 2.5 Flash Image for banner generation.
- [ ] **Day 4:** Record demo video. Post to Twitter/X.
- [ ] **Day 5:** Add Steamworks API integration (Hidden Announcement upload).
- [ ] **Day 6:** Recruit 10 beta testers from Reddit comments.
- [ ] **Day 7:** Launch landing page. Offer $49 Early Bird license (first 50 customers).

---

**The Bottom Line:**

This is not a "build it and they will come" product. It is a "build it, show it working on real games, and let developers clone/fork/buy it" strategy. Your advantage is speed: you can ship the MVP in 7 days because you are leveraging GitHub Actions (no server costs) and Google AI Pro (no API bills during testing). The market is ready. The tools are ready. Execute.

---

*Document created: 2025*  
*Focus: Business blueprint and go-to-market strategy for WishlistOps*
