# WishlistOps Revised Architecture (Post-Critique)
## Practical Fixes for Real-World Adoption

---

## Executive Summary: What Changed and Why

Based on critical analysis of startup failure modes in dev-tool spaces, the original architecture had **4 fatal flaws**:

1. **Git-Wall** - Locked out non-programmers (artists, community managers)
2. **AI Slop Risk** - No quality gate before content reaches Steam
3. **BYOK Friction** - Complex API key setup killed onboarding
4. **Platform Brittleness** - Unofficial APIs = fragile system

**This document provides straightforward fixes that work.**

---

## Fix #1: Hybrid Interface (Solves Git-Wall)

### The Problem
Original: User must edit JSON files, understand Git, and push commits.
Reality: 90% of indie teams have non-programmers managing Steam.

### The Solution: Simple Web Dashboard

```
┌─────────────────────────────────────────────────────────────────┐
│           DUAL INTERFACE ARCHITECTURE                           │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  FOR PROGRAMMERS:              FOR NON-PROGRAMMERS:             │
│  ┌──────────────────┐          ┌──────────────────┐            │
│  │  Git Workflow    │          │  Web Dashboard   │            │
│  ├──────────────────┤          ├──────────────────┤            │
│  │ • Edit JSON      │          │ • Visual forms   │            │
│  │ • Git commit     │          │ • Drag & drop    │            │
│  │ • Push tags      │          │ • Click buttons  │            │
│  └──────────────────┘          └──────────────────┘            │
│          │                              │                       │
│          └──────────┬───────────────────┘                       │
│                     ↓                                           │
│          ┌─────────────────────┐                                │
│          │  GitHub Repository  │                                │
│          │  (Single Source of  │                                │
│          │   Truth - Git)      │                                │
│          └─────────────────────┘                                │
│                     │                                           │
│                     ↓                                           │
│          ┌─────────────────────┐                                │
│          │  GitHub Actions     │                                │
│          │  (Automation)       │                                │
│          └─────────────────────┘                                │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Implementation (Simple)

**Option A: GitHub Pages + Client-Side App (FREE)**
- Static HTML/JS app hosted on GitHub Pages
- Uses GitHub REST API to read/write files
- User authenticates with GitHub OAuth
- No backend needed - all client-side

**Option B: Minimal Cloudflare Worker (FREE tier)**
- Simple proxy for GitHub API calls
- Handles OAuth flow
- Free tier: 100k requests/day

**What Users See:**
```
┌────────────────────────────────────────────────────┐
│  WishlistOps Dashboard                             │
├────────────────────────────────────────────────────┤
│                                                    │
│  Game Settings                                     │
│  ┌────────────────────────────────────────────┐   │
│  │ Steam App ID:  [123456    ]                │   │
│  │ Game Name:     [My Game   ]                │   │
│  └────────────────────────────────────────────┘   │
│                                                    │
│  Branding                                          │
│  ┌────────────────────────────────────────────┐   │
│  │ Art Style:     [pixel art fantasy       ]  │   │
│  │ Logo Position: [⚫ Top-Right  ○ Center  ]  │   │
│  │ Upload Logo:   [Choose File...]            │   │
│  └────────────────────────────────────────────┘   │
│                                                    │
│  Writing Voice                                     │
│  ┌────────────────────────────────────────────┐   │
│  │ Tone: [casual and excited             v]   │   │
│  │ Avoid words: [monetization, grind]         │   │
│  └────────────────────────────────────────────┘   │
│                                                    │
│  [💾 Save Settings]                                │
│                                                    │
└────────────────────────────────────────────────────┘
```

**Behind the scenes:** Dashboard commits changes to `wishlistops/config.json` via GitHub API.

---

## Fix #2: Human-in-the-Loop Approval (Solves AI Slop)

### The Problem
Original: AI posts directly to Steam as "Hidden" - no intermediate check.
Risk: Hallucinated features, generic "ChatGPT" tone, reputation damage.

### The Solution: Discord/Slack Approval Flow

```
┌─────────────────────────────────────────────────────────────────┐
│              REVISED WORKFLOW WITH APPROVAL GATE                │
└─────────────────────────────────────────────────────────────────┘

Git Commit / Tag
        │
        v
GitHub Action Triggered
        │
        v
AI Generates Draft
        │
        v
┌───────────────────────────────────┐
│  NEW: APPROVAL GATE               │
├───────────────────────────────────┤
│                                   │
│  Send to Discord/Slack:           │
│  ┌─────────────────────────────┐  │
│  │ 🤖 WishlistOps Bot          │  │
│  │                             │  │
│  │ New draft ready:            │  │
│  │ "Combat Overhaul v1.2.0"    │  │
│  │                             │  │
│  │ [Preview Text]              │  │
│  │ [Preview Image]             │  │
│  │                             │  │
│  │ ✅ Approve  ❌ Reject        │  │
│  │ ✏️  Edit in Dashboard        │  │
│  └─────────────────────────────┘  │
│                                   │
└───────────────────────────────────┘
        │
        v (only if approved)
Post to Steam
```

### Implementation (Simple)

**Discord Webhook:**
```python
# In GitHub Action
import requests

def send_for_approval(draft_text, banner_url, webhook_url):
    payload = {
        "content": "🎮 New announcement ready for review!",
        "embeds": [{
            "title": draft_text["title"],
            "description": draft_text["body"][:500] + "...",
            "image": {"url": banner_url},
            "color": 5814783
        }],
        "components": [{
            "type": 1,
            "components": [
                {
                    "type": 2,
                    "style": 3,  # Green
                    "label": "✅ Approve & Post",
                    "custom_id": "approve_post"
                },
                {
                    "type": 2,
                    "style": 4,  # Red
                    "label": "❌ Reject",
                    "custom_id": "reject_post"
                }
            ]
        }]
    }
    requests.post(webhook_url, json=payload)
```

**Approval Handler:**
- When user clicks "Approve", Discord sends webhook to GitHub
- Triggers second GitHub Action: "Publish to Steam"
- Total delay: 30 seconds for team to review

**Benefit:** Team reviews in Discord (where they already are), not in Git/Steam.

---

## Fix #3: Simplified Onboarding (Solves BYOK Friction)

### The Problem
Original: User must setup Google Cloud billing, create project, enable APIs, generate keys.
Reality: 80% churn during this setup.

### The Solution: Three-Tier Model

```
┌─────────────────────────────────────────────────────────────────┐
│                    HYBRID AUTHENTICATION MODEL                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  TIER 1: FREE (Simplified BYOK)                                 │
│  ┌───────────────────────────────────────────────────────┐     │
│  │ Setup: 2 clicks                                        │     │
│  │ 1. Get Google AI Studio key (no billing required)     │     │
│  │    → ai.google.dev → Create API key → Copy            │     │
│  │ 2. Get Steam Publisher key (existing requirement)     │     │
│  │                                                        │     │
│  │ Limits: 60 requests/minute (free tier)                │     │
│  │ Cost to user: $0                                       │     │
│  │ Cost to you: $0                                        │     │
│  └───────────────────────────────────────────────────────┘     │
│                                                                 │
│  TIER 2: PRO ($99 lifetime)                                     │
│  ┌───────────────────────────────────────────────────────┐     │
│  │ Setup: GitHub OAuth (1 click)                          │     │
│  │                                                        │     │
│  │ How it works:                                          │     │
│  │ • You maintain a shared API key pool                   │     │
│  │ • User's requests proxied through your Cloudflare     │     │
│  │   Worker (adds their user ID to metadata)             │     │
│  │ • You pay Google per-use, charge upfront lifetime     │     │
│  │                                                        │     │
│  │ Benefits:                                              │     │
│  │ • No API key setup                                     │     │
│  │ • Higher rate limits                                   │     │
│  │ • Priority support                                     │     │
│  │                                                        │     │
│  │ Economics:                                             │     │
│  │ • $99 upfront = 2,538 image generations               │     │
│  │   ($0.039/image)                                       │     │
│  │ • Average user: ~50 images/year = 50 years covered    │     │
│  │ • Profit: ~$97/user                                    │     │
│  └───────────────────────────────────────────────────────┘     │
│                                                                 │
│  TIER 3: STUDIO ($299 lifetime)                                 │
│  ┌───────────────────────────────────────────────────────┐     │
│  │ • Managed keys for 10+ games                           │     │
│  │ • Team collaboration features                          │     │
│  │ • Dedicated support channel                            │     │
│  │ • Custom integrations                                  │     │
│  └───────────────────────────────────────────────────────┘     │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Implementation (Simple)

**For Free Tier:**
- Update docs to use Google AI Studio instead of Google Cloud
- AI Studio gives instant API keys (no billing setup)
- Same API, simpler UI

**For Pro Tier:**
- Cloudflare Worker proxies requests
- Store user API keys in Cloudflare KV (encrypted)
- 100k free requests/day on Cloudflare = plenty of headroom

**Cost Analysis:**
```
Revenue per Pro user: $99
Cost per Pro user (lifetime):
  - 50 images/year × 5 years = 250 images
  - 250 × $0.039 = $9.75 in API costs
  - Cloudflare: $0 (free tier)
Net profit: $89.25 per user
```

---

## Fix #4: Platform Resilience (Solves Brittleness)

### The Problem
Original: Relies on SteamSpy for wishlist stats (unofficial, fragile).
Risk: Data source breaks, monitoring fails, users lose trust.

### The Solution: Graceful Degradation

```
┌─────────────────────────────────────────────────────────────────┐
│              RESILIENT DATA FETCHING STRATEGY                   │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Wishlist Monitoring (Fallback Cascade):                       │
│                                                                 │
│  1. Primary: SteamSpy API                                       │
│     └─ If fails → Try #2                                        │
│                                                                 │
│  2. Secondary: Steam Store Page Scraping                        │
│     └─ If fails → Try #3                                        │
│                                                                 │
│  3. Tertiary: Manual User Input                                 │
│     └─ Prompt: "Enter current wishlist count: [____]"          │
│                                                                 │
│  4. Final: Disable Wishlist Triggering                          │
│     └─ Fall back to tag-based and schedule-based only          │
│                                                                 │
│  Decision Logic:                                                │
│  • If wishlist data unavailable for >7 days:                    │
│    - Email user: "Wishlist monitoring paused"                   │
│    - Continue other triggers (tags, schedule)                   │
│  • Tool remains 90% functional even if Steam data fails         │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Implementation (Simple)

**Remove Hard Dependencies:**
```python
def get_wishlist_count(app_id):
    """Try multiple sources, fail gracefully"""
    
    # Try SteamSpy
    try:
        return steamspy_api.get_wishlists(app_id)
    except:
        pass
    
    # Try scraping
    try:
        return scrape_steam_page(app_id)
    except:
        pass
    
    # Ask user (via dashboard)
    return get_manual_input(app_id)
    
# In workflow: Don't fail if None, just skip wishlist-based triggers
if wishlist_count is not None:
    check_if_threshold_reached()
```

**Benefit:** System keeps working even when Steam changes things.

---

## Fix #5: Anti-Slop Quality Filter (Bonus)

### The Problem
AI-generated content can sound generic and corporate.

### The Solution: Pre-Post Analysis

```
┌─────────────────────────────────────────────────────────────────┐
│                   ANTI-SLOP FILTER STAGE                        │
└─────────────────────────────────────────────────────────────────┘

AI Generates Draft
        │
        v
┌───────────────────────────────┐
│  Run "Slop Detector"          │
├───────────────────────────────┤
│  Check for:                   │
│  ✗ "Delve"                    │
│  ✗ "Tapestry"                 │
│  ✗ "Immersive experience"     │
│  ✗ "Elevate"                  │
│  ✗ "Seamless"                 │
│  ✗ Marketing buzzwords        │
│                               │
│  If detected → Regenerate     │
│  with: "Remove corporate      │
│  language. Write like a       │
│  tired indie dev."            │
└───────────────────────────────┘
        │
        v
Send to Discord for approval
```

### Implementation (Simple)

```python
SLOP_WORDS = [
    "delve", "tapestry", "immersive", "elevate", "seamless",
    "revolutionary", "game-changing", "cutting-edge", 
    "leverage", "synergy", "robust", "holistic"
]

def check_quality(text):
    text_lower = text.lower()
    found_slop = [word for word in SLOP_WORDS if word in text_lower]
    
    if found_slop:
        # Regenerate with stronger prompt
        return regenerate_with_prompt(
            original_text=text,
            instruction=f"Rewrite without these words: {found_slop}. "
                       "Sound like a developer, not a marketer."
        )
    return text
```

---

## Revised Complete Workflow

```
┌─────────────────────────────────────────────────────────────────┐
│            END-TO-END WORKFLOW (REVISED - 90 SECONDS)           │
└─────────────────────────────────────────────────────────────────┘

Developer pushes v1.2.0 tag
        │
        v
GitHub Action triggered
        │
        v
Parse commits (10s)
        │
        v
AI generates draft (12s)
        │
        v
Run Anti-Slop filter (3s)
├─ If slop detected → Regenerate (10s)
└─ If clean → Continue
        │
        v
Generate banner image (8s)
        │
        v
Composite logo (2s)
        │
        v
Upload to temporary storage (3s)
        │
        v
Send to Discord with preview (2s)
┌─────────────────────────────────┐
│  HUMAN REVIEWS IN DISCORD       │
│  (User takes 30-120 seconds)    │
│                                 │
│  ✅ Approve → Continue           │
│  ❌ Reject → Stop                │
│  ✏️  Edit → Open dashboard       │
└─────────────────────────────────┘
        │ (if approved)
        v
Upload to Steam CDN (5s)
        │
        v
Post announcement as Hidden (3s)
        │
        v
Notify team in Discord (1s)
        │
        v
DONE - Ready for manual publish

TOTAL: ~90 seconds + human review time
IMPROVEMENT: Added safety without losing speed
```

---

## Summary of Changes

| Issue | Old Approach | New Approach | Result |
|-------|-------------|--------------|--------|
| **Git-Wall** | JSON files only | Web dashboard + Git | Non-programmers can use it |
| **AI Slop** | Direct to Steam | Discord approval + filter | Quality control |
| **BYOK Setup** | Google Cloud Console | AI Studio (2 clicks) | 80% less friction |
| **Pro Tier** | N/A | Managed proxy keys | Revenue without sacrificing mission |
| **Platform Risk** | Hard dependency on SteamSpy | Graceful fallbacks | 90% uptime even if APIs break |

---

## Implementation Priority

### Week 1: Critical Fixes
1. ✅ Add Discord approval flow (1 day)
2. ✅ Build simple web dashboard (2 days)
3. ✅ Switch docs to AI Studio keys (1 hour)
4. ✅ Add anti-slop filter (2 hours)

### Week 2: Revenue Features
1. Set up Cloudflare Worker proxy (1 day)
2. Implement Pro tier billing (1 day)
3. Build user dashboard for Pro tier (2 days)

### Week 3: Polish
1. Add fallback logic for Steam data (1 day)
2. Improve dashboard UI (2 days)
3. Write new onboarding docs (1 day)

---

## Cost Analysis (Revised)

### Infrastructure Costs (Per Month)
- GitHub Actions: $0 (within free tier)
- Cloudflare Worker: $0 (within free tier)
- GitHub Pages: $0 (included)
- **Total: $0**

### Per-User API Costs (Pro Tier)
- Lifetime revenue: $99
- Expected lifetime usage: 250 images
- Cost: $9.75
- **Profit margin: 90%**

### Scaling
- 100 Pro users = $9,900 revenue - $975 costs = **$8,925 profit**
- 1,000 Pro users = $99,000 revenue - $9,750 costs = **$89,250 profit**

---

## Conclusion

These fixes address the four fatal flaws without abandoning the core vision:

✅ **Git remains the source of truth** (for version control)  
✅ **Non-programmers can use it** (via dashboard)  
✅ **Human approval prevents AI slop** (Discord gate)  
✅ **Easy onboarding** (AI Studio, not Cloud Console)  
✅ **Revenue model works** (Pro tier with 90% margins)  
✅ **Platform resilience** (graceful degradation)

**The mission stays the same: Automate marketing so indie devs can focus on coding.**  
**The execution is now practical and adoption-ready.**

---

*Document Version: 2.0*  
*Status: Post-Critique Revision*  
*Focus: Real-world fixes for startup success*
