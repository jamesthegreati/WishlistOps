﻿# WishlistOps System Architecture & Visual Diagrams

This document provides comprehensive visual representations of the WishlistOps system architecture.

## 1. High-Level System Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          WISHLISTOPS ECOSYSTEM                               │
└─────────────────────────────────────────────────────────────────────────────┘

     ┌──────────────┐          ┌──────────────┐          ┌──────────────┐
     │  DEVELOPER   │          │  WISHLISTOPS │          │    STEAM     │
     │  WORKSPACE   │ ────────>│   PLATFORM   │ ────────>│  STOREFRONT  │
     └──────────────┘          └──────────────┘          └──────────────┘
           │                          │                          │
           │                          │                          │
     [Git Commits]            [Automation Engine]         [Marketing Assets]
     [Game Assets]            [AI Generation]             [Announcements]
     [Lore Docs]              [Orchestration]             [Wishlist Data]
```

## 2. Detailed Component Architecture

```
┌───────────────────────────────────────────────────────────────────────────────┐
│                        WISHLISTOPS SYSTEM COMPONENTS                          │
├───────────────────────────────────────────────────────────────────────────────┤
│                                                                               │
│  ┌─────────────────────┐         ┌──────────────────────┐                   │
│  │   INPUT LAYER       │         │  PROCESSING LAYER    │                   │
│  ├─────────────────────┤         ├──────────────────────┤                   │
│  │                     │         │                      │                   │
│  │  • Git Repository   │────────>│  • GitHub Actions    │                   │
│  │  • Commit Logs      │         │  • Python Scripts    │                   │
│  │  • Game Assets      │         │  • NLP Analysis      │                   │
│  │  • Lore Documents   │         │  • Context Parsing   │                   │
│  │  • Config Files     │         │                      │                   │
│  └─────────────────────┘         └──────────────────────┘                   │
│           │                                │                                 │
│           │                                │                                 │
│           v                                v                                 │
│  ┌─────────────────────┐         ┌──────────────────────┐                   │
│  │  TRIGGER EVENTS     │         │   AI GENERATION      │                   │
│  ├─────────────────────┤         ├──────────────────────┤                   │
│  │                     │         │                      │                   │
│  │  • Git Tag Push     │────────>│  • Gemini 1.5 Pro    │                   │
│  │  • Schedule (Cron)  │         │    (Text/Analysis)   │                   │
│  │  • Manual Trigger   │         │                      │                   │
│  │  • Webhook Call     │         │  • Gemini 2.5 Flash  │                   │
│  └─────────────────────┘         │    (Image Gen)       │                   │
│                                   │                      │                   │
│                                   │  • Context Window    │                   │
│                                   │    (2M tokens)       │                   │
│                                   └──────────────────────┘                   │
│                                            │                                 │
│                                            │                                 │
│                                            v                                 │
│                                   ┌──────────────────────┐                   │
│                                   │  OUTPUT PROCESSING   │                   │
│                                   ├──────────────────────┤                   │
│                                   │                      │                   │
│                                   │  • Image Compositing │                   │
│                                   │    (Pillow/PIL)      │                   │
│                                   │                      │                   │
│                                   │  • BBCode Formatting │                   │
│                                   │                      │                   │
│                                   │  • Asset Validation  │                   │
│                                   └──────────────────────┘                   │
│                                            │                                 │
│                                            │                                 │
│                                            v                                 │
│                                   ┌──────────────────────┐                   │
│                                   │   OUTPUT LAYER       │                   │
│                                   ├──────────────────────┤                   │
│                                   │                      │                   │
│                                   │  • Steam API Client  │                   │
│                                   │  • Announcement Post │                   │
│                                   │  • Image Upload      │                   │
│                                   │  • Analytics Log     │                   │
│                                   └──────────────────────┘                   │
│                                            │                                 │
│                                            v                                 │
│                                   ┌──────────────────────┐                   │
│                                   │    STEAMWORKS        │                   │
│                                   └──────────────────────┘                   │
└───────────────────────────────────────────────────────────────────────────────┘
```


## 3. Data Flow Diagram

```
Developer Pushes Code
        │
        v
┌───────────────────┐
│  Git Tag Trigger  │
│   (e.g., v1.2.0)  │
└───────────────────┘
        │
        v
┌───────────────────────────────────────────────────────────────┐
│              GITHUB ACTIONS WORKFLOW                          │
├───────────────────────────────────────────────────────────────┤
│                                                               │
│  Step 1: Parse Git Log                                       │
│  ┌─────────────────────────────────────────┐                │
│  │  • Extract commits since last tag       │                │
│  │  • Filter merge commits                 │                │
│  │  • Identify file changes                │                │
│  └─────────────────────────────────────────┘                │
│                    │                                          │
│                    v                                          │
│  Step 2: AI Analysis (Gemini 1.5 Pro)                       │
│  ┌─────────────────────────────────────────┐                │
│  │  INPUT: Commit messages + context       │                │
│  │  ├─ Load game lore documents            │                │
│  │  ├─ Load previous announcements         │                │
│  │  └─ Load writing style guide            │                │
│  │                                          │                │
│  │  PROCESSING:                             │                │
│  │  ├─ Classify commits (player-facing?)   │                │
│  │  ├─ Extract key features                │                │
│  │  └─ Generate announcement draft         │                │
│  │                                          │                │
│  │  OUTPUT: BBCode formatted text          │                │
│  └─────────────────────────────────────────┘                │
│                    │                                          │
│                    v                                          │
│  Step 3: Visual Generation (Gemini 2.5 Flash)               │
│  ┌─────────────────────────────────────────┐                │
│  │  INPUT: Announcement text + game style  │                │
│  │  ├─ Reference screenshot                │                │
│  │  ├─ Art style keywords                  │                │
│  │  └─ Branding guidelines                 │                │
│  │                                          │                │
│  │  PROCESSING:                             │                │
│  │  ├─ Generate 1024x576 banner            │                │
│  │  ├─ Text-aware composition              │                │
│  │  └─ Style consistency check             │                │
│  │                                          │                │
│  │  OUTPUT: PNG image (base banner)        │                │
│  └─────────────────────────────────────────┘                │
│                    │                                          │
│                    v                                          │
│  Step 4: Logo Compositing (Python/Pillow)                   │
│  ┌─────────────────────────────────────────┐                │
│  │  • Load game logo (transparent PNG)     │                │
│  │  • Position logo at safe zone           │                │
│  │  • Apply drop shadow/effects            │                │
│  │  • Resize to Steam specs (800x450)     │                │
│  │  • Optimize file size                   │                │
│  └─────────────────────────────────────────┘                │
│                    │                                          │
│                    v                                          │
│  Step 5: Steam Upload (Steamworks API)                      │
│  ┌─────────────────────────────────────────┐                │
│  │  • Authenticate with API key            │                │
│  │  • Upload image to ISteamRemoteStorage  │                │
│  │  • Post announcement (Hidden status)    │                │
│  │  • Log metadata to analytics            │                │
│  └─────────────────────────────────────────┘                │
│                                                               │
└───────────────────────────────────────────────────────────────┘
        │
        v
┌───────────────────┐
│  Developer Gets   │
│  Email/Slack      │
│  Notification     │
└───────────────────┘
        │
        v
┌───────────────────┐
│  Developer        │
│  Reviews & Edits  │
│  in Steam         │
│  Dashboard        │
└───────────────────┘
        │
        v
┌───────────────────┐
│  Manual Publish   │
│  to Live Store    │
└───────────────────┘
```


## 4. Infrastructure & Technology Stack

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    TECHNOLOGY STACK LAYERS                              │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐  │
│  │  DEVELOPER INTERFACE LAYER                                      │  │
│  ├─────────────────────────────────────────────────────────────────┤  │
│  │                                                                  │  │
│  │  • Git Client (GitHub Desktop, CLI, IDE integration)            │  │
│  │  • GitHub Web UI (for manual triggers)                          │  │
│  │  • VS Code / GitHub Codespaces (demo environment)               │  │
│  │  • Configuration Files (.yml, .json)                            │  │
│  │                                                                  │  │
│  └─────────────────────────────────────────────────────────────────┘  │
│                                │                                        │
│                                v                                        │
│  ┌─────────────────────────────────────────────────────────────────┐  │
│  │  ORCHESTRATION LAYER (GitHub Pro)                               │  │
│  ├─────────────────────────────────────────────────────────────────┤  │
│  │                                                                  │  │
│  │  GitHub Actions (3,000 min/month)                               │  │
│  │  ├─ Ubuntu Runners (default)                                    │  │
│  │  ├─ Workflow YAML definitions                                   │  │
│  │  ├─ Secret management (API keys)                                │  │
│  │  └─ Artifact storage (logs, images)                             │  │
│  │                                                                  │  │
│  │  GitHub Codespaces (180 hrs/month)                              │  │
│  │  ├─ 2-core / 4GB RAM instances                                  │  │
│  │  ├─ Pre-configured dev containers                               │  │
│  │  └─ Browser-based IDE access                                    │  │
│  │                                                                  │  │
│  │  GitHub Pages (Private Repos)                                   │  │
│  │  └─ Dashboard hosting for analytics                             │  │
│  │                                                                  │  │
│  └─────────────────────────────────────────────────────────────────┘  │
│                                │                                        │
│                                v                                        │
│  ┌─────────────────────────────────────────────────────────────────┐  │
│  │  AI/ML LAYER (Google AI Pro)                                    │  │
│  ├─────────────────────────────────────────────────────────────────┤  │
│  │                                                                  │  │
│  │  Gemini 1.5 Pro (Text/Analysis)                                 │  │
│  │  ├─ 2M token context window                                     │  │
│  │  ├─ Multi-turn conversations                                    │  │
│  │  ├─ Function calling                                            │  │
│  │  └─ System instructions                                         │  │
│  │                                                                  │  │
│  │  Gemini 2.5 Flash Image ("Nano Banana")                         │  │
│  │  ├─ Text-aware image generation                                 │  │
│  │  ├─ 1024x1024 native resolution                                 │  │
│  │  ├─ 3-8 second generation time                                  │  │
│  │  ├─ SynthID watermarking                                        │  │
│  │  └─ Style consistency features                                  │  │
│  │                                                                  │  │
│  │  API Infrastructure                                             │  │
│  │  ├─ REST API endpoints                                          │  │
│  │  ├─ Rate limiting (100 img/day free)                            │  │
│  │  └─ BYOK support (user API keys)                                │  │
│  │                                                                  │  │
│  └─────────────────────────────────────────────────────────────────┘  │
│                                │                                        │
│                                v                                        │
│  ┌─────────────────────────────────────────────────────────────────┐  │
│  │  PROCESSING LAYER (Python 3.11+)                                │  │
│  ├─────────────────────────────────────────────────────────────────┤  │
│  │                                                                  │  │
│  │  Core Libraries                                                  │  │
│  │  ├─ Pillow (PIL) - Image manipulation                           │  │
│  │  ├─ Requests - HTTP client                                      │  │
│  │  ├─ PyYAML - Config parsing                                     │  │
│  │  ├─ GitPython - Git operations                                  │  │
│  │  └─ python-dotenv - Environment management                      │  │
│  │                                                                  │  │
│  │  Custom Modules                                                  │  │
│  │  ├─ commit_analyzer.py - NLP classification                     │  │
│  │  ├─ image_compositor.py - Logo overlay                          │  │
│  │  ├─ steam_client.py - API wrapper                               │  │
│  │  ├─ prompt_builder.py - Context assembly                        │  │
│  │  └─ config_manager.py - Settings handler                        │  │
│  │                                                                  │  │
│  └─────────────────────────────────────────────────────────────────┘  │
│                                │                                        │
│                                v                                        │
│  ┌─────────────────────────────────────────────────────────────────┐  │
│  │  INTEGRATION LAYER (External APIs)                              │  │
│  ├─────────────────────────────────────────────────────────────────┤  │
│  │                                                                  │  │
│  │  Steamworks Web API                                             │  │
│  │  ├─ ISteamNews - Post announcements                             │  │
│  │  ├─ ISteamApps - App data retrieval                             │  │
│  │  ├─ ISteamRemoteStorage - File uploads                          │  │
│  │  ├─ ISteamUserStats - Analytics data                            │  │
│  │  └─ Partner API - Admin operations                              │  │
│  │                                                                  │  │
│  │  Authentication                                                  │  │
│  │  ├─ Publisher Web API Key                                       │  │
│  │  ├─ OAuth 2.0 (future)                                          │  │
│  │  └─ Rate limit handling                                         │  │
│  │                                                                  │  │
│  └─────────────────────────────────────────────────────────────────┘  │
│                                │                                        │
│                                v                                        │
│  ┌─────────────────────────────────────────────────────────────────┐  │
│  │  DATA LAYER                                                      │  │
│  ├─────────────────────────────────────────────────────────────────┤  │
│  │                                                                  │  │
│  │  Git Repository                                                  │  │
│  │  ├─ Source code                                                  │  │
│  │  ├─ Commit history                                               │  │
│  │  ├─ Game assets (logos, screenshots)                            │  │
│  │  ├─ Configuration files                                          │  │
│  │  └─ Generated artifacts (cache)                                  │  │
│  │                                                                  │  │
│  │  GitHub Secrets                                                  │  │
│  │  ├─ Steam API keys (encrypted)                                  │  │
│  │  ├─ Google AI API keys (encrypted)                              │  │
│  │  └─ Webhook tokens                                               │  │
│  │                                                                  │  │
│  │  Artifacts & Logs                                                │  │
│  │  ├─ Generated images (temporary)                                │  │
│  │  ├─ Announcement drafts                                          │  │
│  │  ├─ Action logs                                                  │  │
│  │  └─ Analytics JSON                                               │  │
│  │                                                                  │  │
│  └─────────────────────────────────────────────────────────────────┘  │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

## 5. Security Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                      SECURITY LAYERS                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Layer 1: API Key Management                                   │
│  ┌────────────────────────────────────────────────────────┐   │
│  │  • GitHub Secrets (AES-256 encrypted at rest)          │   │
│  │  • No keys in code or logs                             │   │
│  │  • Rotation reminders (90-day cycle)                   │   │
│  │  • Scope-limited permissions                           │   │
│  └────────────────────────────────────────────────────────┘   │
│                                                                 │
│  Layer 2: Authentication & Authorization                       │
│  ┌────────────────────────────────────────────────────────┐   │
│  │  • Publisher Web API Key (Steam)                       │   │
│  │  • OAuth 2.0 for Google AI (BYOK)                      │   │
│  │  • GitHub Personal Access Tokens (fine-grained)        │   │
│  │  • IP whitelisting (optional)                          │   │
│  └────────────────────────────────────────────────────────┘   │
│                                                                 │
│  Layer 3: Rate Limiting & Abuse Prevention                     │
│  ┌────────────────────────────────────────────────────────┐   │
│  │  • Max 1 announcement per week                         │   │
│  │  • GitHub Actions concurrency limits                   │   │
│  │  • API quota monitoring                                │   │
│  │  • Suspicious activity detection                       │   │
│  └────────────────────────────────────────────────────────┘   │
│                                                                 │
│  Layer 4: Data Privacy                                         │
│  ┌────────────────────────────────────────────────────────┐   │
│  │  • No persistent storage of game content               │   │
│  │  • Temporary artifacts auto-deleted                    │   │
│  │  • Logs sanitized (no sensitive data)                  │   │
│  │  • SynthID watermarking for provenance                 │   │
│  └────────────────────────────────────────────────────────┘   │
│                                                                 │
│  Layer 5: Compliance & Auditing                                │
│  ┌────────────────────────────────────────────────────────┐   │
│  │  • GDPR-compliant (EU users)                           │   │
│  │  • Steam ToS compliance checks                         │   │
│  │  • Audit logs for all API calls                        │   │
│  │  • User consent management                             │   │
│  └────────────────────────────────────────────────────────┘   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```


## 6. Deployment Architecture

```
┌───────────────────────────────────────────────────────────────────────────┐
│                      DEPLOYMENT MODELS                                    │
├───────────────────────────────────────────────────────────────────────────┤
│                                                                           │
│  MODEL 1: GitHub Actions (Serverless) - FREE TIER                        │
│  ┌─────────────────────────────────────────────────────────────────┐    │
│  │                                                                  │    │
│  │   Developer's GitHub Repo                                       │    │
│  │   ├─ .github/workflows/wishlistops.yml                          │    │
│  │   ├─ wishlistops/                                               │    │
│  │   │   ├─ config.json                                            │    │
│  │   │   ├─ logo.png                                               │    │
│  │   │   └─ style_guide.md                                         │    │
│  │   └─ secrets (GitHub UI)                                        │    │
│  │       ├─ STEAM_API_KEY                                          │    │
│  │       └─ GOOGLE_AI_KEY                                          │    │
│  │                                                                  │    │
│  │   Triggers:                                                     │    │
│  │   • on: push (tags: 'v*.*.*')                                   │    │
│  │   • schedule: cron('0 12 * * 1')  # Weekly Monday noon         │    │
│  │   • workflow_dispatch (manual)                                  │    │
│  │                                                                  │    │
│  │   Execution:                                                    │    │
│  │   • GitHub-hosted runner (Ubuntu 22.04)                         │    │
│  │   • 2 cores, 7GB RAM, 14GB SSD                                  │    │
│  │   • ~60-90 seconds per run                                      │    │
│  │   • Cost:  (within free tier)                                 │    │
│  │                                                                  │    │
│  └─────────────────────────────────────────────────────────────────┘    │
│                                                                           │
│  MODEL 2: Self-Hosted Runner - POWER USERS                               │
│  ┌─────────────────────────────────────────────────────────────────┐    │
│  │                                                                  │    │
│  │   Developer's Local Machine / VPS                               │    │
│  │   ├─ Docker Container                                           │    │
│  │   │   ├─ Base: python:3.11-slim                                 │    │
│  │   │   ├─ Dependencies: pillow, requests, etc.                   │    │
│  │   │   └─ GitHub Actions runner agent                            │    │
│  │   │                                                              │    │
│  │   ├─ Persistent Storage                                         │    │
│  │   │   ├─ Asset cache (generated images)                         │    │
│  │   │   └─ Logs                                                   │    │
│  │   │                                                              │    │
│  │   └─ Network                                                    │    │
│  │       ├─ Outbound: API calls to Google/Steam                    │    │
│  │       └─ Inbound: GitHub webhooks (optional)                    │    │
│  │                                                                  │    │
│  │   Benefits:                                                     │    │
│  │   • No GitHub Actions minute limits                             │    │
│  │   • Faster execution (local cache)                              │    │
│  │   • Custom GPU support (future: local LLMs)                     │    │
│  │   • Cost: -10/month (DigitalOcean Droplet)                    │    │
│  │                                                                  │    │
│  └─────────────────────────────────────────────────────────────────┘    │
│                                                                           │
│  MODEL 3: Desktop App (Electron) - FUTURE                                │
│  ┌─────────────────────────────────────────────────────────────────┐    │
│  │                                                                  │    │
│  │   Cross-Platform Desktop Application                            │    │
│  │   ├─ Frontend: Electron + React                                 │    │
│  │   ├─ Backend: Node.js + Python bridge                           │    │
│  │   └─ Distribution: Auto-updater                                 │    │
│  │                                                                  │    │
│  │   Features:                                                     │    │
│  │   • Drag-and-drop game folder                                   │    │
│  │   • Visual config builder (no YAML)                             │    │
│  │   • Built-in image editor                                       │    │
│  │   • One-click Steam publish                                     │    │
│  │                                                                  │    │
│  │   Target Users:                                                 │    │
│  │   • Non-technical indie devs                                    │    │
│  │   • Artists/designers (not programmers)                         │    │
│  │   • Price:  lifetime license                                │    │
│  │                                                                  │    │
│  └─────────────────────────────────────────────────────────────────┘    │
│                                                                           │
└───────────────────────────────────────────────────────────────────────────┘
```

## 7. User Journey Flow

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          USER ONBOARDING FLOW                               │
└─────────────────────────────────────────────────────────────────────────────┘

STEP 1: DISCOVERY
┌──────────────────┐
│  Developer finds │
│  WishlistOps via │
│  • Reddit post   │
│  • Twitter/X     │
│  • Friend rec    │
└──────────────────┘
        │
        v
STEP 2: INSTANT DEMO (GitHub Codespaces)
┌──────────────────────────────────────────┐
│  Click "Open in Codespaces"              │
│  ├─ Browser-based VS Code opens          │
│  ├─ Pre-configured demo project          │
│  ├─ Sample game data included            │
│  └─ Run: python test_generation.py       │
│                                           │
│  Result: See banner + announcement       │
│  Time: 2 minutes from click to output    │
└──────────────────────────────────────────┘
        │
        v
STEP 3: DECISION POINT
┌──────────────────────────────────────────┐
│  Is the developer convinced?             │
│  ├─ YES: Proceed to setup                │
│  └─ NO: Exit (lost lead)                 │
└──────────────────────────────────────────┘
        │
        v
STEP 4: REPOSITORY SETUP
┌──────────────────────────────────────────┐
│  Fork template repo OR                   │
│  Copy workflow file to existing repo     │
│                                           │
│  .github/workflows/wishlistops.yml       │
│  wishlistops/config.json                 │
└──────────────────────────────────────────┘
        │
        v
STEP 5: CONFIGURATION
┌──────────────────────────────────────────┐
│  Edit config.json:                       │
│  {                                        │
│    "steam_app_id": "123456",             │
│    "game_name": "My Awesome Game",       │
│    "art_style": "pixel art fantasy",     │
│    "voice_tone": "casual and excited"    │
│  }                                        │
└──────────────────────────────────────────┘
        │
        v
STEP 6: API KEY SETUP
┌──────────────────────────────────────────┐
│  Add GitHub Secrets:                     │
│  1. Go to repo Settings > Secrets        │
│  2. Add STEAM_API_KEY                    │
│     ├─ Get from Steamworks partner page  │
│     └─ Publisher Web API Key             │
│  3. Add GOOGLE_AI_KEY                    │
│     ├─ Get from ai.google.dev            │
│     └─ Free tier: 100 img/day            │
└──────────────────────────────────────────┘
        │
        v
STEP 7: ASSET UPLOAD
┌──────────────────────────────────────────┐
│  Upload to repo:                         │
│  wishlistops/                            │
│  ├─ logo.png (transparent, 512x512)      │
│  ├─ screenshot.png (reference style)     │
│  └─ lore.md (game world description)     │
└──────────────────────────────────────────┘
        │
        v
STEP 8: FIRST TEST RUN
┌──────────────────────────────────────────┐
│  Trigger manually:                       │
│  • Go to Actions tab                     │
│  • Select "WishlistOps" workflow         │
│  • Click "Run workflow"                  │
│  • Watch logs in real-time               │
│                                           │
│  Expected time: 60-90 seconds            │
└──────────────────────────────────────────┘
        │
        v
STEP 9: REVIEW OUTPUT
┌──────────────────────────────────────────┐
│  Check Artifacts:                        │
│  • announcement_draft.md                 │
│  • banner_final.png                      │
│                                           │
│  Check Steam Dashboard:                  │
│  • Log into Steamworks                   │
│  • Go to Community > Events              │
│  • See "Hidden" announcement             │
└──────────────────────────────────────────┘
        │
        v
STEP 10: ITERATE & REFINE
┌──────────────────────────────────────────┐
│  Adjust config if needed:                │
│  • Tweak art style keywords              │
│  • Modify voice tone                     │
│  • Update logo positioning               │
│                                           │
│  Re-run until satisfied                  │
└──────────────────────────────────────────┘
        │
        v
STEP 11: AUTOMATION SETUP
┌──────────────────────────────────────────┐
│  Enable auto-triggers:                   │
│  • Tag-based: Push v*.*.* tags           │
│  • Schedule: Weekly updates              │
│  • Let it run autonomously               │
└──────────────────────────────────────────┘
        │
        v
STEP 12: MONETIZATION (Optional)
┌──────────────────────────────────────────┐
│  Upgrade to Pro:                         │
│  • Pay  lifetime license              │
│  • Get priority support                  │
│  • Access beta features                  │
│  • Join Discord community                │
└──────────────────────────────────────────┘

Total Onboarding Time: 30-45 minutes
Friction Points: API key setup (unavoidable)
Success Metric: First successful generation
```


## 8. Error Handling & Failure Recovery

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      ERROR HANDLING ARCHITECTURE                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  Level 1: Input Validation                                                 │
│  ┌───────────────────────────────────────────────────────────────────┐    │
│  │                                                                    │    │
│  │  Git Log Parsing                                                  │    │
│  │  ├─ Empty commit log → Skip run (exit gracefully)                │    │
│  │  ├─ Invalid tag format → Log warning, continue                   │    │
│  │  └─ No player-facing changes → Generate "minor update" post      │    │
│  │                                                                    │    │
│  │  Config Validation                                                │    │
│  │  ├─ Missing config.json → Use defaults                           │    │
│  │  ├─ Invalid Steam App ID → Fail with helpful error               │    │
│  │  └─ Missing logo.png → Use text-only banner                      │    │
│  │                                                                    │    │
│  └───────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  Level 2: API Failure Handling                                             │
│  ┌───────────────────────────────────────────────────────────────────┐    │
│  │                                                                    │    │
│  │  Google AI API                                                    │    │
│  │  ├─ Rate limit (429) → Exponential backoff (wait & retry)        │    │
│  │  ├─ Timeout (504) → Retry up to 3 times                          │    │
│  │  ├─ Content policy violation → Use fallback prompt               │    │
│  │  └─ Quota exceeded → Email user, save draft locally              │    │
│  │                                                                    │    │
│  │  Steam API                                                        │    │
│  │  ├─ Authentication failure → Verify API key, halt with error     │    │
│  │  ├─ Upload failure → Retry with smaller image                    │    │
│  │  ├─ Duplicate post detection → Skip (already posted)             │    │
│  │  └─ Network timeout → Retry after 30 seconds                     │    │
│  │                                                                    │    │
│  └───────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  Level 3: Generation Quality Checks                                        │
│  ┌───────────────────────────────────────────────────────────────────┐    │
│  │                                                                    │    │
│  │  Text Quality                                                     │    │
│  │  ├─ Too short (<50 words) → Request regeneration                 │    │
│  │  ├─ Contains placeholder text → Flag for manual review           │    │
│  │  ├─ Off-brand tone → Re-prompt with stronger instructions        │    │
│  │  └─ Grammar/spelling check → Basic linting                       │    │
│  │                                                                    │    │
│  │  Image Quality                                                    │    │
│  │  ├─ Resolution check → Must be ≥800x450px                        │    │
│  │  ├─ File size check → Must be <2MB                               │    │
│  │  ├─ Aspect ratio validation → Crop/pad if needed                 │    │
│  │  └─ Logo visibility check → Ensure proper contrast               │    │
│  │                                                                    │    │
│  └───────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  Level 4: Fallback Mechanisms                                              │
│  ┌───────────────────────────────────────────────────────────────────┐    │
│  │                                                                    │    │
│  │  Cascade Strategy                                                 │    │
│  │  1. Primary: Gemini 2.5 Flash Image                              │    │
│  │  2. Fallback 1: Gemini 2.0 Flash (if 2.5 unavailable)            │    │
│  │  3. Fallback 2: Text-only announcement (skip image)              │    │
│  │  4. Fallback 3: Save locally, notify user                        │    │
│  │                                                                    │    │
│  │  Degraded Mode                                                    │    │
│  │  • If AI unavailable: Use template-based generation              │    │
│  │  • Pre-written announcements with variables                      │    │
│  │  • Example: "Version {version} is now live!"                     │    │
│  │                                                                    │    │
│  └───────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  Level 5: Monitoring & Alerts                                              │
│  ┌───────────────────────────────────────────────────────────────────┐    │
│  │                                                                    │    │
│  │  Success Metrics                                                  │    │
│  │  ├─ Log all runs to JSON file                                    │    │
│  │  ├─ Track: duration, API calls, errors                           │    │
│  │  └─ Generate weekly report                                       │    │
│  │                                                                    │    │
│  │  Alert Channels                                                   │    │
│  │  ├─ GitHub Issues (auto-create on failure)                       │    │
│  │  ├─ Email notification (critical errors)                         │    │
│  │  ├─ Slack/Discord webhook (optional)                             │    │
│  │  └─ Status page (GitHub Pages)                                   │    │
│  │                                                                    │    │
│  └───────────────────────────────────────────────────────────────────┘    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 9. Scalability & Performance Optimization

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    PERFORMANCE OPTIMIZATION STRATEGIES                      │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  Strategy 1: Intelligent Caching                                           │
│  ┌───────────────────────────────────────────────────────────────────┐    │
│  │                                                                    │    │
│  │  Context Caching                                                  │    │
│  │  ├─ Cache game lore docs (static)                                │    │
│  │  ├─ Cache previous announcements (rolling 10)                    │    │
│  │  ├─ Cache reference screenshot                                   │    │
│  │  └─ TTL: 7 days or until config changes                          │    │
│  │                                                                    │    │
│  │  Image Caching                                                    │    │
│  │  ├─ Store generated banners with commit hash                     │    │
│  │  ├─ Reuse if patch notes unchanged                               │    │
│  │  └─ Cache logo composites by position                            │    │
│  │                                                                    │    │
│  │  API Response Caching                                             │    │
│  │  ├─ Cache Steam wishlist counts (1 hour)                         │    │
│  │  ├─ Cache app metadata (24 hours)                                │    │
│  │  └─ Use ETag headers when available                              │    │
│  │                                                                    │    │
│  │  Savings: 30-50% reduction in API calls                          │    │
│  │                                                                    │    │
│  └───────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  Strategy 2: Batch Processing                                              │
│  ┌───────────────────────────────────────────────────────────────────┐    │
│  │                                                                    │    │
│  │  Multi-Game Studios                                               │    │
│  │  ├─ Process all games in single Action run                       │    │
│  │  ├─ Share context between games (studio voice)                   │    │
│  │  ├─ Parallel API calls (asyncio)                                 │    │
│  │  └─ Batched Steam uploads                                        │    │
│  │                                                                    │    │
│  │  Commit Grouping                                                  │    │
│  │  ├─ Process multiple commits together                            │    │
│  │  ├─ Generate single announcement for related changes             │    │
│  │  └─ Avoid spam (max 1 per week enforcement)                      │    │
│  │                                                                    │    │
│  └───────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  Strategy 3: Resource Optimization                                         │
│  ┌───────────────────────────────────────────────────────────────────┐    │
│  │                                                                    │    │
│  │  GitHub Actions Minutes                                           │    │
│  │  ├─ Conditional execution (skip if no changes)                   │    │
│  │  ├─ Efficient dependencies (minimal Docker layers)               │    │
│  │  ├─ Parallel steps where possible                                │    │
│  │  └─ Early exit on validation failures                            │    │
│  │                                                                    │    │
│  │  Memory Management                                                │    │
│  │  ├─ Stream large files (don't load all in RAM)                   │    │
│  │  ├─ Delete temporary files immediately                           │    │
│  │  ├─ Use generators vs. lists for large datasets                  │    │
│  │  └─ Limit Pillow image buffer size                               │    │
│  │                                                                    │    │
│  │  Network Optimization                                             │    │
│  │  ├─ Compress images before upload                                │    │
│  │  ├─ Use HTTP/2 where supported                                   │    │
│  │  ├─ Connection pooling for API calls                             │    │
│  │  └─ Resume interrupted uploads                                   │    │
│  │                                                                    │    │
│  └───────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  Strategy 4: Load Distribution                                             │
│  ┌───────────────────────────────────────────────────────────────────┐    │
│  │                                                                    │    │
│  │  Time-Based Sharding                                              │    │
│  │  ├─ Distribute cron jobs across different hours                  │    │
│  │  ├─ Avoid peak API times (e.g., US business hours)               │    │
│  │  └─ Randomize execution within time window                       │    │
│  │                                                                    │    │
│  │  Geographic Distribution                                          │    │
│  │  ├─ Use GitHub Actions in multiple regions (future)              │    │
│  │  ├─ Route to nearest Google AI endpoint                          │    │
│  │  └─ Steam CDN for asset downloads                                │    │
│  │                                                                    │    │
│  └───────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  Performance Targets                                                       │
│  ┌───────────────────────────────────────────────────────────────────┐    │
│  │  • Cold start: <90 seconds (all steps)                           │    │
│  │  • Warm start: <30 seconds (cached context)                      │    │
│  │  • API latency: <10 seconds (per call)                           │    │
│  │  • Success rate: >95% (without manual intervention)              │    │
│  │  • Cost per run: <.05 (with BYOK)                              │    │
│  └───────────────────────────────────────────────────────────────────┘    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```


## 10. Database Schema & State Management

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    STATE MANAGEMENT ARCHITECTURE                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  Philosophy: Git as Database (No External DB Required)                     │
│  ┌───────────────────────────────────────────────────────────────────┐    │
│  │                                                                    │    │
│  │  State is stored in the Git repository itself:                   │    │
│  │  • Configuration → JSON files                                     │    │
│  │  • History → Git tags and commit log                             │    │
│  │  • Metadata → YAML frontmatter                                    │    │
│  │  • Artifacts → Git artifacts/releases                            │    │
│  │                                                                    │    │
│  │  Benefits:                                                        │    │
│  │  ✓ Version controlled automatically                              │    │
│  │  ✓ No database hosting costs                                     │    │
│  │  ✓ Works offline (local clones)                                  │    │
│  │  ✓ Backup = git push                                             │    │
│  │                                                                    │    │
│  └───────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  Repository Structure                                                      │
│  ┌───────────────────────────────────────────────────────────────────┐    │
│  │                                                                    │    │
│  │  game-repo/                                                       │    │
│  │  ├─ .github/                                                      │    │
│  │  │   └─ workflows/                                                │    │
│  │  │       └─ wishlistops.yml         # Workflow definition        │    │
│  │  │                                                                │    │
│  │  ├─ wishlistops/                    # WishlistOps data folder    │    │
│  │  │   ├─ config.json                 # Main configuration         │    │
│  │  │   ├─ state.json                  # Current state tracking     │    │
│  │  │   ├─ history.json                # Past runs history          │    │
│  │  │   ├─ assets/                                                  │    │
│  │  │   │   ├─ logo.png                # Game logo                  │    │
│  │  │   │   ├─ screenshot.png          # Style reference            │    │
│  │  │   │   └─ banner_cache/           # Cached generated banners   │    │
│  │  │   ├─ context/                                                 │    │
│  │  │   │   ├─ lore.md                 # Game lore document         │    │
│  │  │   │   ├─ voice_guide.md          # Writing style guide        │    │
│  │  │   │   └─ previous_posts.md       # Past announcements         │    │
│  │  │   └─ templates/                                               │    │
│  │  │       ├─ announcement.md.j2      # Jinja2 template            │    │
│  │  │       └─ styles.json             # Banner style presets       │    │
│  │  │                                                                │    │
│  │  ├─ .wishlistops_cache/             # Local cache (gitignored)   │    │
│  │  └─ src/                             # Game source code          │    │
│  │                                                                    │    │
│  └───────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  Configuration Schema (config.json)                                        │
│  ┌───────────────────────────────────────────────────────────────────┐    │
│  │                                                                    │    │
│  │  {                                                                │    │
│  │    "version": "1.0",                                              │    │
│  │    "steam": {                                                     │    │
│  │      "app_id": "123456",                                          │    │
│  │      "app_name": "My Awesome Game"                                │    │
│  │    },                                                             │    │
│  │    "branding": {                                                  │    │
│  │      "art_style": "pixel art fantasy",                            │    │
│  │      "color_palette": ["#FF6B6B", "#4ECDC4", "#FFE66D"],          │    │
│  │      "logo_position": "top-right",                                │    │
│  │      "logo_size_percent": 25                                      │    │
│  │    },                                                             │    │
│  │    "voice": {                                                     │    │
│  │      "tone": "casual and excited",                                │    │
│  │      "personality": "friendly indie developer",                   │    │
│  │      "avoid_phrases": ["monetization", "grind"]                   │    │
│  │    },                                                             │    │
│  │    "automation": {                                                │    │
│  │      "enabled": true,                                             │    │
│  │      "trigger_on_tags": true,                                     │    │
│  │      "schedule": "0 12 * * 1",                                    │    │
│  │      "min_days_between_posts": 7,                                 │    │
│  │      "require_manual_approval": true                              │    │
│  │    },                                                             │    │
│  │    "ai": {                                                        │    │
│  │      "model_text": "gemini-1.5-pro",                              │    │
│  │      "model_image": "gemini-2.5-flash-image",                     │    │
│  │      "temperature": 0.7,                                          │    │
│  │      "max_retries": 3                                             │    │
│  │    }                                                              │    │
│  │  }                                                                │    │
│  │                                                                    │    │
│  └───────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  State Schema (state.json)                                                 │
│  ┌───────────────────────────────────────────────────────────────────┐    │
│  │                                                                    │    │
│  │  {                                                                │    │
│  │    "last_run": {                                                  │    │
│  │      "timestamp": "2025-01-20T15:30:00Z",                         │    │
│  │      "commit_sha": "abc123...",                                   │    │
│  │      "tag": "v1.2.3",                                             │    │
│  │      "success": true,                                             │    │
│  │      "duration_seconds": 67                                       │    │
│  │    },                                                             │    │
│  │    "last_post": {                                                 │    │
│  │      "date": "2025-01-20",                                        │    │
│  │      "steam_post_id": "789456123",                                │    │
│  │      "announcement_type": "major_update",                         │    │
│  │      "wordcount": 342,                                            │    │
│  │      "image_hash": "sha256:def456..."                             │    │
│  │    },                                                             │    │
│  │    "statistics": {                                                │    │
│  │      "total_runs": 45,                                            │    │
│  │      "successful_runs": 43,                                       │    │
│  │      "failed_runs": 2,                                            │    │
│  │      "total_posts_created": 38,                                   │    │
│  │      "total_images_generated": 52,                                │    │
│  │      "cache_hit_rate": 0.34                                       │    │
│  │    },                                                             │    │
│  │    "rate_limits": {                                               │    │
│  │      "posts_this_week": 1,                                        │    │
│  │      "week_start": "2025-01-19",                                  │    │
│  │      "google_api_calls_today": 23,                                │    │
│  │      "steam_api_calls_today": 5                                   │    │
│  │    }                                                              │    │
│  │  }                                                                │    │
│  │                                                                    │    │
│  └───────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  History Schema (history.json)                                             │
│  ┌───────────────────────────────────────────────────────────────────┐    │
│  │                                                                    │    │
│  │  {                                                                │    │
│  │    "runs": [                                                      │    │
│  │      {                                                            │    │
│  │        "id": "run_001",                                           │    │
│  │        "timestamp": "2025-01-20T15:30:00Z",                       │    │
│  │        "trigger": "tag_push",                                     │    │
│  │        "tag": "v1.2.3",                                           │    │
│  │        "commits_processed": 15,                                   │    │
│  │        "player_facing_changes": 8,                                │    │
│  │        "announcement_title": "New Combat System!",                │    │
│  │        "announcement_length": 342,                                │    │
│  │        "banner_generated": true,                                  │    │
│  │        "banner_url": "artifacts/banner_v1.2.3.png",               │    │
│  │        "steam_posted": true,                                      │    │
│  │        "steam_post_id": "789456123",                              │    │
│  │        "performance": {                                           │    │
│  │          "git_parse_ms": 523,                                     │    │
│  │          "ai_text_gen_ms": 12450,                                 │    │
│  │          "ai_image_gen_ms": 8730,                                 │    │
│  │          "compositing_ms": 1240,                                  │    │
│  │          "steam_upload_ms": 3890,                                 │    │
│  │          "total_ms": 67234                                        │    │
│  │        },                                                         │    │
│  │        "errors": []                                               │    │
│  │      }                                                            │    │
│  │    ]                                                              │    │
│  │  }                                                                │    │
│  │                                                                    │    │
│  └───────────────────────────────────────────────────────────────────┘    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 11. API Integration Specifications

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         API INTEGRATION DETAILS                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  Google AI API (Gemini)                                                    │
│  ┌───────────────────────────────────────────────────────────────────┐    │
│  │                                                                    │    │
│  │  Endpoint: https://generativelanguage.googleapis.com/v1beta      │    │
│  │                                                                    │    │
│  │  Authentication:                                                  │    │
│  │  • API Key in header: x-goog-api-key                             │    │
│  │  • Or OAuth 2.0 Bearer token                                     │    │
│  │                                                                    │    │
│  │  Text Generation (Gemini 1.5 Pro):                               │    │
│  │  POST /models/gemini-1.5-pro:generateContent                     │    │
│  │  {                                                                │    │
│  │    "contents": [{                                                 │    │
│  │      "role": "user",                                              │    │
│  │      "parts": [{                                                  │    │
│  │        "text": "Analyze these commits..."                         │    │
│  │      }]                                                           │    │
│  │    }],                                                            │    │
│  │    "systemInstruction": {                                         │    │
│  │      "parts": [{                                                  │    │
│  │        "text": "You are a marketing assistant for indie games"    │    │
│  │      }]                                                           │    │
│  │    },                                                             │    │
│  │    "generationConfig": {                                          │    │
│  │      "temperature": 0.7,                                          │    │
│  │      "maxOutputTokens": 2048                                      │    │
│  │    }                                                              │    │
│  │  }                                                                │    │
│  │                                                                    │    │
│  │  Image Generation (Gemini 2.5 Flash Image):                      │    │
│  │  POST /models/gemini-2.5-flash:generateContent                   │    │
│  │  {                                                                │    │
│  │    "contents": [{                                                 │    │
│  │      "parts": [{                                                  │    │
│  │        "text": "Generate a banner for: [description]"             │    │
│  │      }, {                                                         │    │
│  │        "inline_data": {                                           │    │
│  │          "mime_type": "image/png",                                │    │
│  │          "data": "[base64_reference_image]"                       │    │
│  │        }                                                          │    │
│  │      }]                                                           │    │
│  │    }],                                                            │    │
│  │    "generationConfig": {                                          │    │
│  │      "responseModalities": ["image"],                             │    │
│  │      "aspectRatio": "16:9"                                        │    │
│  │    }                                                              │    │
│  │  }                                                                │    │
│  │                                                                    │    │
│  │  Rate Limits (Free Tier):                                        │    │
│  │  • 60 requests per minute                                        │    │
│  │  • 100 images per day                                            │    │
│  │  • 2M tokens context per request                                 │    │
│  │                                                                    │    │
│  │  Response Handling:                                               │    │
│  │  • 200 OK: Extract content from JSON                             │    │
│  │  • 429 Too Many Requests: Backoff 60s                            │    │
│  │  • 400 Bad Request: Log and use fallback                         │    │
│  │  • 500 Server Error: Retry up to 3x                              │    │
│  │                                                                    │    │
│  └───────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  Steamworks API                                                            │
│  ┌───────────────────────────────────────────────────────────────────┐    │
│  │                                                                    │    │
│  │  Base URL: https://api.steampowered.com                          │    │
│  │  Partner API: https://partner.steam-api.com                       │    │
│  │                                                                    │    │
│  │  Authentication:                                                  │    │
│  │  • Publisher Web API Key (from Steamworks dashboard)             │    │
│  │  • Passed as query param: ?key=XXXXXXXXXXXXX                     │    │
│  │                                                                    │    │
│  │  Get App Details:                                                 │    │
│  │  GET /ISteamApps/GetAppList/v2/                                  │    │
│  │  • Returns: List of all Steam apps                               │    │
│  │                                                                    │    │
│  │  Post News Announcement:                                          │    │
│  │  POST /ISteamNews/PostNewsUpdate/v1/                             │    │
│  │  Parameters:                                                      │    │
│  │  • appid: Steam App ID                                           │    │
│  │  • title: Announcement title (max 255 chars)                     │    │
│  │  • contents: BBCode formatted body                               │    │
│  │  • feedlabel: "Product Update" | "Event" | "News"                │    │
│  │  • feedname: Display name                                        │    │
│  │  • gid: Game ID (optional)                                       │    │
│  │                                                                    │    │
│  │  BBCode Format:                                                   │    │
│  │  [h1]Major Update[/h1]                                            │    │
│  │  [b]New Features:[/b]                                             │    │
│  │  [list]                                                           │    │
│  │  [*]Feature 1                                                     │    │
│  │  [*]Feature 2                                                     │    │
│  │  [/list]                                                          │    │
│  │  [img]https://cdn.akamai.steamstatic.com/...[/img]               │    │
│  │                                                                    │    │
│  │  Upload Image to CDN:                                             │    │
│  │  POST /ISteamRemoteStorage/FileShare/v1/                         │    │
│  │  • Multipart form upload                                         │    │
│  │  • Returns: CDN URL for use in announcements                     │    │
│  │                                                                    │    │
│  │  Get Wishlist Stats (Unofficial):                                │    │
│  │  Note: No official API. Use SteamSpy or scraping as fallback     │    │
│  │  https://steamspy.com/api.php?request=appdetails&appid=123456    │    │
│  │                                                                    │    │
│  │  Rate Limits:                                                     │    │
│  │  • 100,000 requests per day                                      │    │
│  │  • 200 requests per 5 minutes                                    │    │
│  │  • Burst: 10 concurrent requests                                 │    │
│  │                                                                    │    │
│  │  Error Codes:                                                     │    │
│  │  • 1: Success                                                     │    │
│  │  • 2: Failure (generic)                                          │    │
│  │  • 5: Invalid parameter                                          │    │
│  │  • 15: Access denied (invalid API key)                           │    │
│  │  • 42: Rate limit exceeded                                       │    │
│  │                                                                    │    │
│  └───────────────────────────────────────────────────────────────────┘    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```


## 12. Complete System Workflow (End-to-End)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    COMPLETE WORKFLOW: COMMIT TO STEAM                       │
└─────────────────────────────────────────────────────────────────────────────┘

TIME: T+0s
┌─────────────────────────────────────────────────────────────────────┐
│  TRIGGER EVENT                                                      │
│  Developer executes: git tag v1.2.0 && git push --tags              │
└─────────────────────────────────────────────────────────────────────┘
                                │
                                v
TIME: T+2s
┌─────────────────────────────────────────────────────────────────────┐
│  GITHUB WEBHOOK                                                     │
│  • GitHub detects tag push                                          │
│  • Matches workflow trigger: on.push.tags                           │
│  • Queues Action job                                                │
└─────────────────────────────────────────────────────────────────────┘
                                │
                                v
TIME: T+5s
┌─────────────────────────────────────────────────────────────────────┐
│  RUNNER PROVISIONING                                                │
│  • GitHub Actions allocates Ubuntu 22.04 runner                     │
│  • Checkout repository (checkout@v4)                                │
│  • Setup Python 3.11                                                │
│  • Install dependencies: pip install -r requirements.txt            │
└─────────────────────────────────────────────────────────────────────┘
                                │
                                v
TIME: T+15s
┌─────────────────────────────────────────────────────────────────────┐
│  STEP 1: CONFIGURATION LOADING                                      │
│  ┌───────────────────────────────────────────────────────────┐     │
│  │  • Load wishlistops/config.json                           │     │
│  │  • Validate required fields                               │     │
│  │  • Load secrets from GitHub environment                   │     │
│  │  • Initialize logging                                     │     │
│  └───────────────────────────────────────────────────────────┘     │
│                                                                     │
│  Python: config_manager.load_config()                              │
│  Duration: ~1s                                                     │
└─────────────────────────────────────────────────────────────────────┘
                                │
                                v
TIME: T+16s
┌─────────────────────────────────────────────────────────────────────┐
│  STEP 2: GIT LOG ANALYSIS                                           │
│  ┌───────────────────────────────────────────────────────────┐     │
│  │  • Identify last tag: v1.1.0                              │     │
│  │  • Extract commits: v1.1.0..v1.2.0                        │     │
│  │  • Parse commit messages (15 commits found)               │     │
│  │  • Filter merge commits                                   │     │
│  │  • Extract file change summaries                          │     │
│  └───────────────────────────────────────────────────────────┘     │
│                                                                     │
│  Shell: git log v1.1.0..v1.2.0 --oneline                           │
│  Python: commit_analyzer.parse_commits()                           │
│  Duration: ~2s                                                     │
│                                                                     │
│  Output: commits_data.json                                         │
│  {                                                                  │
│    "total": 15,                                                    │
│    "commits": [                                                    │
│      {"sha": "abc123", "message": "Add double jump", ...},         │
│      ...                                                           │
│    ]                                                               │
│  }                                                                  │
└─────────────────────────────────────────────────────────────────────┘
                                │
                                v
TIME: T+18s
┌─────────────────────────────────────────────────────────────────────┐
│  STEP 3: CONTEXT ASSEMBLY                                           │
│  ┌───────────────────────────────────────────────────────────┐     │
│  │  • Load lore document (wishlistops/context/lore.md)       │     │
│  │  • Load voice guide (wishlistops/context/voice_guide.md)  │     │
│  │  • Load previous posts (last 5 announcements)             │     │
│  │  • Combine into mega-context string                       │     │
│  └───────────────────────────────────────────────────────────┘     │
│                                                                     │
│  Python: prompt_builder.assemble_context()                         │
│  Duration: ~1s                                                     │
│                                                                     │
│  Context Size: ~150,000 tokens                                     │
└─────────────────────────────────────────────────────────────────────┘
                                │
                                v
TIME: T+19s
┌─────────────────────────────────────────────────────────────────────┐
│  STEP 4: AI TEXT GENERATION (Gemini 1.5 Pro)                       │
│  ┌───────────────────────────────────────────────────────────┐     │
│  │  REQUEST:                                                  │     │
│  │  System: "You are a marketing assistant for indie games"  │     │
│  │  User: "[full context] + [commits] + Write announcement"  │     │
│  │                                                            │     │
│  │  PROCESSING:                                               │     │
│  │  • API call to Gemini 1.5 Pro                             │     │
│  │  • Temperature: 0.7                                        │     │
│  │  • Max tokens: 2048                                        │     │
│  │                                                            │     │
│  │  RESPONSE:                                                 │     │
│  │  Title: "Combat Overhaul: The Knight Awakens!"            │     │
│  │  Body: [BBCode formatted announcement, 342 words]          │     │
│  └───────────────────────────────────────────────────────────┘     │
│                                                                     │
│  Python: ai_client.generate_text()                                 │
│  Duration: ~8s                                                     │
│                                                                     │
│  Output: announcement_draft.md                                     │
└─────────────────────────────────────────────────────────────────────┘
                                │
                                v
TIME: T+27s
┌─────────────────────────────────────────────────────────────────────┐
│  STEP 5: VISUAL PROMPT CONSTRUCTION                                 │
│  ┌───────────────────────────────────────────────────────────┐     │
│  │  • Extract key visual elements from announcement          │     │
│  │  • Load reference screenshot (base64 encode)              │     │
│  │  • Incorporate art style from config                      │     │
│  │  • Build image generation prompt                          │     │
│  └───────────────────────────────────────────────────────────┘     │
│                                                                     │
│  Python: prompt_builder.build_image_prompt()                       │
│  Duration: ~1s                                                     │
│                                                                     │
│  Prompt: "Create a 16:9 banner for a pixel art fantasy game        │
│  featuring a knight with a glowing sword. Style: pixel art,        │
│  colors: warm orange and deep blue. Reference image attached."     │
└─────────────────────────────────────────────────────────────────────┘
                                │
                                v
TIME: T+28s
┌─────────────────────────────────────────────────────────────────────┐
│  STEP 6: AI IMAGE GENERATION (Gemini 2.5 Flash Image)              │
│  ┌───────────────────────────────────────────────────────────┐     │
│  │  REQUEST:                                                  │     │
│  │  Model: gemini-2.5-flash-image                            │     │
│  │  Prompt: [visual prompt]                                   │     │
│  │  Reference: [base64 screenshot]                            │     │
│  │  Aspect ratio: 16:9                                        │     │
│  │                                                            │     │
│  │  PROCESSING:                                               │     │
│  │  • API call with multimodal input                         │     │
│  │  • Generation time: 3-8 seconds                            │     │
│  │  • SynthID watermark applied                              │     │
│  │                                                            │     │
│  │  RESPONSE:                                                 │     │
│  │  Image: base64 PNG (1024x576px)                           │     │
│  └───────────────────────────────────────────────────────────┘     │
│                                                                     │
│  Python: ai_client.generate_image()                                │
│  Duration: ~7s                                                     │
│                                                                     │
│  Output: banner_base.png                                           │
└─────────────────────────────────────────────────────────────────────┘
                                │
                                v
TIME: T+35s
┌─────────────────────────────────────────────────────────────────────┐
│  STEP 7: LOGO COMPOSITING (Pillow/PIL)                             │
│  ┌───────────────────────────────────────────────────────────┐     │
│  │  INPUT:                                                    │     │
│  │  • banner_base.png (1024x576)                             │     │
│  │  • logo.png (transparent, 512x512)                        │     │
│  │                                                            │     │
│  │  PROCESSING:                                               │     │
│  │  1. Open both images with PIL                             │     │
│  │  2. Resize logo to 25% of banner width (~200px)           │     │
│  │  3. Position at top-right corner (safe zone)              │     │
│  │  4. Apply drop shadow effect                              │     │
│  │  5. Composite using alpha blending                        │     │
│  │  6. Resize to Steam spec: 800x450px                       │     │
│  │  7. Optimize: quality=95, progressive=True                │     │
│  │                                                            │     │
│  │  OUTPUT:                                                   │     │
│  │  • banner_final.png (800x450, <1MB)                       │     │
│  └───────────────────────────────────────────────────────────┘     │
│                                                                     │
│  Python: image_compositor.composite_logo()                         │
│  Duration: ~2s                                                     │
│                                                                     │
│  Output: banner_final.png                                          │
└─────────────────────────────────────────────────────────────────────┘
                                │
                                v
TIME: T+37s
┌─────────────────────────────────────────────────────────────────────┐
│  STEP 8: QUALITY VALIDATION                                         │
│  ┌───────────────────────────────────────────────────────────┐     │
│  │  Text Checks:                                              │     │
│  │  ✓ Length: 342 words (within 50-500 range)                │     │
│  │  ✓ No placeholder text detected                           │     │
│  │  ✓ BBCode syntax valid                                    │     │
│  │  ✓ Title length: 38 chars (<255 limit)                    │     │
│  │                                                            │     │
│  │  Image Checks:                                             │     │
│  │  ✓ Resolution: 800x450 (exact match)                      │     │
│  │  ✓ File size: 847 KB (<2MB limit)                         │     │
│  │  ✓ Format: PNG with transparency                          │     │
│  │  ✓ Logo visible (contrast check passed)                   │     │
│  └───────────────────────────────────────────────────────────┘     │
│                                                                     │
│  Python: validator.check_quality()                                 │
│  Duration: ~1s                                                     │
└─────────────────────────────────────────────────────────────────────┘
                                │
                                v
TIME: T+38s
┌─────────────────────────────────────────────────────────────────────┐
│  STEP 9: STEAM IMAGE UPLOAD                                         │
│  ┌───────────────────────────────────────────────────────────┐     │
│  │  REQUEST:                                                  │     │
│  │  POST /ISteamRemoteStorage/FileShare/v1/                  │     │
│  │  • Authenticate with Publisher API key                    │     │
│  │  • Upload banner_final.png (multipart)                    │     │
│  │                                                            │     │
│  │  RESPONSE:                                                 │     │
│  │  {                                                         │     │
│  │    "success": 1,                                           │     │
│  │    "url": "https://cdn.akamai.steamstatic.com/..."        │     │
│  │  }                                                         │     │
│  └───────────────────────────────────────────────────────────┘     │
│                                                                     │
│  Python: steam_client.upload_image()                               │
│  Duration: ~5s (network dependent)                                 │
│                                                                     │
│  Output: cdn_image_url                                             │
└─────────────────────────────────────────────────────────────────────┘
                                │
                                v
TIME: T+43s
┌─────────────────────────────────────────────────────────────────────┐
│  STEP 10: ANNOUNCEMENT FORMATTING                                   │
│  ┌───────────────────────────────────────────────────────────┐     │
│  │  • Insert CDN image URL into announcement body             │     │
│  │  • Format as BBCode: [img]https://cdn...[/img]            │     │
│  │  • Add standard footer                                     │     │
│  │  • Sanitize special characters                             │     │
│  └───────────────────────────────────────────────────────────┘     │
│                                                                     │
│  Python: formatter.finalize_announcement()                         │
│  Duration: <1s                                                     │
│                                                                     │
│  Final BBCode:                                                     │
│  [h1]Combat Overhaul: The Knight Awakens![/h1]                     │
│  [img]https://cdn.akamai.steamstatic.com/.../banner.png[/img]      │
│  [b]New Features:[/b] ...                                          │
└─────────────────────────────────────────────────────────────────────┘
                                │
                                v
TIME: T+44s
┌─────────────────────────────────────────────────────────────────────┐
│  STEP 11: STEAM ANNOUNCEMENT POST                                   │
│  ┌───────────────────────────────────────────────────────────┐     │
│  │  REQUEST:                                                  │     │
│  │  POST /ISteamNews/PostNewsUpdate/v1/                      │     │
│  │  Parameters:                                               │     │
│  │    appid: 123456                                           │     │
│  │    title: "Combat Overhaul: The Knight Awakens!"          │     │
│  │    contents: [BBCode text]                                 │     │
│  │    feedlabel: "Product Update"                             │     │
│  │    feedname: "My Awesome Game"                             │     │
│  │    key: [STEAM_API_KEY]                                    │     │
│  │                                                            │     │
│  │  RESPONSE:                                                 │     │
│  │  {                                                         │     │
│  │    "success": 1,                                           │     │
│  │    "post_id": "789456123",                                 │     │
│  │    "status": "hidden"  // Awaiting manual approval        │     │
│  │  }                                                         │     │
│  └───────────────────────────────────────────────────────────┘     │
│                                                                     │
│  Python: steam_client.post_announcement()                          │
│  Duration: ~3s                                                     │
│                                                                     │
│  Output: steam_post_id                                             │
└─────────────────────────────────────────────────────────────────────┘
                                │
                                v
TIME: T+47s
┌─────────────────────────────────────────────────────────────────────┐
│  STEP 12: STATE UPDATE                                              │
│  ┌───────────────────────────────────────────────────────────┐     │
│  │  • Update wishlistops/state.json                          │     │
│  │  • Record run metadata                                     │     │
│  │  • Append to history.json                                  │     │
│  │  • Update rate limit counters                              │     │
│  │  • Commit changes to git (optional)                        │     │
│  └───────────────────────────────────────────────────────────┘     │
│                                                                     │
│  Python: state_manager.update_state()                              │
│  Duration: ~1s                                                     │
└─────────────────────────────────────────────────────────────────────┘
                                │
                                v
TIME: T+48s
┌─────────────────────────────────────────────────────────────────────┐
│  STEP 13: ARTIFACT STORAGE                                          │
│  ┌───────────────────────────────────────────────────────────┐     │
│  │  • Save artifacts to GitHub Actions artifacts              │     │
│  │    - announcement_draft.md                                 │     │
│  │    - banner_final.png                                      │     │
│  │    - run_log.txt                                           │     │
│  │  • Retention: 90 days                                      │     │
│  └───────────────────────────────────────────────────────────┘     │
│                                                                     │
│  GitHub Action: upload-artifact@v4                                 │
│  Duration: ~5s                                                     │
└─────────────────────────────────────────────────────────────────────┘
                                │
                                v
TIME: T+53s
┌─────────────────────────────────────────────────────────────────────┐
│  STEP 14: NOTIFICATION                                              │
│  ┌───────────────────────────────────────────────────────────┐     │
│  │  • Send notification to developer                          │     │
│  │    - GitHub Actions email (default)                        │     │
│  │    - Optional: Slack/Discord webhook                       │     │
│  │  • Include:                                                │     │
│  │    - Success status                                        │     │
│  │    - Link to Steam dashboard                               │     │
│  │    - Link to artifacts                                     │     │
│  │    - Performance metrics                                   │     │
│  └───────────────────────────────────────────────────────────┘     │
│                                                                     │
│  Python: notifier.send()                                           │
│  Duration: ~2s                                                     │
└─────────────────────────────────────────────────────────────────────┘
                                │
                                v
TIME: T+55s
┌─────────────────────────────────────────────────────────────────────┐
│  CLEANUP & COMPLETION                                               │
│  • Delete temporary files                                           │
│  • Clear sensitive data from memory                                 │
│  • Write final logs                                                 │
│  • Exit with status code 0                                          │
└─────────────────────────────────────────────────────────────────────┘
                                │
                                v
TIME: T+60s
┌─────────────────────────────────────────────────────────────────────┐
│  DEVELOPER MANUAL REVIEW                                            │
│  • Developer receives email notification                            │
│  • Logs into Steamworks dashboard                                   │
│  • Reviews hidden announcement                                      │
│  • Makes edits if needed                                            │
│  • Clicks "Publish" to make live                                    │
└─────────────────────────────────────────────────────────────────────┘
                                │
                                v
┌─────────────────────────────────────────────────────────────────────┐
│  LIVE ON STEAM STORE                                                │
│  • Announcement visible to all users                                │
│  • Wishlist velocity increases                                      │
│  • Algorithm detects activity → boosts visibility                   │
│  • Developer focuses on coding, not marketing                       │
└─────────────────────────────────────────────────────────────────────┘

TOTAL EXECUTION TIME: ~60 seconds
API CALLS: 3 (Gemini Text, Gemini Image, Steam Upload)
COST: ~.04 (with BYOK)
DEVELOPER TIME SAVED: 2-4 hours
```

---

## 13. Future Architecture Extensions

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         ROADMAP: PHASE 2 & 3                                │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  Phase 2: Multi-Platform Support (Q2 2025)                                 │
│  ┌───────────────────────────────────────────────────────────────────┐    │
│  │                                                                    │    │
│  │  Extend beyond Steam:                                             │    │
│  │  ├─ Epic Games Store (EGS) integration                            │    │
│  │  ├─ itch.io automatic devlog posting                              │    │
│  │  ├─ GOG.com news feed                                             │    │
│  │  └─ Nintendo/PlayStation developer portals                        │    │
│  │                                                                    │    │
│  │  Social Media Automation:                                         │    │
│  │  ├─ Twitter/X auto-tweets                                         │    │
│  │  ├─ TikTok vertical video generation                              │    │
│  │  ├─ YouTube Community posts                                       │    │
│  │  └─ Discord server announcements                                  │    │
│  │                                                                    │    │
│  └───────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  Phase 3: Advanced AI Features (Q3 2025)                                   │
│  ┌───────────────────────────────────────────────────────────────────┐    │
│  │                                                                    │    │
│  │  Video Generation:                                                │    │
│  │  ├─ Gameplay trailer auto-editing                                 │    │
│  │  ├─ Text-to-video for patch notes                                 │    │
│  │  └─ Animated GIF creation from screenshots                        │    │
│  │                                                                    │    │
│  │  Analytics & Optimization:                                        │    │
│  │  ├─ A/B testing of announcement styles                            │    │
│  │  ├─ Sentiment analysis of player comments                         │    │
│  │  ├─ Optimal posting time prediction                               │    │
│  │  └─ Wishlist velocity forecasting                                 │    │
│  │                                                                    │    │
│  │  Localization:                                                    │    │
│  │  ├─ Auto-translate announcements (10+ languages)                  │    │
│  │  ├─ Cultural adaptation (not just translation)                    │    │
│  │  └─ Regional banner variations                                    │    │
│  │                                                                    │    │
│  └───────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  Phase 4: Marketplace Ecosystem (Q4 2025)                                  │
│  ┌───────────────────────────────────────────────────────────────────┐    │
│  │                                                                    │    │
│  │  Template Marketplace:                                            │    │
│  │  ├─ Developers share announcement templates                       │    │
│  │  ├─ Premium templates by marketing pros                           │    │
│  │  └─ Revenue sharing model (70/30 split)                           │    │
│  │                                                                    │    │
│  │  Plugin System:                                                   │    │
│  │  ├─ Community-built extensions                                    │    │
│  │  ├─ Genre-specific modules (RPG, FPS, etc.)                       │    │
│  │  └─ Custom AI model integration                                   │    │
│  │                                                                    │    │
│  │  Publisher Features:                                              │    │
│  │  ├─ Manage 100+ games from single dashboard                       │    │
│  │  ├─ Cross-game campaigns                                          │    │
│  │  ├─ Brand consistency enforcement                                 │    │
│  │  └─ Team collaboration tools                                      │    │
│  │                                                                    │    │
│  └───────────────────────────────────────────────────────────────────┘    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Conclusion

This document provides a comprehensive visual representation of the WishlistOps system architecture, from high-level concepts to detailed API specifications. The system is designed to be:

- **Serverless**: Leveraging GitHub Actions (no server management)
- **Cost-effective**: BYOK model eliminates API reselling costs
- **Developer-friendly**: Git-native workflow, no context switching
- **Scalable**: Stateless design allows horizontal scaling
- **Secure**: Multi-layer security with encrypted secrets
- **Fast**: 60-second end-to-end execution time
- **Reliable**: Comprehensive error handling and fallbacks

The architecture is optimized for rapid MVP deployment while maintaining extensibility for future enhancements. By treating marketing as code and leveraging CI/CD principles, WishlistOps transforms a traditionally manual, time-consuming process into an automated, consistent, and scalable system.

---

*Document Version: 1.0*  
*Created: 2025*  
*Diagrams: ASCII Art (Mermaid/PlantUML versions available on request)*  
*Classification: Technical Architecture - System Design*
